---
title: 投资-随机游走
author: Junhan Hu
tags:
  - management
  - startup
mathjax: true
categories:
  - MarkdownNotes
  - 'Entrepreneurship '
date: 2022-10-17 21:34:00
---

## Why

Random walk for the market, make it impossible to have large advantage

* Fundamental analysis doesn't outperform the market
  * analyze all kinds of rate...
  * but maybe mislead by faulty information / wrong conclusion 
* Technical analysis doesn't outperform the market
  * unequal access to information, under-react
  * sharp reversals, profit maximization, self-defeating
* Human psychology
  * over-confidence
  * biased-judgements
  * herd mentality, group thinking
  * loss aversion, people value pain more
* Market can't be predicted, take what you can get
* Invest for the long run



