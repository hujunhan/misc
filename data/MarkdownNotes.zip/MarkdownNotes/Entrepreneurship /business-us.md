---
title: Start Business in US (STEM OPT)
author: Junhan Hu
tags:
  - management
  - startup
mathjax: true
categories:
  - MarkdownNotes
  - 'Entrepreneurship '
date: 2023-04-22 13:52:00
---

## Legal Eligibility

[Ref](https://studyinthestates.dhs.gov/stem-opt-hub/for-students/students-determining-stem-opt-extension-eligibility)

A student can only participate the STEM OPT **twice**

Must purpuse their practical training through a employer that is enreolled in E-verify

> they may use a start-up business so long as all regulatory requirements are met

[Ref2](https://louisville.edu/internationalcenter/isss/current-f1-j1-students/current-students/employment/f-1-opt-2-yr-stem-extension/opt-24-month-stem-extension-information)

May work for more than one employer, must be related to degree program and must be enrolled in E-verify

## Steps froim SBA

[Ref](https://www.sba.gov/business-guide/10-steps-start-your-business)

1. [Conduct market research](https://www.sba.gov/business-guide/plan-your-business/market-research-competitive-analysis)

   1. check if it is profitable

2. Write business plan. Roadmap for how to structure, how to grow

3. [Fund your busniess](https://www.sba.gov/business-guide/plan-your-business/fund-your-business)

   1. Raise enough money

4. Pick a location

5. [Choose structure](https://www.sba.gov/business-guide/launch-your-business/choose-business-structure)

   1. sole proprietorship
   2. partnership
   3. LLC (limited liablity company)

   ![image-20230422144459462](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230422144459_PFlcQh.png)

6. Choose name

7. Register, make it legal and protect the brand

   1. Fedral, just simply filing to get a EIN
   2. [CA](https://www.sos.ca.gov/business-programs/business-entities/forms/)

8. Get EIN for federal and state tax

   1. just like the SSN for business

9. Apply for licenses

   1. vary by industry, state, locaiton and other factors

10. Open a business bank account

