---
title: 一句话描述
author: Junhan Hu
tags:
  - management
  - startup
mathjax: true
categories:
  - MarkdownNotes
  - 'Entrepreneurship '
date: 2022-04-14 15:07:00
---

## Intro

为什么需要一句话描述？

项目创业有很多，想要引起别人的注意，我们需要给别人留下深刻的印象，通过一句话描述可以在短时间内将自己的公司说明清楚

具体怎么做？

## How

https://fi.co/insight/can-you-explain-your-startup-idea-in-one-sentence

 **(公司名称)提供的 (产品或服务) 利用 (特色功能的突出) 帮助 (目标用户) 解决 (问题描述)**

几个原则

* 避免使用主观性描述
* 准确定义目标市场和客户
* 保持简单

## Practice

腾浩视线利用机器人和人工智能技术为茶企提供智能采摘机器人，帮助茶企降低人工成本、提高茶叶质量
