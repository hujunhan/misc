---
title: 创业？
author: Junhan Hu
tags:
  - management
  - startup
mathjax: true
categories:
  - MarkdownNotes
  - 'Entrepreneurship '
date: 2022-10-17 22:47:00
---

## Lean Startup

Goal: create something customer would buy, as quick as possible

No idea is that great

The main thing is execution.

Takeaway

1. build-measure-learn feedback loop
2. everything is a grand experiment
   1. observe, don't ask
3. MVP
   1. from easy to real
4. Three engine of growth
   1. sticky, long term customer
   2. viral, new customer should invite others
   3. paid
5. Pivot?

## Fastlane to financial freedom

From current to freedom

1. use the business and investment, time is the highest value, create passive income, and chase dream
2. wealth=profit+asset value, **not bound by time**
3. five bussiness
   1. control
   2. entry
   3. need
   4. time
   5. scale: quantity or quality

## Software Developer

[Ref](https://amaca.substack.com/p/how-i-got-wealthy-without-working?r=1ftgt3&utm_medium=ios&utm_campaign=post)

Define the goal: try to get the 80% of the reward with 20% of the work

Making money is procrastinating, when we choose money, we just decide to decide later. We should look for more free time.

Three takeaways

1. Do not compete, just do what the market need. Self-improvement to a enough level, then enjoy the life
2. Escape big cities
3. Compound, exponential function, take the benefit of exponential

How to find remote jobs?

* Build a public online profile, show something you've bu¬t