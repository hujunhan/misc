---
title: Business Proposal
author: Junhan Hu
tags:
  - management
  - startup
mathjax: true
categories:
  - MarkdownNotes
  - 'Entrepreneurship '
date: 2022-04-14 15:19:00
---

## Intro

What: A document outlines ideas and strategies for launching and managing

## Structure

1. What is the company
   1. slogan
2. Team
   1. experience
   2. unique
3. Operation
   1. What is user gonna use
   2. technology
4. Marketplace
   1. facts, numbers
5. Strategy
   1. When will you make money
6. Competition
   1. Why hasn't been done
7. Revenue
   1. How are you going to make money
   2. The cost
8. How much do you need

## Ref

[Business Plan Writing 101: Wharton Entrepreneurship Series](https://www.youtube.com/watch?v=zlrb_X6fYZ0)
