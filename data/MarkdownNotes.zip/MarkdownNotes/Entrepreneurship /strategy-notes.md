---
title: Strategy for Startup
author: Junhan Hu
tags:
  - management
  - startup
mathjax: true
categories:
  - MarkdownNotes
  - 'Entrepreneurship '
date: 2022-03-06 21:20:00
---
## Choosing Your Opportunity
Opportunity is neither a matter of simple luck nor a certain path. Opportunity is the formulation of a hypothesis by an entrepreneur about how to potentially create and capture value by providing something that is “missing” from the marketplace. 
### A Strategic Approach
3 insight about opportunities 
* opportunities are everywhere
* while opportunities are everywhere, not every opportunity is the right opportunity for every individual.
* opportunities are uncertain

Opportunity is a hypothesis about the potential for creating and capture value that, by its very nature, is uncertain at the moment it is first perceived. Indeed, it is that very uncertainty that creates the opportunity.
### Why Choose an Opportunity
Two questions 
* why is there an opportunity in a particular location and moment (here and now) to introduce something novel to the marketplace?
* why are you the entrepreneur or founding team to translate this opportunity into a reality?

### Value Creation and Capture: Why Here and Now
* Novel technologies,most involve a process of combinatorial innovation, where the innovator seeks to arrange different technological elements in a novel way
* Novel needs

### Perspective, Advantage, and Passion: Why You

* The Individual-Opportunity Nexus. Presented with precisely the same opportunity, different individuals will have differing assessments of the value of that opportunity as well as how best to pursue it.
* Unfair Advantage. prior knowledge allows an entrepreneur to weigh the relative strengths and weaknesses of alternative strategic options
* Passion. entrepreneur needs to undertake hard work and effort to realize value.

### Choosing Opportunity
Three key criteria stand out.
* unique value creation. The most valuable opportunities are those that have the potential to create value and are not already being pursued
* whether the entrepreneur possesses an unfair advantage. An entrepreneur is more likely to successfully pursue an opportunity for which that entrepreneur can leverage or attract resources and capabilities that others may not be able to access.
*  the passion that entrepreneur has for that idea. Passion is not simply a willingness to undertake the opportunity in the abstract but an ability to undertake the significant effort and work required to bring a particular opportunity to life.

## Choosing your Strategy
### Forming a core idea: identifying what you can choose
the best way to identify those choices is to know and be able to state very clearly what the core idea of the venture is.

> Amazon: use the Internet to order and deliver goods directly to consumers
### Four Domains of Entrepreneurial Choice
* customer
* technology 
* organization: culture style people location, attract resources as much as possible
* competition: choose who to avoid

### Why Choice Matters

**Resources is limited.**

The best process ends up being one between just doing it and full-on planning.

### The Choice Challenge

* Many Alternatives, good idea have more than one path to achieve it
* Tight Constraints, Financial and organizational resource constraints prevent the pursuit of more than one alternative at the same time.

### The Learning Challenge
Given that there is fundamental uncertainty about the quality of the entrepreneur’s core idea as well as whether any given path might create sufficient value, it is unclear which path to choose.

* Fundamental Uncertainty, Because of uncertainty, even the most optimistic projections should be treated with considerable skepticism.it is precisely this high level of uncertainty that justifies undertaking an active and iterative planning process. Unavoidable 
* Commitment-free learning can only generate noisy estimates of the value of an idea and an alternative.
* The paradox of entrepreneurship: Choosing between alternatives strategies requires knowledge that can only be gained through learning and
experimentation that itself can foreclose on the pursuit of other strategies.
Ultimately, entrepreneurs must experiment.

### Test Two, Choose One
For a given idea, entrepreneurs should only begin to commit to one business plan after considering multiple strategic alternatives and identifying at least two that are commercially viable yet difficult to rank.
### Takeaway
one reason you might choose one path above another is that the path involves fewer commitments and an opportunity to pivot if that path proves unsuccessful

## Choosing Customer

there are often multiple paths for technological development

## Choosing Technology

Fewer challenges or potentially superior trajectory

* Prioritizing  innovation  allows  a  startup  to  offer  a  vision  to  potential investors, employees, partners, customers
* The  resources,  time  and  emphasis  to achieving technical objectives may lead to different consumer insights and thus, it will  also  matter  if  those  are  the  right  consumers

### The Technology S-curve

![image-20220205143646216](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-02-05-14-36-46.png)

Need a metrics to evaluate an idea, connect it with value creation

* Existing solutions' constrain can be overcame by new solutions
* Can start-up team take advantage from the window of opportunity in S-Curve. Compare different method
* General vs. Specialized





## Choosing Organization

Questions: It's impossible to great at everything.

### Why Choose Organization

Need a group, so an organizations is required to deliver on value creation and capture.

It's about

* How organization formed
* What element is prioritized

At beginning, the startup team is limited. Face 3 challenges

* Limited resources like money human and time
* High level of uncertainty of alternative organization form.
  * Whom to hire? Tech? Sale?
* Imprinting of founders

### Resources and Capabilities

The effective management of valuable resources and unique capabilities is often identified as the one of (if not the most) important driver of the success of any organization.

Make use of the unique advantage of group (like high education level, or locate more local), so that competition can not imitate quickly.

### Starting Organization

for most ventures, the pursuit of opportunity involves somehow gaining access or control over resources and capabilities beyond the initial resources and capabilities of the founding team.

The entrepreneur must also figure out how to gain access to those resources and capabilities in order to grow their organization over time.

The key is **growth**

* Focus by setting metrics.
* Choosing the founding team, those who have the same core mission

### Grwoth

The growth of a firm (the most common type of organization established by an entrepreneur) is the change over time in the accumulation of human, physical, and financial resources and the development of processes and structures (and even organizational culture) that enable capabilities.

* to test and implement their overall entrepreneurial strategy, a new firm needs to attract or acquire new resources and capabilities beyond those under its control at the time of founding.
* On the other hand, the process of attracting and acquiring resources itself takes time and attention away from implementing the strategy itself.

### Build Capabilities & Leveraging resources

A capability is, at a very broad level, something that your business is good at.

The make versus buy decision defines what will be done inside the business as opposed to outside of it. 

* **In choosing whether to make or buy with respect to a good or service, a startup must trade off the ability to procure externally the best products available globally at present versus the ability to set their own dynamic path for internal improvement of those products.**q

### Model

* Star model
* Factory model
* Engineering model
* Commitment model
