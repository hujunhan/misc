---
title: Management for Startup
author: Junhan Hu
tags:
  - management
  - startup
mathjax: true
categories:
  - MarkdownNotes
  - 'Entrepreneurship '
date: 2022-04-06 21:20:00
---

## Intro

Goal: manage startup between 2-150 people, responsible for other people's output

Limit: time and experience

Solution: 

* find the smallest possible set of techniques to be a manager
* First principle

## What is Manager's Job

Goal: **increase the output of the team**, the single principle

Limit: the activities of a manager is complicated, and not directly map to **business value**

How to measure the value of a manager? (Rather than an individual contributor)

* increase the output
* maximize the value of employee

What to learn? Techniques that can help to achieve this goal

> Exercise: every week, sit down and ask have I increased or decreased the output

## How to Delegate Without Micro-Management

Individual contributor who are effective tend to dislike giving up tasks they are good at.

BAD: Manager should not use superior knowledge to take control of task

* Would result subordinates' unhappiness
* Team's output is reduced (Never act by self)

HOW TO AVOID: 

* Share the **common** **understanding** between delegator and delegatee
* **Training** others (this is manager's job)

Check the output: Responsible for the output of your team

* check at the *lowest value stage of production*
* check often at the beginning, and then taper off as the feature reaches completion.

What to delegate?

* things you already know how to do
* if not, ask a plan from subordinate, check the thinking

## How to Train Without Becoming a Bottleneck

Just like Super-Mario, introduce the part and mechanics

* Introduce one idea one time
  * code base, language, repo, tool, deploy
* Give little task, follow the **instruction** and call me ever stuck
  * A following harder task
* Try to create a training program for new hire
* Systemastsing 
  * Won't miss crucial part
  * Allows to scale

How to create the training program?

1. Think about the task you most likely to delegate
2. Break down, order it from simple to complex
3. Write down as a series of task
4. Testing, go back and tweak

## How to Prioritise and Regain Your Sanity

A good manager should change the mix of activities so that do more high **leverage** activities

![img](https://managementforstartups.com/articles/content/images/2018/11/DraggedImage.a18c7289b46041e4bd48b1049e7aea43.png)

You should gather information as much as possible

* informal channels
* one-on-one meetings
* written reports

## One-on-Ones: How to Prevent Blowups From Happening

Powerful tool to catch problem that might have huge impact in the future

> One-on-One origin: Intel
>
> Goal: Mutual teaching and exchange of information

Principle:

* Information transfer
* Build context and trust

Frequency? 2 week / 1 month / 1 quarter

How？

1. Share information
2. Talk about personal life
3. Professional development

Result：

* Normal update
* Rant $\to$ listen, mirror the problem / label the pain
* Explosion

## Where to Go From Here

Practice

## Ref

https://managementforstartups.com/
