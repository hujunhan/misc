---
title: Why Normal Distribution? Central Limit Theorem
author: Junhan Hu
tags:
  - statistics
mathjax: true
categories:
  - MarkdownNotes
  - Math
date: 2023-06-08 23:31:00
---

## Intro

Why is normal distribution so common?

Since the Central Limit Theorem

## Central Limit Theorem

Random variable $X$

Add N samples of this variable

* The distribution would be a bell curve

How mean and std changes? NX

* $N\times\mu$
* $\sqrt{N}\times\sigma$

No matter what the **origin** distribution is 

* When you normalize it ($\mu=0,\sigma=1$)
* the **final** result would be a normal distribution

### Why $e$

Since the integral of $e^{-x^2}$ is $\pi$

### Standard

$$
\frac{1}{\sigma \sqrt{2 \pi}} e^{-\frac{1}{2}\left(\frac{x-\mu}{\sigma}\right)^2}
$$

### Understanding

$$
\lim _{N \rightarrow \infty} P(a<\text {  value }<b)=\int_a^b \frac{1}{\sqrt{2 \pi}} e^{-x^2 / 2} d x
$$

Where value is
$$
\frac{\left(X_1+\cdots+X_N\right)-N \cdot \mu}{\sigma \cdot \sqrt{N}}
$$
