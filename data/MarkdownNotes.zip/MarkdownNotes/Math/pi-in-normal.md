---
title: Why There is a Pi in Normal Distribution
author: Junhan Hu
tags:
  - statistics
mathjax: true
categories:
  - MarkdownNotes
  - Math
date: 2023-06-09 22:53:00
---

## Intro

1. Why $e^{-x^2}$ integral is $\sqrt{\pi}$
2. Where is the $e^{-x^2}$ come from
3. Connect

## How to Calculate

Add a dimension and solve it 



Subject: Request to Update Address and Adjust Auto Insurance Coverage

Dear [Insurance Agent's Name],

I hope this message finds you well.

I am writing to inform you that I have recently relocated and would appreciate it if you could update my personal records, specifically for my auto insurance policy. My new address is as follows:

1455 McCandless Drive, Milpitas, CA, 95035

In addition to this, as I have recently turned 25, I would appreciate if you could review my current auto insurance rates and see if there is potential for a reduction based on my age.

Furthermore, I would like to inform you that I will no longer require the existing apartment insurance policy I hold. My new apartment provides a comprehensive insurance cover, thus making the continuation of my current policy unnecessary.

Please let me know if you require any additional information or documentation to facilitate these changes. I am happy to provide them as needed.

I look forward to your prompt response confirming these updates.

Best regards,

Junhan