---
title: Record For daily Supplement
author: Junhan Hu
tags:
  - life
mathjax: true
categories:
  - MarkdownNotes
  - Life
date: 2023-05-06 17:01:00
---

## What

| Supplement           | Usage                    | Supplement Facts            |
| -------------------- | ------------------------ | --------------------------- |
| CoQ10                | (Fill out usage details) | (Fill out supplement facts) |
| Melatonin            | (Fill out usage details) | (Fill out supplement facts) |
| Magnesium            | (Fill out usage details) | (Fill out supplement facts) |
| Omega-3 Fish Oil     | (Fill out usage details) | (Fill out supplement facts) |
| One-Day Multivitamin | (Fill out usage details) | (Fill out supplement facts) |

