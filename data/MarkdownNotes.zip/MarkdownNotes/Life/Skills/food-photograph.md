---
title: Food Photography
author: Junhan Hu
tags:
  - skills
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Skills
date: 2023-05-01 20:27:00
---

## Basic

From chatGPT

1. Find area with natural light
2. Invest
   1. Sturdy tripod
   2. Artifical lighting
   3. Light Modifiers
   4. Background and surfaces
   5. Styling props
3. Organize the workspace
4. Learn and Practice
5. Portfolio
6. Network and Market

## Artifical Light

Type:

* Continuous light
* Strobe light or flash
* Speedlight

Color Temperature

* 5000-5500

CRI:

* Above 90 is desireable

> Choice: Godox SL60W

## Light Modifiers

To create different effects

* Softbox: to create diffused and soft lighting
* Reflector: add some light from different position and color

