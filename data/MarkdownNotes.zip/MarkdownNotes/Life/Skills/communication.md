---
title: Improve Communication Skills
author: Junhan Hu
tags:
  - skills
  - social
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Skills
date: 2022-06-04 11:29:00
---

## Compete and Cooperate

### 3 Principes

### How to Evaluate

### When to Compete or Cooperate

