---
title: How to Produce Music
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Skills
date: 2022-09-13 23:16:00
tags:
---

## Why

For me, I really not appreciate music that much, and I regard music as a mixture of sound wave.

But music can do effect our emotion, so I say "why not get hands dirty and produce something?"

## Learn

The basics from [youtube](https://www.youtube.com/watch?v=mYVFF-MTkOM)

Software:

1. DAW, digital audio workstation
   1. FL studio
   2. Albeton
   3. Just pick one and use it 



Hardware:

1. All in, time is the resource
2. Mini controller
   1. AKAI MK2 MINI
   2. M Audio
3. Studio headphone
   1. ATH-M50X/30X



## Knowledge Base

Music: complex yet widely recognized expression

Sound: vibration in the air, music is just a complex form of the vibration

Why: Human are attracted to **pattern** and **symmetries** 

All intervals are combination of **tones** and **semitones**

Most harmonious interval:

* Octave: A set of equally spaced notes
  * twice as the one before (frequency)
* Agree to each other (a simple ratio)
  * $2^{7/12}=1.5$ good
  * $2^{6/12}=1.414$ bad

Wave Shape:

* Sin, simple
* Square

