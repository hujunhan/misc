---
title: Office Health Tips
author: Junhan Hu
tags:
  - office
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Skills
date: 2022-10-26 16:40:00
---

## Intro

Common health problem

## Eye problem & Migraines

headache, dizziness, computer vision syndrome

Suggestion:

1. 20-20-20
2. Good lighting
3. Blue light blocking glasses
4. Adjust monitor

## Back, neck and shoulder

pain, stiff, spinal

Suggestion:

1. sit/stand
2. stretch break
3. good posture/chair 

## Carpal Tunnel

nerves, burning, pain

Suggestion:

1. Stretch wrist regularly
2. Ergonomically

## Lack of exercise & sleep

weight, heart, diabetes, lethargic

Suggestion:

1. move around
2. walk, jog, run
3. aim for 8-hours sleep

## Mental health

Anxiety, depression, isolation, ADHD

Suggestion:

1. One thing at a time
2. Enough sleep
3. Relaxation
4. Focus on the positive
5. Hobby