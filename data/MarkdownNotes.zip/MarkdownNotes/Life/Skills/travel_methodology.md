---
title: Travel Methodology
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Skills
date: 2022-09-15 01:02:00
tags:
---

## Why

To get more from a trip

Experience more authentic culture

## Where

Some places are easier to live like a local

### Budget

The cheaper, the better

The most famous cities are usually the most expensive

Biggest cost: Flight, use the travel reward card

Figure out a budget

Right before or after the "busy" season would be helpful

### What to do

City or wilderness? Night or daytime?

Follow your heart

Some cities are full of tourist, do some research

---

Friendly locals: ignore the stereotype, there are good and bad people everywhere

## Fit in

There are all kinds of thing you should not do, but in fact, you may not offend anyone.

Just be conscious of the people around

