---
title: 理发助手
author: Junhan Hu
tags:
  - skills
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Skills
date: 2023-01-02 22:06:00
---

## Goal

Create a haircut helper to reduce the time of haircut

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230102220652.png" alt="image-20230102220652682" style="zoom:33%;" />

Using a template trimmer to get hairstyle like the above state, the important part is the **back of head** since it's hard to trim the hair in that area. 

## Prototype

Type I: a fixed template that cover the back head area

![image-20230102221030466](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230102221030.png)

## Implementation

### Intuition 

Material: soft alumni string to shape my head, since the precise model is not that important, a 4 by 4 grid is used

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230102222227.png" alt="image-20230102222226998" style="zoom: 25%;" />

Then we need to digitalize the curve. Using iPad and modeling software would be a good idea

Software:

* Tried Shapr3D, a good modeler, but require pricy subscription
* Freecad

### Improvement 

In the last design, although the overall idea is pretty simple and straightforward, but the implementation and modeling is too hard. So in this version, I would try to simplify the design

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230104204255.png" alt="image-20230104204255368" style="zoom: 25%;" />

this way, I separate the hair cut region into 2 part, program each part

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230104204608.png" alt="image-20230104204608578" style="zoom:25%;" />

---

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230104222424.png" alt="image-20230104222424555" style="zoom:25%;" />

Tried control point and spline fit, doesn't work well. That lead to my 2nd attempt, the log curve

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230104224544.png" alt="image-20230104224543872" style="zoom:33%;" />

Well, it doesn't do well either

---

Let try $x^3$

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230104230705.png" alt="image-20230104230705207" style="zoom:33%;" />

Emm.. Still kind of werid.

---

Nevermind, lets do arc

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230104231534.png" alt="image-20230104231534596" style="zoom:33%;" />

Circle never let me down

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230105015721.png" alt="image-20230105015721033" style="zoom:50%;" />

Create the point cloud in open3d

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230105220445.png" alt="image-20230105220444788" style="zoom:33%;" />

However, 3d printer can NOT print point cloud straight, we need to generate the face and compute the stl file. Meshlab can do this job by using ball pivoting algorithm

## 3D Print

### V1.0

![IMG_7679 Large](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230131011018.jpeg)

* Problem: Can't gather hair
* Solution: remove the horizontal line and mimic the normal comb

### V1.1

![IMG_7680 Large](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230131011305.jpeg)

* Problem: can't control the hair clipper
* Solution: add guide for clipper

