---
title: Get Sponsored
author: Junhan Hu
tags:
  - marketing
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Skills
date: 2021-07-18 00:14:00
---

## Why Company Sponsor

Make their product known by customers

Build opportunities between people and sponsor

* In meaningful way
* Interesting

### How Sponsor

Type

* Experience, make people feel the product
* Media
* Cash
* ...

## Know the Audience

* Demographic
* Psychographic
* Preferred brands
* Coming purchases

The more data of audience, the better

### How to do

Talking to preferred company

Markert search thepriority

### Value of AUDIENCE

The value highly depend on your audience

* Who are they
* What they want
* Fair value

## After Event

Prove you did what you promised

Get feedback and do better next time