---
title: 图像后期流程优化
author: Junhan Hu
tags:
  - photograph
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Skills
date: 2022-09-15 22:33:00
---

## Why

为了更好的节省时间和优化后期的流程，避免重复文件

Input：一个文件夹，里面包含raw和jpg

Output: 一个文件夹，里面包含普通照片的heic和优秀照片的raw+heic

## How

之前的后期流程比较随意，现在更好的清理

1. 将照片分到两个文件夹（代码完成）
   1. raw
   2. jpg
2. 在jpg文件夹将照片分成两类（手动完成）
   1. good
   2. normal（全部转成heic）
3. 将raw文件中找到和good文件中同名的照片复制到good文件夹中（代码完成）
4. 后期good文件夹中的raw照片
   1. 如果没有good中的jpg好，直接jpg放到final中
   2. 如果比jpg好，输出heic到final中
5. 将normal和final放到合适的目录

## Code

