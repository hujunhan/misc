---
title: Photograph
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Skills
date: 2022-02-20 21:29:00
---
# Photography

> Photography means Writing with Lights

## Elements

Record of people and things. Photo serves as document or symbol?

Making photo rather than Taking

Well organized/composited photo

Learning photography is just like learning language/writing

### Shape

Syntax creates meaning, we arrange elements

Just 2D information

Use exposure to control what to emphasis

### Form

3D aspect info

lighting and shadowing

distortion information

Close-large, far-small

### Texture

Touch information

We need light/shadow to illustrate the texture

We should emphasis texture that people ignore in daily life

### Tone

Lightness and darkness

Based on the message we want to convey

> Meter: make the spot/overall image in **gray**

###  Line

We need to put element in a purpose

Visible/Implied

Vertical line $\to$ Solidity

Horizontal $\to$ from left to right (written language)

S-curve, radiant line, circular

### Pattern

**Repetition** of similar elements

Direction, leads to the emphasis things

Capture the simple memory

Find the difference in pattern

too simple $\to$ visual candy (bad)

### Color

Address color as elements

Visual weights

* contrast (avoid)
* similar

To achieve harmonious

## Composition

Visual weights

* someone interests in something
* we need to assess the element

**Goal: let the viewer look deeply to where I want them to**

NO.1: Human Being

Other things like

* strange shape
* contrast color
* strange texture
* size

### Balance

composition is a map,

* map has to be accurate
* viewer, the information want to convey

balance is bike riding

* shifting body parts to balance
* shifting the visual weight to balance

## Organizing

### Perspective

Perspective is a great tool to adjust visual weights

### Symmetry

bike ride straight ahead

visually identical/similar items, size, number, shape

### Asymmetry

engage more intellectually

**attention** is the key, how viewer see the image

like rule of thirds

## Content

### Portrait

**soft** light

fast shutter speed

F5.6-F8

Don't include too much background

goal: reveal something unique and striking

### Landscape

Striking position

largest F stop

### Still Life

Different angle

Lightning condition

### Tableau, Manipulated Landscape

recreating photo, dramtic

post-processing

## Light

### Color

Temperature

### Ambient Light

fill flash to avoid shadow

change your/subject position

light and color

### Controlled Light

Normal sunlight, cause least attention

Writing with light

If we want viewer to notice the light, we should make it abnormal

Most flash in 5500K-6000K,

Dedicated flash, 

### Shutter type

Focal plane shutter

Sync speed, means how long the flash would last

Slow sync: use the flash with lower shutter speed to make the background correctly exposured in night

## Studio Light

### Kitchen

Setup a lighting system to shoot

Lighting an object

* determine the goal for the object first
  * sell
    * show the characteristic
    * convey the message
* use extra light
