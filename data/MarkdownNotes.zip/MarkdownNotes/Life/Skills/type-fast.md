---
title: 提高打字速度
author: Junhan Hu
tags:
  - skill
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Skills
date: 2019-08-22 20:14:00
---

## 标准指法

[typingclub](https://www.typingclub.com)练习标准指法的网站，网站做的很好看，界面互动很优秀.

键盘上的`F`,`J`上面有一个横杠，这两个是用来定位的，将两只手的食指放在那两个键位上

主要思路是让手养成**肌肉记忆**，用最短的路径去拼写单词

* 多次、重复的练习

**我的经验：先在这个网站上学习标准指法，即各个按键应该用哪个手指按，大概是87课左右**

## 如何提高打字速度

[keybr](https://www.keybr.com/)一个练习打字的网站

这个网站提高打字速度的思路：

1. 先练习一些常用单词的拼写

1. keybr会记录拼写这些单词的时间来评估你的速度
2. 拼写更多更难的单词

