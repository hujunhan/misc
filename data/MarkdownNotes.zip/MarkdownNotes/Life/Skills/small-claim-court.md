---
title: File Small Court Claim Against Landlord
author: Junhan Hu
tags:
  - rental
  - justice
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Skills
date: 2023-07-08 12:23:00
---

## Intro

The apartment charge 2400 for painting

It's un-reasonable

## Process

1. **Determine Who to Sue**
2. **Send a Demand Letter (optional but recommended)**
3. **File Your Case**
4. **Serve the Defendant**
5. **Go to Court**
6. **Collect Your Money**

I hope this email finds you well.

In accordance with California Civil Code §1950.5, I am formally requesting the return of my security deposit that I believe has been improperly withheld following my vacating the premises at 833 W El Camino Real, Sunnyvale, CA on June 12, 2023.

Please find attached a letter detailing my concerns regarding an excessive $2400 charge for repainting the apartment, and the lack of an appropriately itemized statement describing the work performed, the time spent, and the reasonable hourly rate charged.

The letter outlines the steps I am prepared to take if we are unable to resolve this dispute, including pursuing a small claims action.

I am open to discussion in order to reach a fair resolution to this matter. I kindly ask you to review the attached letter and provide me with your feedback at your earliest convenience.

I appreciate your prompt attention to this matter.

Best regards,1