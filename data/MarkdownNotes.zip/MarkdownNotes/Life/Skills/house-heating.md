---
title: 房屋供暖方案研究
author: Junhan Hu
tags:
  - skills
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Skills
date: 2023-01-30 22:10:00
---

## 目标

研究排屋供暖方案

* 类型
* 原理
* 效果
* 成本

## 