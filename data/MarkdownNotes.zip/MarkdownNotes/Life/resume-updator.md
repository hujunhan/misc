---
author: Junhan Hu
tags:
  - life
mathjax: true
categories:
  - MarkdownNotes
  - Life
date: 2023-05-18 22:35:00
---

## Goal

Improve current resume

1. Define the guideline and limit
2. Transform current resume into markdown format
3. Add up-to-date info
4. Use ChatGPT to general a new general resume
5. Find a good template for exporting PDF

Later plan (target for specfic role) in the future

1. Extract the most important skills needed
2. Update accordingly

## Guidelines

[Ref](https://www.youtube.com/watch?v=Tt08KmFfIYQ)

* Include important keywords
* Measurable metrics
* 475-600 words
* Remove the buzzwords, cliches

## Reusme


