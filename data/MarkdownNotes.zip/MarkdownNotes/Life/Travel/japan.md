---
title: Japanese Travel
author: Junhan Hu
tags:
  - travel
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Travel
date: 2023-07-02 21:47:00
---

## Osaka

Restaurant of Japan

## Koyasan

Temple, Buddisim 

## Nara

Deer park

Temple

Mochi

## Kyoto

Ancient captial

Garden, river, temple dog

Ramen

Nishiki foods

## Kanazawa

little Kyoto

JR, bento box on the train

Museum

Tea culture

## Takayama

onsen

## Tokyo

Meiji Shrine

Harajuki, trend

Micro pig cafe

Crosswalk, Rooftop s

