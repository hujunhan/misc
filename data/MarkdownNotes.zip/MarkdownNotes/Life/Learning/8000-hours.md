---
title: 工作？
author: Junhan Hu
tags:
  - life
  - job
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Learning
date: 2022-06-09 23:38:00
---



## 8000-hours

## What to do?

* Good at
* Help others
* Good condition

## What impact?

Not only make difference, but make huge impact

Impact=Number X Level

## How to make differences

* Donations, $1 means more in Kenya than in USA
* political advocacy
* help others become more effective

## Find the focus area

* big in scale
  * use number to make comparisons
    * number of people
    * effects
    * long-run benefits
* neglected
  * affect neglected groups
  * few people know the problem
* solvable

## What's important?

* global health in poor country
* focusing on future generation
  * forecast the problem in the future

## How to help most

* Earning to give
* Advocacy, persuade a friend to give 
* Research, if top 10%, highest impact
* Direct work, find a effective organisation
* Entrepreneurship

Find the career

1. decide the problem
2. read profile, read career ideas
3. go through the 4 approuch

## Change

https://www.bbc.com/worklife/article/20190718-the-101-people-ideas-and-things-changing-how-we-work-today

