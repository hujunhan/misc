---
title: 美国税法
author: Junhan Hu
tags:
  - skill
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Learning
date: 2022-04-15 14:47:00
---

## Intro

IRS——internal revenue service， tax collection agency

Tax return——tax form sent to IRS

W-2——tax form from employer

1042-s——tax from unversity

## Tax Residency

different residency determines which form you need

F1-Non-resident alien (within 5 calendar year)

## Tax Forms

May receive if you have income

* Main-W-2, employer in US, document the **wages**

1099-MISC: independent contractor

1099-INT： bank

## Federal Tax Return

1. receive the W2 and ...
2. Prepare the tax return
3. Print and mail to IRS, send it by April 15

## State Tax Return

Two reason：

* made more than some money
* To get some money back