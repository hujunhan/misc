---
title: Cheese
author: Junhan Hu
tags:
  - learning
mathjax: false
categories:
  - MarkdownNotes
  - Life
  - Learning
date: 2023-06-25 14:44:00
---

## History

Fresh milk become sour

could be stored easily

Different milk and different process produce different cheese

Now: 22,000,000,000 KGs cheese every year

## Types

[Ref](https://www.youtube.com/watch?v=f25Yqm2ugpU)

Cheesemonger: expert on cheese

Cheese board

* milk type
  * cow
  * goat
  * sheep
  * bufflo
  * blend
* texture
  * soft
  * medium
  * hard
* color

## Classic Cheese

[Ref](https://www.youtube.com/watch?v=Jwu-7wFc4-E)

1. Mozzarella
   1. Italy
   2. Cow
   3. served with tomato
   4. inexpensive
2. Feta
   1. Greek
   2. Sheep
   3. Salty
   4. served with salad
3. Crottin de Chavignol
   1. France
   2. Goat
   3. Soft
4. Blue Cheese
   1. Blue mold

## Cheese Knowledge

[Ref](https://www.youtube.com/watch?v=3-PfywiJBPI)

Milk: whey + curd

Whey: use acid, build the Ricotta

Curd

1. Salty water: Feta
2. Hot water and stretch: Mozzarella
3. Clean and compress: Gouda, Jack
4. (Ferment) Blue cheese: Blue, camembert, brie
5. (Ferment+compress) Cheddar, comte, parmesan

## Tried

![IMG_0617 Large](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230625204032_SNc3rR.jpeg)

* Feta
* Gouda
* Brie
* Blue
* Goat
* Ricotta