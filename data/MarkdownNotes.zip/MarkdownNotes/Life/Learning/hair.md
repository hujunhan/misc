---
title: 人类毛发疑惑
author: Junhan Hu
tags:
  - hair
mathjax: false
categories:
  - MarkdownNotes
  - Life
  - Learning
date: 2023-03-07 00:15:00
---

## 问题

* 为什么头发没有在进化过程中减少
* 为什么头发会一直生长而其他毛发不会

## 头发？

头发比较重要

* 保护，吸收紫外线
* 维持体温，大脑比较重要，且散热较多
* 社交信号

## 生长？

生物结构不一样

* 头皮的毛囊更大，生长周期较长
* 其他部位毛发生长数月，就会停止生长

