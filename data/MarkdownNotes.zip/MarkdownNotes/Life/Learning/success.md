---
title: Review of How to Be Successful
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Learning
date: 2023-07-23 13:59:00
---

## Intro

In the past few month, I use ChatGPT intensively, the CEO of OpenAI is Sam Altman, he wrote a blog called 「How to be successful」, today I wanna look at it and see what I can learn from

## Content

[Ref](https://blog.samaltman.com/how-to-be-successful)

For Altman, the definition of success is

* Make huge amount of money
* Create something important

Tips

1. Compound yourself
   1. Rate of learning should be high
2. Self-belief
   1. Trust yourself more
   2. Balance with self-awareness
3. Think independently
   1. Get original idea
   2. Find easy, fast ways to test these ideas
4. Get good at 'sales'
   1. convince other people of what you believe
   2. Show up in person whenever its important
5. Take risk
   1. Its impossible to be right all the time
   2. Human nature, prioritize short-term gain
6. Focus
   1. Much more important to work on the right thing
7. Work hard
   1. do it at the begining of your career
8. Be bold
   1. people want to be part of something exciting and feel the work matters
   2. Follow your curiosity
9. Be willful
   1. people have the power to change the world
10. Be hard to compete with
    1. do what others can't
       1. personal relationships
       2. strong personal brand
       3. good at intersection of multiple different fields
11. Build a network
    1. the size of network become the limiter for what you can accomplish
12. Get rich by owning things
    1. don't sell time
13. Be internally driven

