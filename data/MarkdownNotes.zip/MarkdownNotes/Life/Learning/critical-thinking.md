---
title: Note for Asking the Right Questions A Guide to Critical Thinking
author: Junhan Hu
tags:
  - book
  - reading
mathjax: false
categories:
  - MarkdownNotes
  - Life
  - Learning
date: 2023-02-16 21:19:00
---

## Intro

Learn the book Asking the Right Questions: A Guide to Critical Thinking by Neil Browne.

I would use ChatGPT to assist my reading. All the info is generated from ChatGPT, I would ask more detailed question to ChatGPT and examine the answer quality

## Outline

> ChatGPT first gives the outline of the book and summarize each chapter

### Base

1. Importance of critical thinking and questioning process

   From unknown to known, using current knowledge to get a better answer

2. Issue and Conclusion, important step, make the problem more clear

   Issue: the central problem

   Conclusion: assertion being made about the issue

3. Reasons: evidence and facts

   Important to evaluate 

   * Relevance
   * Sufficiency
   * Accuracy

4. Assumption: belief, values and attitude

   * often unstated / implicit
   * casue different conclusion
   * We should try to know the assumption made by author

5. Fallacies: common errors that weaken the argument

   * ad nominem: attack person
   * Apeal to authority
   * False dilemma: e.g. only show limited options
   * Hasty generalization: based on insufficient evidence
   * Slippery slope: argue action would lead to negative consequences without providing evidence
   * Straw man: misrepresenting to make it easier to attack

### Tips

1. How good is evidence: how to evaluate the quality of evidence
   1. Source credibility
   2. Relevance
   3. Sufficiency
   4. Timelines
   5. Consistency
   6. Use of qualifiers
2. Alternative intrerpolation: considering alternative interpretations
3. Implications
4. How to resolve the conflicts
5. Further

## Takeaway

From this books' perspective

* Issue and conclusion should be made by human
* ChatGPT can/can't provide

  * Highly **relevant** knowledge: better than google
  * Medium **sufficiency** knowledge: less than google
  * LACK OF: **accuracy**(no source provided) **timelines** (when is source made), **consistency** (maybe try multiple times),

* Common fallacies ChatGPT may occur
  * False dilemma: only show limited options
  * Hasty generalization: make conclusion based on insufficient evidence

