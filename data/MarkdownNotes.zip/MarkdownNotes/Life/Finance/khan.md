---
title: Personal Finance
author: Junhan Hu
tags:
  - skills
  - finance
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Finance
date: 2022-08-22 20:32:00
---

## Saving

Live below your means, look what you earn

Should I spend money on something?  optimize the freedom money get rather than the money itself

New grads? save money for what you want

How much should spend?

---

Marriage? Different styles

Kids, how money works, how things work,

College, consider the growth of tuition and investment

---

Monthly bills

* Mortgage
* Utilities
* Insurance
* Car loan

## Interest and Debt

Rule of 72: (very good approximation)

* if APY is 10%, the money would double in 72/10=7.2 years
* if APY is 6%, the money would double in 72/6=12 years

---

Federal Reserve control the interest rate to contrl the economy

* Low rate: more shopping, more job
* High rate: less shopping,

---

Credit: FICO, give a score of creadit

Three credit bureaus

* Transunion
* Experum
* Equifax

---

Interest in credit card

calculate the average daily balance

* if you pay off, no interest
* if there is balance left, you pay below

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-23-20-27-15.png" alt="image-20220823202715420" style="zoom:33%;" />

> Build credit, use chime and pya

---

Processors，each processor have bank in network

* Visa
* Mastercard
* Amex
* Discover

Store should be in the same network to receive the money from the same network 

Each payer is providing services, like 2% to the bank

---

Bankruptcy: if you can't pay back

* Ancient Greece, become the debt slave
* In prison, family pay off
* Bankruptcy 
  * Chapter 7: straight, stay on credit report for 10 years, some loan are never forgiven
  * Chapter 13: reorganization, pay in the next 3-5 years, stay on 

## Investment

Retirements

* Traditional IRA, gain interest in a larger base. Only taxed when withdraw
  * Best if you withdraw after age 60
* Roth IRA，tax not deferred. NO TAX when withdraw
  * Best if you withdraw before 60, need more flexible
  * And if you in higher tax bracket in retirement
* 401K，very similar to Traditional IRA，pay income tax on total distribution
  * Higher limit
  * Organized by employer

Penalty: 10%

Different company have different 401K policy. When change job

* to IRA
* to new 401K
* stay in old 401K

---

Open-ended and Close-ended mutual fund

* Open: can create new share
* Closed: only trade existing share

Exchange Traded Funds: more flexible

Ponzi Scheme: **more in than out**

----

Stock: part owner of company, money isn't guaranteed

Bond: part lender to the company, company pay interest and pay off principle

Asserts: Thins can be in cash

Asserts=Liabilities + equity

fair price should be equity/(share numbers)

Cap=current price * (share numbers)

## Income

See paycheck

How allowance works

## Housing

Rent Vs Buy

Buy: **stability**

* Down payment
* Interest
* prop tax
* house keeping

Rent: **flexibility**

* gain interest

Consider the out of pocket money,

* Consider how much **money burn in every year** if you buy or rent

---

Loan: the longer, the more risky

---

Short sale

Ballon payment, share the risk between buyer and bank

---

How to solve
$$
((L(1+i)-P)(1+i)-P)...=0
$$
Solve P
$$
P=L(\frac{1-r}{r-r^{n+1}})
$$
where $r=\frac{1}{1+i}$

---

Title of the house? Called deeds

## Car

## Taxes

