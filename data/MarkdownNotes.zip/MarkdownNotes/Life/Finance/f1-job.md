---
title: F1 Visa Job
author: Junhan Hu
tags:
  - skills
  - finance
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Finance
date: 2022-10-25 23:59:00
---

## Intro

Current status:

* F1 Visa
* OPT

Multiple Job: 

* F1 still could do multiple job
* How to add a new employer
* How many jobs can you do? at least 20 hours per week for each employer

