---
title: Career Planning
author: Junhan Hu
tags:
  - life
  - job
mathjax: true
categories:
  - MarkdownNotes
  - Life
date: 2022-06-10 0:07:00
---

## Philosophy for the future (with Purpose)

Design the future career

Do the work help others

Don't waste time and keep learning

## Career Exploration

How to shape the career path?

The world is changing soon, so the career path is changing

* aware of the possibilities
* signup project outside fields
* become a subject matter experts in important area
* emotional resistence 

Ask yourself, what is the driven and can you resist when face hard situation

* can be paid for
* what you love
* what you good at
* what the world need

Transferable skills

* leadership
* interperson

## Technique for career exploration

1. Design thinking, choose the value you value most
2. Big 5 model
3. Make plan
   1. Current, long-term decision
   2. Next, alternative
   3. Final, worst case 

What's really important? Confidence and Reputation

## Softskills

### Networking

* future contacts
* different information
* How
  * overcome the anxiety
  * Integrate new experience
  * Positive, smile and curious

### Character flaws, personal imperfections

* unstable emotional status
* Develop more self-awareness
* Get feedback

### Changing career

discipline

confidence

transferable skills

* Know some tools
* Tools in useful in new career
* Know how to apply in new career

---

mid-career crisis

## Communication

### Digital profile

Linkedin

* passive candidate
* Professional photo
* Headline contain important information
* Summary, unique, credential
  * action, outcome

### Resume

## Adapt

work is more virtual

### Essential Skill

Cultural Frequency

* personal 
* organizational

---

* Work smarter than harder
* Understand Banter
* Articulate goals
* Find allies and mentor

### Stand Out

* show up
  * Start a blog
  * Publish articles on Medium
  * Publish in publication
* Add value
  * more efficient
  * save/earn money
* Fix problem

### Personal Branding

Using your strength

Show the value



