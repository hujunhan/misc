---
title: Vision for a Better World
author: Junhan Hu
tags:
  - life
  - world
mathjax: true
categories:
  - MarkdownNotes
  - Life
date: 2023-07-22 14:10:00
---

## Vision For a Better World

How to do that (in general)? Find how current world behave bad, (not ideal from my view). fix it

Example:

* People do too much work or thing for a living, so they don't have time for thins they really enjoy
* Imbalance of wealth
* Unfair between people, power uneven distribution
* Environmental issue

How to solve the problem?

1. Robot and Artificial Intelligence should operate the main thing (physical and digital world). For example, the farms, power plant, and other facilities
2. Push the governments distribute enough wealth to everyone

Main Issue

* The selfish nature of human being, make it hard to achieve real equal and fair
* While pushing robot to replace human worker, there would be unemployment issue before the productivity achieve new stage

Practical Step

* Promoting automation
  * re-skilling and education
  * regulation and safety
* Weath distribution
  * Fair Taxation
  * Encourage social entrepreneurship
* Fairness
  * Transparency
  * Access to opportunities
* Environmental Issue
  * Sustainable pracitices
  * Influence Policy

##  Politics Changer

Goal: Push government treat people well

Original plan:

1. re-build the system
2. Take a good example
3. For unfair nation, take act for forced fair
4. Apply success template, new tech

New plan:

1. Build Awareness: inform and educate public
2. Collect data and conduct research
3. Lobbying: network of influencers
4. Policy proposal
5. Public pressure

## Robot-wise Helper

Goal: Build all kinds of robots, mainly two part

1. Physical Robot: run in the real world. Help people do physical work, like in the factory, farms etc
2. Software Robot: run in the digital world, help people make decision and keep everything in record, from automation work to AI technology

### Physical Robot

How: work in seperate workspace / collaborative robots, safety issue

What: mainly work in production area

* Agriculture
* Construction
* Farming
* Facilities..

Chanllenge

* Un-predictable environment
* Movement: Need to build all kind of movement base to work on different terrian
* Task operation: Currently most jobs are done by human, so human hand is no-doubt the best option, however, it's too difficult to build. May need to design a set of task gripper

### Software Robot

How: work in digital world, work with human in every single day and way

What: mainly work in life experience area and keep system working

* Aritifical Intelligence for better decision making
* Recommendatio
* Health

Challenge

* Privacy issue

* System: how to connect everything and make it aware of other software robot, API stantard

* Power, it may require very intensive computation resources and electrical power, how to do that on edge device. cloud computing

  