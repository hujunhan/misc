---
title: 近期思考&读书笔记
author: Junhan Hu
tags:
  - life
mathjax: true
categories:
  - MarkdownNotes
  - Life
date: 2021-06-27 02:46:00
---

## 人生目标？

人这一生到底要做什么

为什么

目前情况怎么样

怎么做

## What really matters

快乐主义：Hedonism

Pleasure is the only direct good, Pain is the only direct bad

萨特：

* 对人类来说，先有存在，然后再有目的
  * 我们的目的由自己定义
* 对于物品来说，先有目的，然后再存在

Susan Wolf:

* Meaningful lives are lives of active engagement in projects of worth
  * Active engagement: 要感兴趣
  * Projects of worth：科学研究、政治、与他人建立联系
* 我们的价值判断和文化息息相关

## What should We do

### Act consequentialism

* To do the thing that maximize the aggregate **good**
* Act utilitarianism
  * To do the thing maximize the aggregate **utility**

Objection：

1. 对于我们的亲戚朋友，utility有什么特殊吗
   * Easy to help

### Rule consequentialism

* The optimific moral code is that system of rules would produces the best **consequences**
* Rule utilitarianism
  * system of rules that produces the best utility

### Kant

Kant's universalization test:

* A maxim that **everyone** can follow, then the action followed the maxim is moral worthy.

Kant's humanity formula:

* Human=things+humanity
  * Humanity=The ability to choose a goal and take rational steps to pursuit it.

## 如何过好这一生

What makes a good life? 是什么让人健康和快乐

> 从哈佛的人生研究

良好的人际关系让人健康和快乐

* 社会关系让我们更健康
* 良好亲密的婚姻关系
* 主动与他人交往

## 人类简史

人类如何从动物到人，我们有什么与众不同之处呢？

人类和动物的区别不在个体上，而是群体上。群体之间的大型合作 

虽然人之间互相不认识，但是能够进行思想交流

那么我们是如何做到的呢？**想象力**

* 我们能创造并相信虚构的故事
* 我们遵循着相同的价值观和行事准则

宗教、法律、人权、上帝、天堂、国家、家族、公司、钱，这些概念都不是客观事实，只是一个故事。只要大家都相信着同样的故事，事情就能开始运作。

Everyone believe MONEY

人类生存在双重现实中

随着电脑和生产力的发展，我们还需要那么多人做什么？

## 未来简史

 在数据时代，人的意义到底是什么？

人类要解决的问题和新的追求

* 饥荒、瘟疫、战争
* 神性

随着科技的发展，人文主义成了新的宗教，自由意志是新的神。

为什么我们需要一种理论来解释发生的一切。

人的行为=想象+现实

## 新的问题

随着技术的发展，新技术对于不同的人来说意味着不同的后果，我们需要新的哲学和伦理来指导

### 自由意志

当大数据比我们自己更了解我们自己之后，我们还有自己的欲望吗

* 前叶被切除、肿瘤
* 毒品
* 酒瘾
* 吃饭等基本欲望
* 人类的基本心理学
  * 人倾向于做出容易的选择

我们能控制哪些东西呢？

* Desire？对某些东西的喜好、厌恶。短时间内不能变化，但是能在通过一段时间的训练之后改变
* Emotion？几乎不能控制
* Physiology？激素分泌等，也几乎不能控制。
* Belief？也是一个长期的过程，在短时间内几乎无法改变

什么是自由意志？

1. 我们有几个可选的选择
2. 我们能够选择其中的一项
3. 我们对其后果负责

随机性并不能保证我们的自由意志，正因为随机性，所以我们的选择是out of control的，所以2和3就不成立了

### 平均水平

有效率本身就是一件符合伦理的事？

集权国家，效率高，但是符合伦理？

比如说用AI面试，做一些决策，比人做的更好

## 下一阶段的实习做什么

- [ ] 如何首先选取Top30个特征点
- [ ] 已知深度图、3d点云、模型，分割出深度图
- [ ] 延迟，视觉算法，超前控制，用过去时间的信息来判断后续的算法
- [ ] 机械臂末端增加实时传感器，

## 道德话题

### 贫富差距

除了维持基本生活需要的金钱之外，是否应该将其他的所有钱捐赠给贫穷的人

* 从整个社会的角度来看，只要每个发达国家的人都能捐献出一些钱，每年$170，就可以解决全世界的贫穷问题，但是问题是当大部分人不进行这个捐献的动作，那对少数人就造成了极大的压力
* 也阔以是捐献出一部分

### 素食主义

