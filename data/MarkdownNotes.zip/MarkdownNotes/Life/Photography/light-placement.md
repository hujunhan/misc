---
title: Light Placement Course
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Photography
date: 2023-05-04 22:10:00
---

## Why

People are more happy to see usual pattern light

So there is "good" light placement

* natural

Differnt light could achieve different purpose

Type

* Key light
* Fill light
* Effect light
* Background light

## Exposure

Ambient exposure

Flash exposure

### Eliminating Ambient light

Use the exposure, eliminate the light into the camera

Control the unwanted light

The dimmer environment, the more flexible camera setting you would have

---

### Incorporating ambient light

Use ambient light for 

* highlight area
* background

## Single Light Setup

### Hardlight

For bright sunny emotion, use overhead light

> Note: the tone of the surface would affect the total exposure level

Use flash with modifiers

* for hard light, use the reflector or direct

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230511000341_Ei4VXk.png" alt="image-20230511000341659" style="zoom:33%;" />

### Softlight

With a large softbox 

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230511001028_GxK6zJ.png" alt="image-20230511001027941" style="zoom:33%;" />

light direction would dramatic change the overall feels

## Two Light Setup

When the lens is close to the object, it may seems not flat

* distorted

Finish the image step by step, from a simple image, simply fix the problem you don't lilke

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230512003356_7Fgp4G.png" alt="image-20230512003356170" style="zoom:33%;" />

Set one light at each time.

* first set up the environment light
* then set the key light

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230512004120_EZVm6V.png" alt="image-20230512004120840" style="zoom:33%;" />

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230512004142_kG2iEg.png" alt="image-20230512004142803" style="zoom:33%;" />

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230512004413_Cw5qnd.png" alt="image-20230512004413395" style="zoom:33%;" />

## Three Light

 ![image-20230517222515202](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230517222515_vNFmkU.png)

subject Analysis, walk around to find the best lighting angle or shoot angel

## Four Light

![image-20230517230542203](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230517230542_y3psC1.png)
