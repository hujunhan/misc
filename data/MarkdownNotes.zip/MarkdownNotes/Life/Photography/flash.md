---
title: Off Camera Flash
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Photography
date: 2023-05-07 15:06:00
---

## What to Buy?

* basic fundamentals of lighting
* fundamental of off-camera flash
* lighting for your work

## Flash Duration

With natutal light

* High speed shutter to capture the motion
* for splash, 1/1000s is needed

While with the flash speed

* Maybe 1/40s is good enough
* The flash duration capture the motion
* shutter speed is irrelavant

The higher power, the longer flash duration

So to capture splash, use low flash output power

## Sync Speed

The max speed camera can set to work properly with flash

> Why limit? since In high shutter speed, the shutter should not fully open, so ther would be a dark area

Shoot as max sync speed

## Flash Power

The more powerful, the more control you have on the depth of field

For flash, the power if linear

![image-20230507161501491](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230507161501_G0cyyj.png)

