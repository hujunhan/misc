---
title: Composition
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Photography
date: 2023-05-02 20:35:00
---

## Definition and Different Space

Arrangement of Space

* **Active Space**: area you want the viewer to focus
* **Negative Space**: area around the subject   

Pose with different position to make different feeling

* To make static, stability, at rest

  * **Passive Space**: centered and surrounded by elements
  * eye at rest

* To make dynamic, attract
  * **Active Space**: not centered, something about to happen

## Figure Ground

Figure: visual dominant

Ground: surrouding areas 

---

Area of greatest contrast

* human would be attracted to greatest contrast area

---

Value: brightness

---

So how to make a figure:

* more contrast
* more bright   

## How We See Light

1. Area of greatest contrast
2. Saturated color
3. Texture and pattern
   1. something not usual in daily life



