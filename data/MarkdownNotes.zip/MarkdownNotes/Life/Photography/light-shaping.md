---
title: Control the Shape of Lighting
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Photography
date: 2023-05-08 22:37:00
---

## Stand

* Tranditional Stand
* C Stand

For C stand, get some stand bag for more steady envrionment

## Adapters

grip, clamp, adapter

* to work with C stand and attach all kinds of light/modifiers

try to avoid very specific usage tool

Plastic clamps: [https://amzn.to/3gUd8Ul ](https://amzn.to/3gUd8Ul)  

Metal clamps (with rubber grip): [https://amzn.to/3p2iAY2   ](https://amzn.to/3p2iAY2)

C-Stand Grip Head (Neewer): https://amzn.to/34llyzc   

Reflector Disc Holder (set of 3): https://amzn.to/3oStwHM   

C-clamp Grip: https://amzn.to/2Wmfjqn   

^ Clip to attach: https://amzn.to/3mrRTdV   

Supergrip with Adjustable Handle: https://amzn.to/3rbGoej   

##  Modifiers

Softbox mainly make the flash larger

![image-20230508230826709](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230508230826_x0mELD.png)

Using grid, snoots, GOBOs

Looking for the right mount system

Magbox (with Magmod system): [https://amzn.to/2WmBNYm ](https://amzn.to/2WmBNYm)

Pro Studio 4ft Softbox (I have the 3ft version, but could not find it on Amazon): [https://amzn.to/34jCyWl ](https://amzn.to/34jCyWl)  

Phottek Softlighter (Umbrella): https://amzn.to/37otmC4   

Westcott 7tf Umbrella: https://amzn.to/37rBxNS   

Magmod Basic Kit: https://amzn.to/2KbjDq2   

Magmod Snoot: https://amzn.to/2Woayg8   

Godox Snoot:  https://amzn.to/38eXxe6   

## Flags & Fill Cards

Control light is the key skills

3 main way

* cutting or shaping

  * block light

    ![image-20230508231706875](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230508231706_sFQiMA.png)

* reducing

  * negative fill

* adding 

  * positive fill

  * serve as a new light source

    ![image-20230508232348849](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230508232348_30jU8Q.png)

Foam boards: [https://amzn.to/3r5BW0w ](https://amzn.to/3r5BW0w)  

Tri-fold boards: [https://amzn.to/3oWKaWQ   ](https://amzn.to/3oWKaWQ)

Godox SA-17: https://amzn.to/3mrVRDl  

## Diffusion & Reflector

diffusion roll?

* more smooth, creamy, and natural
* no cross light

![image-20230508232812878](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230508232812_v27QcB.png)

Reflector

Mirror is a great tool for product photography

