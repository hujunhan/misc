---
title: Food Photograph Tips
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Photography
date: 2023-05-04 21:41:00
---

## Light and Emotion

Direct light help feel healthier

Diffuse make people pale even ill

Light could provoke emotion

1. Brightness
2. Color
3. Contrast
4. Direction
   1. Natural
   2. Contribute to the mood



For food: capture more texture

* back light
* side light

## Course

Focus on

* bringing out the artist in your

Feel the weight of improvements

1. Foundation
2. Light
3. Idea
4. Gear

## Being a Artist

Thouhgt process to lead the final result

Sometimes you would feel stress or upset when things goes wrong

* talk to someone
* take a break

## Hidden Power

While shooting, we are also exploring the hidden self

Apply the principle and make you own

## Four Mindsets

Both photographer and artist

1. Build for self
2. Confidence
3. Comitment
4. Be playful



