---
title: Lighting Foundation
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Photography
date: 2023-05-05 19:51:00
---

## Definition

What light does

* Dimension

  * the shadow make it more 3D
  * ![image-20230505195632329](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230505195632_rIFfrM.png)

* Sepatation: between subject and background

  * ![image-20230505195548452](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230505195548_RyN3Yc.png)

* Texture: how can we convey the feeling of texture

  * ![image-20230505200114478](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230505200114_6sbLqJ.png)
  * back lit might help 
  
* Emotion
  
  * convey motion
  * reminds someone of a certain food, memory, 
  
  

## Why REACT strongly to Light

Psychological hard-wiring

Personal experience

* bright cold for morning
* dim warm for sunset
* ![Color temperature variation throughout a single day | Download Scientific  Diagram](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230505201218_sZbo9D.png)



## Zone System

What makes a photo stand out?

* A map describe different shades of color gray

![image-20230505202011720](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230505202011_FNI1H5.png)

Expose the shadow, develop for the highlight for **film**

For digital camera:

* Shoot for highlight
* Develop the shadow

Make more tone variation in a single image

1. Turn RGB to B&W
2. Tune the tone
3. Go back to RGB
4. Fine tune

## Light Fall off

Fall over distance's square

* Close to light
  * more contrast 
* Far from light
  * more flat

## Light Quality

* Transition between highlight and shadow

* Surface the light is interacting with

### Hard and soft light

| Hard                                                         | Soft                                                         |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| ![image-20230505210309643](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230505210309_oXV0mi.png) | ![image-20230505210334308](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230505210334_cqGTzJ.png) |

How to control?

* Size of light (distance to the object)
  * Bigger size (closer) -- Softer
  * Smaller size (farer) -- Harder

### Diffused and Specular

Depend on the subject **material**

## Reflection

Use reflective light to create more interesting scene 

* Absorb light

* Refection

* Diffuser

  ![image-20230505211852514](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230505211852_ZetUsG.png)

![image-20230505212230029](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230505212230_oGuMDV.png)

## Color of Light

Color temperature measure the COLOR of light

![image-20230505212854001](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230505212854_w6bzPn.png)

* Blur hour? ozon layer and flat angle [Ref](https://www.photocourse.info/the-blue-hour.php)
* During day? Rayleigh Scattering of sunlight
* Sunset/Sunrise? The angle of perception [Ref](https://www.clickondetroit.com/weather-center/2018/12/10/whats-up-what-determines-the-colors-of-the-sky-at-sunrise-and-sunset/)

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230505214012_mGtbcD.jpg)

### White Balance

Tell the camera how to determine the white

So it's a inverse process

* E.g. setting 3200K means we want 3200K to be white
  * since 3200K color is warm
  * We are making the whole scene cooler

## Assignment

### 3 Key Character 

1. Area of greatest contrast
2. Saturated color
3. Texture and pattern

---

Though process

1. To make greatest contrast: the subject and background should have large color difference
2. Saturated color: the subject should have stand out color 
3. Texture: the light should lit the texture of subject 

I choose salmon as my subject since its saturaed color. At beginning I use white background but find the image looks too flat and cheap maybe because the background's brightness is too high, so I change the background to dark and the image seems more classy.

The light I am using is a continous light, from side, I hope the light can make the texture of the salmon more obvious. 

The camera setting for the final image is at 70mm, f/9.0, 1/50s, iso 640. It seems the orange slice is still out of the focus, I guess for smaller aperture, I could get better results?

### 4 Usage of Light

1. Separate
2. Dimension
3. Texture
4. Emotion

Though process:

1. To make separate subject, the background and subject should have enough brightness difference, so the light should be focus rather than diffuse
2. To demonstrate the dimenstion of subject, we should create shadow for the 
3. As for texture, the subject's surface should have obvious texture
4. I am struggle with the emotion, don't know how to design the emotion

For the image, I don't know how to choose the right backdrop. For the dark backdrop, the image somehow more harmony, while the white backdrop makes the image more "fresh"

Besides, I am using f/16 to shoot however the depth of field is still not enough to include all 3 part of orange, so I use focus stacking. The following open source software give quit decent result

[PetteriAimonen/focus-stack: Fast and easy focus stacking (github.com)](https://github.com/PetteriAimonen/focus-stack)

### Fall of Light

I just take two simple shots to test this.

The difference is obvious

* when light is close, the contrast of the image is obvious higher
* when light is far away, the image is more flat, the overall tone is also changed

### Light Quality

Before the course, I was thinking the specular and diffuse quality are solely depend on the light source, but now I understand the texture of the subject could be "changed" to deliver certain feeling
