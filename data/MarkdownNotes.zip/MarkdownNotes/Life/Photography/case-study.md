---
title: Case Study for Product Photograph
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Photography
date: 2023-05-17 23:08:00
---

## Product Shoot

![image-20230517232401844](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230517232401_LZUOSS.png)

day light

shadow

## Fruit Smoothies