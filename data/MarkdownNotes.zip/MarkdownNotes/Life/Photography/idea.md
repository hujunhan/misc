---
title: Photography Idea Generation
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Life
  - Photography
date: 2023-05-06 15:44:00
---

## Consistently

Brief: client key words

Creativity is a skills

Idea based on individual's experience



Steps

1. Brainstorm, there are no bad idea
   1. write down
   2. give stupid idea a chance

## Light or Food?

Goal: make the food look good

* show the texture?
* show some feeling you want to make the food look 

So: light is work for food

## Gather Images

Mood board? Visual organization

* set idea in motion
* ease the feeling of overwhelm
* Help make vision clear

Where to?

* Pinterest
  * save the image attract your attention
  * Mood board
* Instagram
  * Collection

## Building Treatment

Putting everything together

* color palette
* props
* lighting setup

4 Core element

* subject analysis
  * color
  * texture
  * taste
* Story or content
* color palette
  * complementary
* lighting

 It would save time

## Finalizing

## Assignment

To come up with a great idea

### Brainstorming

Take some time for it, especially sometime you are more creative

> > ***Hello! I own an orange juice company. I sell organic, fresh orange juice. It's family-owned and we juice our oranges by hand. I'm looking for an image that can really stand out and that really speaks to the fact that we juice our oranges by hand. I will be posting this to our Instagram page where we have a very loyal following. I'd love it to have a very bright, yet muted color palette and also a very minimalistic feel to it, but also isn't very "punchy" or crunchy looking. It'd be great if the lighting was a little bit more pleasant, but also really helps the image stand out. Again, we're family-owned and want this to have a welcoming vibe to it.\***
> >
> > ***I'm sorry I don't speak very good photography lingo! but I hope you can take my description and create something amazing for us. I'll trust your creative direction and am looking forward to seeing what you create!\***
> >
> > ***Thank you!\***

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230513175935_j8xjno.jpg" alt="image-20230513175934973" style="zoom:25%;" />

### Analysis

Considering the nature of the subject

* let it guide the lighting decision

Describe the elements of the subject

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230513181303_REprzg.jpeg" alt="IMG_9811" style="zoom:33%;" />

what kind of orange juice I would like?

* with pulp. clear orange juice seems so industrial 
* a little red-ish color, seems more flavorful

Container:

* clear glass cup



### Moodboard

visual literacy: find, interpret, evaluate, use, create images

* ability to create more meaningful and incredible images

How? Be a person looks at a lot of images

Understand what works and what not, apply the knowledge into your shoot

Hwo to read and breakdown images

1. Gather image
2. Analyze, contextualize
3. Curate and Assemble

![image-20230514113010960](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230514113011_a07OiW.png)

### Treatment

Presenting 4 fundamental aspects of idea

* Concept, story. Describe the scene of the image
* Color Palette, the overall color
* Props, 
* Lighting,  emotion

