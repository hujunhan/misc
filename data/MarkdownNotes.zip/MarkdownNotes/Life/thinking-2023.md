---
title: 近期思考
author: Junhan Hu
tags:
  - life
mathjax: true
categories:
  - MarkdownNotes
  - Life
date: 2023-05-14 16:19:00
---

## 改变世界

如何缩小贫富差距，作为大众

* 教育
* 投票
* 捐赠

如何实现平等

什么是平等

* 朴素平等
* 幸福平等
* 资源平等
* 机会平等
* 能力平等

## 职业发展

是否要跳槽

身份问题如何解决？

* 职业移民EB2/3
  * PERM
  * I-460
  * I-485
* 在I-140获批之后可以获得PD
* 需要多久？一年半左右

## 食物摄影

要作为赚钱的手段吗

## 创业

* 教育
* 养老机器人
* 食物摄影

## 计划

1. Update resume
2. Update Linkedin profile

