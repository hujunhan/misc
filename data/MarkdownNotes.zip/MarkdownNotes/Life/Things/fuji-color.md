---
title: 富士胶片模拟研究
author: Junhan Hu
tags:
  - camera
  - photography
mathjax: false
categories:
  - MarkdownNotes
  - Life
  - Things
date: 2022-08-05 23:59:00
---

## Why

最近出掉了用了大半年的Fujifilm X-S10，主要原因是对画质不太满意，ISO一高画面显得很糊

购入了Nikon Z5，对画质很满意，但是直出颜色远不及富士，所以研究一下富士色彩

硬件上，富士采用的CFA是X-Trans排列，尼康是非常常见的Bayer排列，不过理论上通过合适的插值，得到的RGB图像应该是差不多的

软件上，富士有看家的胶片模拟，尼康的色彩预设一言难尽。

## 胶片模拟

在用X-S10的时候，常用的也就几种模拟

1. Provia默认模式，没什么特点

2. Velvia鲜艳模式，拍摄风景时采用

3. Classic Chrom经典正片，街头摄影时使用

   模仿的是Kodachrome反转片，颜色比较平淡，饱和度没那么高

4. Classic Neg经典负片，最喜欢的胶片模拟，色彩浓郁

   模仿的是Superia 100负片，对比强烈，最具有复古色彩

## Nikon Picture Control

尼康的自定义预设，有一些模仿胶片的，[网址](https://nikonpc.com/)

