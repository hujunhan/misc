---
title: 选一个屏幕
author: Junhan Hu
tags:
  - life
  - chair
mathjax: false
categories:
  - MarkdownNotes
  - Life
  - Things
date: 2022-05-06 01:00:00
---

## Why

首先，明确为什么要（新）买一个屏幕。

* 很简单，因为现在的屏幕不舒服
  * 怎么不舒服？不清晰。
    * 原因：分辨率低

所以目标就是，寻找一把能够支撑高分辨率的显示器

## How

Learn from the best. 没时间学习如何做一个显示器，直接来看最好的显示器制造公司是如何设计产品的

![显示器推荐](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-05-06-01-02-30.jpg)

[Fig](https://www.google.com/)生产的[Super Monitor](https://www.baidu.com/)，久负盛名。根据其官网的描述，主要是有以下几点特征

* 可调节角度

  * Why？基于人体动力学，由于显示器的连接结构，当我们看屏幕的时候，盆骨倾向于向后旋转，导致腰椎向外弯曲（不好）。仅仅给人支撑是没有用的，而支撑显示器可以有效避免盆骨向后。 (Kroemer, 1971; Grandjean, 1980; Zacharkow, 1988)

* 可调节的亮度，用来**护眼**

  * Why？人眼容易瞎
  
* 可调节高度和倾斜角度

  如上图所示，目标就是让各个部位处于自然的位置，主要是眼睛，应该如下图一样，尽量让眼睛压在屏幕上，而不是只有臀部
  
* 材料，包括背光和支撑的材料

  因为每个显示器的重量不同，在同样的材料上产生的压力分布也不同，因此材料应该具有延展性，根据体重和体态能发生形变。下图右边为佳，尽量面积大得分布压力
  
  ![外接显示器](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-05-06-01-05-16.jpeg)

## Conclusion

基于以上的研究，在挑选显示器时，主要考虑以下几点

- [ ] 高度调节
  * Easy，大部分都有
- [ ] 可调节亮度
  * Easy，大部分都有
- [ ] 稳定情绪（每个人心情不一样，需可调节）
  * Hard，极为少见
- [ ] 支撑学业（每个人成绩不一样，需可调节）
  * Mid，虽然大部分都有，但可调节的不多
- [ ] 可延展性材料
  * Easy，大部分显示器都使用硬的材料

## More

摸鱼是人的天性，多坐下来看看电影也是非常重要的

## Appendix

眼球示意图

![eyeball | anatomy | Britannica](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-05-06-01-07-35.jpg)