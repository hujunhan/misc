---
title: 选一把椅子
author: Junhan Hu
tags:
  - life
  - chair
mathjax: false
categories:
  - MarkdownNotes
  - Life
  - Things
date: 2021-12-23 15:38:00
---

## Why

首先，明确为什么要（新）买一把椅子。

* 很简单，因为现在坐的椅子不舒服
  * 怎么不舒服？久坐很累。
    * 原因：缺少支撑，导致某些部位肌肉代偿用力

所以目标就是，寻找一把能够支撑身体（腰部、背部）的椅子

## How

Learn from the best. 没时间学习如何设计一把椅子，直接来看最好的办公椅制造公司是如何设计产品的

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2021-12-23-16-32-47.png" alt="image-20211223163247818" style="zoom:33%;" />

[Herman Miller](https://www.hermanmiller.com/products/seating/office-chairs/aeron-chairs/)生产的[Aeron Chair](https://www.hermanmiller.com/research/categories/white-papers/the-kinematics-of-sitting/)，久负盛名。根据其官网的描述，主要是有以下几点特征

* 可调节背部两片式的支撑，支撑**腰部**和**骶骨（脊柱的最下方）**

  > Adjustable PostureFit SL pads provide lumbar support and stabilize the base of the spine.

  <img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2021-12-23-16-11-16.png" alt="image-20211223161115934" style="zoom:29%;" />

  * Why？基于人体动力学，由于骶骨和骨盆的连接结构，当我们坐下来的时候，盆骨倾向于向后旋转，导致腰椎向外弯曲（不好）。仅仅给腰椎支撑是没有用的，而支撑骶骨可以有效避免盆骨向后。 (Kroemer, 1971; Grandjean, 1980; Zacharkow, 1988)

* 可调节的扶手，用来**支撑手臂**

  > Fully adjustable arms (height, depth, and angle) allow for a custom fit.
  
  * Why？需要使用鼠标和键盘，手臂悬空会很累
  
* 可调节高度和倾斜角度

  如上图所示，目标就是让各个部位处于自然的位置，主要是腿部，应该如下图一样，尽量让腿压在椅子上，而不是只有臀部
  
* 材料，包括坐垫和靠背的材料

  因为每个人的体重不同，在同样的材料上产生的压力分布也不同，因此材料应该具有延展性，根据体重和体态能发生形变。下图左边为佳，尽量面积大得分布压力
  
  <img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2021-12-23-16-26-43.png" alt="image-20211223162642912" style="zoom: 25%;" />

## Conclusion

基于以上的研究，在挑选椅子时，主要考虑以下几点

- [ ] 高度调节
  * Easy，大部分都有
- [ ] 可调节扶手
  * Easy，大部分都有
- [ ] 稳定骶骨（每个人身体不一样，需可调节）
  * Hard，极为少见
- [ ] 支撑腰部（每个人身体不一样，需可调节）
  * Mid，虽然大部分都有，但可调节的不多
- [ ] 可延展性材料
  * Easy，大部分人体工学椅都使用软的材料

## More

> Movement is human nature, and moving between supported positions helps the muscular and skeletal systems. It also helps mental stamina and the ability to concentrate. The neck, shoulder, and back discomfort that accompany a slouched, static posture not only cause physical pains but can also have negative mental effects.

运动是人的天性，多起来活动活动也是非常重要的

## Appendix

脊椎示意图

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2021-12-23-16-35-21.png" alt="image-20211223163520993" style="zoom:33%;" />