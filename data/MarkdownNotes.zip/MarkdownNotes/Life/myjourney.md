---
title: My Robot Journey
author: Junhan Hu
tags:
  - life
mathjax: true
categories:
  - MarkdownNotes
  - Life
date: 2021-10-17 23:27:00
---

{% pdf https://drive.google.com/file/d/1UW0YqjRFxnCMlV31ZnSA0AcuP57dV2ac/preview %}
