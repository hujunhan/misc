---
title: Why We Need Window Function
author: Hu Junhan
tags:
  - signal
mathjax: true
categories:
  - MarkdownNotes
  - Control
  - DSP
date: 2020-03-29 22:53:00
---

在数字信号处理中，我们经常会对一段信号进行加窗的处理，为什么要这样做呢？这里采用自上而下的方式来考虑

## FFT

当我们要考量信号的频域特征时，我们就要做傅里叶变换。

FFT的对象只能是两种

* 从负无穷到正无穷
* 有限长度的周期信号

在实际中，FFT的对象肯定是**有限长度**的时域信号，所以会对信号进行截断。如果截断的长度不是周期的整数倍就会存在泄露，如下所示

* 如果是周期性的截断，那么截断之后的信号还是保留了原来信号的信息，可以还原出来的信号

  <img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20200329231116.png" style="zoom:50%;" />

* 如果是非周期性截断，起始和结束时刻的赋值不等，这样就是非连续的了

  <img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20200329231219.png" style="zoom:50%;" />

  对截断后的信号做频谱分析显然会导致频谱复杂，只会在正确的频率上出现一个峰值，其他地方会存在**泄露**

窗函数就是为了减少泄露，使得时域信号变化之后更好地满足周期性，**减少泄露**

## 窗函数？

由上一节得知，我们可以通过窗函数来减少泄露，尽量使得截断的信号能够更加真实地反应原信号的频谱

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20200329232804.png" style="zoom:50%;" />

理想情况是**左图**，能够准确还原出原来信号的频谱信息

不加窗的实际情况大致如**中间图**，存在很多不相关的频率信息，这就是泄露

加了窗的实际情况大概如**右图**，虽然存在泄露，但大大减少了，总体能够反应原来信号的信息

原理：通过窗函数将非平稳信号平稳化，更加具有周期性

窗函数是一个有限长度的加权函数，存在不同的加权方式所以存在不同的窗函数，常见的有矩形窗，hamming窗，kaiser窗等

有什么用？

* 频域分析
* 滤波器设计