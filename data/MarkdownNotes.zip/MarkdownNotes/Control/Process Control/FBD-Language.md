---
title: 功能块图编程语言
author: Hu Junhan
tags:
  - control
  - process
published: true
categories:
  - MarkdownNotes
  - Control
  - Process Control
date: 2019-09-04 20:12:00
---

## 概述

功能块图编程语言也称为FBD语言,它源于信号处理领域，使用类似于数字电路中的图形逻 辑符号来表示控制逻辑，有数字电路基础的人很容易掌握。该语言具有图形符号，可图形连接，操作方便，因此被广泛采用。

FBD语言的一些组成部分

* 函数
* 功能块
* 连接元素

一个功能块网络能够看成一个电气电路图,电气之间的连接用于描述组件之间的信号流. 功能块的典型应用包括**描述控制回路和逻辑**

