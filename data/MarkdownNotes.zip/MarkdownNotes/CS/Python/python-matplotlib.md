---
title: Matplotlib
author: Junhan Hu
tags:
  - data
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Python
date: 2019-03-12 10:33:00
---

## 1. Basics

* Figure
  * Axes
    * Axis
    * Title