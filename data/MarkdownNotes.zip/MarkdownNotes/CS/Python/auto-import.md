---
title: Auto Import Image from SD card to Lightroom
author: Junhan Hu
tags:
  - python
  - automation
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Python
date: 2023-02-01 21:06:00
---

## Why

I have multiple cameras, and I always shoot with Raw+JPG, but at the end of the day, I only need the raw file since it's better for post-processing

So everytime I do the work

1. Open the folder
2. Select the JPG image
3. Delete the JPG image
4. Right click the remained RAW file
5. Import to Lightroom

This process is simple but I don't like repeat it, so an automation tool would be great

## How

In a nutshell, we can use Automator and Python to finish the job

* Automator is just to run the Python script and tell the Python script where is the location
* In Python, the code will run the logic 2/3/4/5

![image-20230201211240945](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230201211241.png)

Python code:

```python
## Automate the image import process
import os
import subprocess
import sys

## Get the path to the folder containing the images
root_path=sys.argv[1]

## Define the extensions of the raw and jpg files
raw_extensions = [".DND", ".RW2", ".NEF", ".ORF"]
jpg_extensions = [".JPG",'.JPEG']

## Find the raw files and the jpg files
raw_list = []
jpg_list = []
jpg_remove_list = []
for rext in raw_extensions:
    for root, dirs, files in os.walk(root_path):
        for file in files:
            if file.endswith(rext):
                raw_list.append(file[:-len(rext)])
print(raw_list)

for jext in jpg_extensions:
    for root, dirs, files in os.walk(root_path):
        for file in files:
            if file.endswith(jext):
                jpg_list.append(file[:-len(jext)])
print(jpg_list)


## Find the jpg files that have a corresponding raw file
for jpg in jpg_list:
    if jpg in raw_list:
        jpg_remove_list.append(jpg)

## Delete the jpg files that have a corresponding raw file
print(jpg_remove_list)
for jext in jpg_extensions:
    for root, dirs, files in os.walk(root_path):
        for file in files:
            if file.endswith(jext) and file[:-len(jext)] in jpg_remove_list:
                os.remove(os.path.join(root,file))
                # print(f'removing {os.path.join(root,file)}')

## Open the remaining raw and jpg files in default application
command_list = ['open']
for root, dirs, files in os.walk(root_path):
        for file in files:
            if not file.startswith('.'):
                command_list.append(os.path.join(root,file))
print(command_list)
subprocess.run(command_list)                

```

