---
title: Design Pattern
author: Junhan Hu
tags:
  - design
  - software
mathjax: true
categories:
  - MarkdownNotes
  - CS
date: 2023-07-27 00:01:00
---

## Intro

[Ref](https://refactoring.guru/design-patterns/structural-patterns)

What?

* Typical solution to occurring problem in software
* pre-made blueprints
* Intent, Motivation, Structure, Code example

Why?

* Best practices
* common language

Classification

* Creational pattern, object creation
* Structural pattern, assemble into larger structure
* Behavioral pattern, take care of effective communication
  * Maybe useful in robotics area

## Creational Pattern

Factory: use general interface, all subclass implement these interface. Good if continue to add object type

* for create new sensor, new actuator

Builder: build a complex object by director and builder

* could be useful for pipeline design

Prototype: implement clone() method, the client don't need to know whats inside the class

Singleton: a class has only one instance, control the shared resource. make the default contructor private, create a static creation

* for global control

## Structural

Adapter: allow object with incompatible interface to collaborate, just add new function take care of the transition

* for different robot object

Bridge: Abstraction and implementation, divide the problem, make it easier to

* differentiate objects

Composite: compose objects into **tree** structures, so you can work on like recursive pattern

* robot system

Decorator: add new behavior to objects

* add new feature to different object

Facade: build a middleware, deal with details with large 3rd party library

* make the system into layers

Flyweight: fit more objects into RAM

* apply for optimization

Proxy: control the access, allow for performing something either before or after the request

## Behavioral

Chain of Responsibility: pass request along a chain of handlers, each handler decide either process or pass

Command: turn request into objects, add logic layer

* should be apply to robotics

Iterator: provide a function to get elements of the collection

Mediator: restrict direct communication, forces to collaborate

* just like a center controller

Memento: save and restore previous state of an object

* undo operation

Observer: event-subscriber, just maintain a subscriber list, and goes over subscriber 

* when two objects are closely related
* important in robotics

State: change behavior when the internal state change. Fi

Strategy: a class contain different algorithm 

* nice for testing new system

Template: abstract class and make the subclass implement by itself for different type

Visitor: decouple with the object that working 