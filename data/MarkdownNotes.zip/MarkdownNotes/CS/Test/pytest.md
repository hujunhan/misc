---
title: Pytest Basics
author: Junhan Hu
tags:
  - test
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Test
date: 2022-03-11 13:48:00
---

## What

The `pytest` framework makes it easy to write small, readable tests, and can scale to support complex functional testing for applications and libraries.

## Why

Benefit of testing framework

* Integrarte within
* add assertions

PyTest Markers$\to$grouping

PyTest Fixtures$\to$prerequest

PyTest Hooks$\to$



## 