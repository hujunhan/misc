---
title: How OS Render Image
author: Junhan Hu
tags:
  - hdr
  - project
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - HDR
date: 2023-08-13 21:33:00
---

## Intro

Learning how operating system render images like JPEG or PNG

## Process

1. **File Read**: the operating system's file system layer reads the raw binary data from the disk.
2. **Decoding**: This raw binary data isn't directly interpretable as an image. So, it gets passed to a software component (often a library or a module within an application) responsible for decoding JPEG files. JPEG is a compressed format, and decoding it involves:
   - Parsing the file headers to understand the image's dimensions, color space, and other metadata.
   - Decompressing the data to recover the original image information.
   - The output from the decoding process is usually an uncompressed bitmap, which is an array of pixel values.
3. **Color Space Conversion (if necessary)**: Images can be stored in various color spaces. RGB (Red, Green, Blue) is one of the most common ones for displays, but images can also be stored in other formats like YUV (Luminance and Chrominance). If the decoded image is in a color space that's not native to the display, a conversion must occur. For instance, many video playback systems use YUV because it's more efficient for certain types of compression. When displaying such content, the YUV data is converted to RGB.
4. **Rendering**: Once we have the bitmap in the appropriate color space (usually RGB for displays), it's passed to the operating system's rendering system. This system interacts with the graphics hardware (your GPU) to display the image. Modern operating systems use a "compositor" that takes the bitmap, any other UI elements, and composes a final image that is sent to the display.
5. **Data Transmission**: The graphics card or GPU then sends this composed image to your monitor. The actual data transmission method (VGA, HDMI, DisplayPort, etc.) will define how this data is sent. But in essence, yes, RGB values (or sometimes other color space values) are sent to the monitor.
6. **Monitor Display**: The monitor receives these values, and each pixel on the monitor displays the corresponding color. If the monitor has a different color profile or calibration, it may make its own adjustments to the displayed colors.

## Decode

1. **JPEG (Joint Photographic Experts Group)**
   - **Decoding Method**: JPEG uses a lossy compression method based on the Discrete Cosine Transform (DCT). It converts spatial domain data into the frequency domain. During compression, some high-frequency components (which the human eye is less sensitive to) can be discarded.
   - **Color Space**: Typically YCbCr (which is similar to YUV in intent). Y is the luminance component, and Cb and Cr are chrominance components. After decoding, the image can be converted to RGB for display.
2. **PNG (Portable Network Graphics)**
   - **Decoding Method**: PNG uses lossless compression based on the DEFLATE algorithm. It supports various color depths and can handle transparency (alpha channel).
   - **Color Space**: RGB, often with an additional alpha channel (RGBA) for transparency.
3. **GIF (Graphics Interchange Format)**
   - **Decoding Method**: GIF uses the LZW (Lempel-Ziv-Welch) lossless compression algorithm. It's limited to 256 colors, which makes it suboptimal for full-color photos but suitable for simpler graphics and animations.
   - **Color Space**: Indexed color (limited to a palette of up to 256 colors).
4. **BMP (Bitmap)**
   - **Decoding Method**: BMP is often uncompressed, although RLE (Run-Length Encoding) compression can be used in some cases.
   - **Color Space**: RGB, but BMP can support various bit depths (from 1-bit monochrome to 32-bit RGBA).
5. **TIFF (Tagged Image File Format)**
   - **Decoding Method**: TIFF can use multiple compression schemes, including none (uncompressed), LZW, JPEG, and others.
   - **Color Space**: Typically RGB, but it's versatile and can support multiple color spaces depending on the specific TIFF variant.
6. **WebP**
   - **Decoding Method**: WebP can be either lossy (based on VP8 video codec) or lossless.
   - **Color Space**: YUV for lossy WebP and RGB for lossless WebP. Lossy WebP, like JPEG, involves a conversion to RGB post-decompression for display.

## Data Transmission

1. **VGA (Video Graphics Array)**
   - **Transmission**: Analog
   - **Description**: VGA transmits **red, green, and blue** video signals as separate analog channels. Horizontal and vertical sync signals are also transmitted to coordinate the timing of the display. Since the signal is analog, the quality can degrade with cable length and interference. This method is older and less common in modern systems.
2. **HDMI (High-Definition Multimedia Interface)**
   - **Transmission**: Digital
   - **Description**: HDMI transmits both video and audio digitally. The video data is sent using TMDS (Transition Minimized Differential Signaling), which minimizes electromagnetic interference. HDMI supports various video formats, including standard, enhanced, high-definition, and 3D video. HDCP (High-bandwidth Digital Content Protection) is often used with HDMI to prevent unauthorized copying of protected content.
3. **DisplayPort**
   - **Transmission**: Digital
   - **Description**: DisplayPort also uses a digital protocol, somewhat similar to HDMI but distinct in its technical specifics. It transmits data using a micro-packetized format and supports daisy-chaining of multiple monitors (Multi-Stream Transport). DisplayPort can handle high refresh rates, high resolutions, and supports Adaptive Sync, which can reduce screen tearing in games.
4. **USB Type-C (or USB-C)**
   - **Transmission**: Digital
   - **Description**: USB-C is a versatile connector that can support multiple protocols, including USB data, DisplayPort, HDMI, and even power delivery. When it comes to transmitting video, the USB-C connector doesn't define the transmission method itself; instead, it supports "alternate modes." For instance, a USB-C port with DisplayPort Alt Mode would use the DisplayPort protocol for transmitting video data. The presence of alternate modes makes USB-C a versatile connector, able to handle various tasks, including video output, depending on its configuration.

## Local Dimming

Achieve higher contrast ratio

Contrast ratio? What make it different?

* Display Tech
  * LCD, different liquid crystal can block different amount of dark
  * OLED, each pixel emit light
  * MicroLED
* Backlight
  * Edge-lit, uneven light
  * Direct-lit, full -array, can be combined with local dimming
  * Quantum Dot Ehnhancemtn