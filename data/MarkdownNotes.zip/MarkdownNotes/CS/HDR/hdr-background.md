---
title: Background for HDR Display
author: Junhan Hu
tags:
  - hdr
  - project
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - HDR
date: 2023-08-08 21:11:00
---

## Goal

1. Research & Problem Definition
   - **HDR Display Overview**: Collect comprehensive information about the intricacies of HDR displays, their technical specifications, and benefits.
   - **Problem Statement**: Clearly define the problem this project aims to address. What challenges in HDR imaging are we trying to overcome? What value does our solution bring?
   - **Project Scope**: Outline what the project will and won't cover, helping the team stay focused on core objectives.

## Display (Monitor)

Apple:

* iPhone
* iPad Pro 12.9
* Macbook Pro 14/16
* Pro Display XR

DisplayHDR

* https://displayhdr.org/certified-products

## HDR Software/Standard

### Apple

Apple SDK [Displaying HDR Content in a Metal Layer | Apple Developer Documentation](https://developer.apple.com/documentation/metal/hdr_content/displaying_hdr_content_in_a_metal_layer)

EDR: Use relative brightness

> Some Macs can process pixel data with a wider range of pixel values and send those extended values to the display. In macOS, the ability to process larger pixel values and display them is referred to as extended dynamic range (EDR). When you configure a Metal layer to support extended values, you can provide pixel values — and therefore brightness levels — that exceed the normal SDR range in order to display HDR content.

Other HDR standard: use physical brightness

### DisplayHDR

[Vesa Certified DisplayHDR™](https://displayhdr.org/)

![image-20230808212127776](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230808212127_feich7.png)

### Windows

[Use DirectX with Advanced Color on high/standard dynamic range displays - Win32 apps | Microsoft Learn](https://learn.microsoft.com/en-us/windows/win32/direct3darticles/high-dynamic-range)

## Format

HEIC

JPEG XR

JPEG 2000

## Problem

No open source software to generate HDR photo for display hdr content

Challenge:

* No public standard from Apple (only SDK), need to dig further to see
* Compatibility, how can we make the photo compatitable with as much monitor and system as possible
* Tone mapping algorithm, not sure how difficult it is or could the tone mapping be generalized

## Project

Input: Raw image+Config file(Optional, Maybe edited in other software like Lightroom, Rawtherapee)

Operation: Use GUI manipulate the brightness level, or AUTO mode

Output: HDR content ready to display on desired platform

* Maybe 10bit HEIC image like iPhone camera did

Basic Function:

- Image conversion
- Image display
- Color management (wide color gamut display)
- Color space conversion on HDR display
- Bit depth conversion
- Tone mapping

## Question

How OS render images？

## Summarize

- **Problem Statement**: Clearly define the problem this project aims to address. What challenges in HDR imaging are we trying to overcome? What value does our solution bring?
- **Project Scope**: Outline what the project will and won't cover, helping the team stay focused on core objectives.

