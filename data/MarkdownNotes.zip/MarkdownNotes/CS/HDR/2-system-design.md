---
title: System Design for RawShines Project
author: Junhan Hu
tags:
  - hdr
  - project
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - HDR
date: 2023-08-16 23:57:00
---

## System

MacOS: Apple has implemented the HDR display. We need to first match that (hard task)

## Programming Language

Python

**C++**

## High-Level System Components:

- **Input Module**: Accepts and validates the RAW image files.
- **Metadata Extraction Module**: Extracts and temporarily stores metadata from the RAW file.
- **Image Processing Engine**: Prepares RAW images for manipulations by converting them into an intermediate format.
- **Modification GUI**: Provides user-friendly tools and controls for image adjustments.
- **HEIC Converter**: Converts the manipulated image into the HEIC format.
- **Output Module**: Outputs the processed HEIC image, complete with options for subsequent actions such as saving or sharing.

## Detailed Design:

- **a. Input Module**:
  - **File Selection**: Facilitates selection or drag-and-drop of RAW files.
  - **File Validation**: Ensures files adhere to supported RAW formats.
  - **Batch Processing**: Enables processing of multiple files simultaneously.
- **b. Image Processing Engine**:
  - **Decoding Engine**: Utilizes libraries like `libraw` for RAW image decoding.
  - **Color Correction**: Employs algorithms for consistent color grading.
  - **Intermediate Format Storage**: Ensures quick processing by converting and storing images in an intermediate format.
- **c. Modification GUI**:
  - **Preview Pane**: Real-time display of image modifications.
  - **Adjustment Sliders**: Controls for brightness, contrast, saturation, etc.
  - **Undo/Redo Actions**: Grants flexibility in modifications.
  - **Presets**: Allows quick edits through predefined settings.
  - **Zoom & Pan Tools**: Facilitates detail inspection.
  - **Histogram Display**: Dynamic histogram for informed editing.
- **d. HEIC Converter**:
  - **Conversion Engine**: Employs libraries like `libheif` for HEIC conversion.
  - **Compression Settings**: Users can set desired compression levels.
  - **Profile Embedding**: Guarantees color consistency by embedding ICC profiles.
- **e. Output Module**:
  - **File Saving**: Users dictate destination and filename for output.
  - **Metadata Preservation**: Original metadata remains intact in the converted image.
  - **Sharing Options**: Direct integration for cloud, social media, or email sharing.

## System Architecture & Technologies:

- **Platform**: Choices include Electron or Qt, based on target audience.
- **Programming Language**: Choose between JavaScript (Electron) or C++ (Qt).
- **External Libraries**: Utilize `libraw` and `libheif`.
- **Database**: Integrate SQLite for efficient storage and retrieval.

## Non-functional Considerations:

- **Performance**: Prioritize fast processing, especially for high-res RAW images.
- **Usability**: Ensure an intuitive experience, especially for non-tech-savvy photographers.
- **Scalability**: Plan for potential growth or feature additions.
- **Security**: Prioritize user data security.
- **Extensibility**: A modular architecture facilitates future feature additions.
- **Error Handling**: Users receive clear messages for unsupported formats or other issues.

## Testing:

- **Unit Testing**: Individual components are rigorously tested.
- **Integration Testing**: Modules are tested for seamless interactions.
- **Usability Testing**: Gather feedback from photographers on GUI and workflows.
- **Performance Testing**: Ensure efficiency with high-res RAW files.
