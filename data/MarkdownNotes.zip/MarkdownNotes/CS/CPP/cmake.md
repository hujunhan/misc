---
title: CMake Done Right
author: Junhan Hu
tags:
  - programming
  - cpp
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - CPP
date: 2023-03-10 01:01:00
---

## Why

CMake is indeed not a modern design for package management

```cmake
find_package(Boost 1.55 COMPONENTS asio)
list(APPEND INCLUDE_DIRS ${BOOST_INCLUDE_DIRS})
list(APPEND LIBRARIES ${BOOST_LIBRARIES})

include_directories(${INCLUDE_DIRS})
link_libraries(${LIBRARIES})
```

* lack of structure
* the order of linking is missing

## Target

Modern CMake is about targets

* executable is target
* library is target

Properties is the

* source file
* compiler option
* Link against

Properties have two domain

* PRIVATE: for internal use
* INTERFACE: for usage of this lib

## Import

When we call `find_package()`, the CMake would execute `FindBoost.cmake` and import the `Boost::boost`, so that we can link them `target_link_libraries()` 

The PAIN: 3rd party dependencies, 