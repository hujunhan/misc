---
title: Power of ChatGPT
author: Junhan Hu
tags:
  - AI
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - AI
date: 2023-03-27 00:15:00
---

## GPT3

三个重要能力

* Text Generation, using prompt
* In-Context learning
* World knowledge, factual knowledge and common sense

来源：大量的数据

## From GPT3 to ChatGPT

![图片](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230327001912.png)

不同的微调指令激发出了不同的能力，这些能力本来就已经有了

* 上下文学习
* 对话
* 代码

## Code-Davinci

通过指令微调，直接产物是能够响应人类指令

泛化能力：指令数量超过一定范围自动出现

* 复杂推理能力是**训练代码**的神奇副产物
* 面向对象和面向过程

## Text-Davinci, RLHF

**人类反馈**（一种训练手段）带来的能力：

* 更长的回答
* 公正的回应
* 拒绝不当问题
* 拒绝知识范围之外的问题

能力是模型本来就有的，RLHF（人类反馈）触发了新的能力

## Can't Do

非常严谨的数学推导

纠正错误的事实



