---
title: AI Writer
author: Junhan Hu
tags:
  - data
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - AI
date: 2023-02-01 00:38:00
---

## Intro

Using NN to generate novel

* Input: the start
* Output: renewed novel with the start

## How

Convert the input text into number, find the stat pattern

By learning a model

* Given a bunch of data
* **Predict the next word**

GPT model

* Training data: novel, small



## Ref

[Github Repo](https://github.com/BlinkDL/AI-Writer)