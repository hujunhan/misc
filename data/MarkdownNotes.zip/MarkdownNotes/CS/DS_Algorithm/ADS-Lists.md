---
title: PADS-Lists
author: Junhan Hu
tags:
  - DS
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - DS_Algorithm
date: 2019-03-02 11:11:00
---

## 1 Introduciton
