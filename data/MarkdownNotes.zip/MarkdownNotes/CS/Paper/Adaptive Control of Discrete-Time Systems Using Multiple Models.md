---
title: Adaptive Control of Discrete-Time Systems Using Multiple Models
author: Junhan Hu
tags:
  - paper
  - notes
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Paper
date: 2019-08-07 22:34:00
---

## Abstract

Using **multiple models** to control a linear time-invariant discrete-time system

Giving proof of global **stability** of the overall system

## Introduction

## Mathematical Preliminaries

## Adaptive Control