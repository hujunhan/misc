---
categories:
  - MarkdownNotes
  - CS
  - Miscellaneous
---
## QT

signal

* when signal emit, it would run instantly.



Current Problem

* ![image-20211215223503831](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2021-12-15-22-35-04.png)
* Line mode could be activated multiple times
* Point mode only 1 times
* Rect mode can't be activated after Line mode

## How it Works?

1. Make the Line work as Rect
2. add custom text for label
3. 

