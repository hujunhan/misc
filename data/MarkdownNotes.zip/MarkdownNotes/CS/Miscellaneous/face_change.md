---
title: Face Time Lapse
author: Junhan Hu
tags:
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Miscellaneous
date: 2022-12-29 13:06:00
---

## Goal

Show how my face and hair style changes from time to time

Input: a bunch of selfie

Output: a short clip show the change

## Plan

1. Collect data (image) from camera and phone
2. Put into Lightroom in a album for organization and further development
3. Output the image with time-tagged prefix
4. Remove the background (maybe not)
5. Use computer vision to detect the face and crop

## Code

Eye alignment is the key process

https://github.com/hujunhan/eyelign

1. main.py use machine learning to do the most job
2. gui_manual_align.py use GUI to manual align the corner case

---

Generate the timelapse

```bash
ffmpeg \                                                                 
  -framerate 15 \
  -pattern_type glob \
  -i "/Users/Hu/Downloads/output/*.jpg" \
  -s:v 500x500 \
  -c:v libx264 \
  -crf 17 \
  -pix_fmt yuv420p \
  timelapse.mp4
```

