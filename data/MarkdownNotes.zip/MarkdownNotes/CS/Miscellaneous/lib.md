---
title: Dynamic? Static?
author: Junhan Hu
tags:
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Miscellaneous
date: 2023-03-08 22:32:00
---

## Goal

Understand the difference between dynamic and static libraries in software

* Static: link at compile time, make the final program larger
* Dynamic: link at runtime, require the system to have the lib

When to use?

* Static: lib is small, not change, need to be optimized
* Dynamic: lib is large, frequently update

## Compile Process

* Preprocessing, remove comments, expand macro
* Compilation, translate into assembly
* Assembly, translatie into machine code
* Linking, combine it with other libraries and modules

## Linking?

* Static linking is usually used for local
* Dynamic linking is usually used for external libraries

How it works?

* When compiled, it split into object file and combined into a single file
* Header files should be used to make sure the parameter is correct

References?