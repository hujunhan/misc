---
title: Real-time System
author: Junhan Hu
tags:
  - real-time
  - cs
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Miscellaneous
date: 2023-02-22 15:46:00
---

## Definition

From [ROS2 Design](https://design.ros2.org/articles/realtime_background.html)

* Determinism
* Deadline
* Quality of Service

Real-time software guarantees correct computation at the correct time.

It needs 2 parts

* Real time system
* Real time code

KEY: **DEADLINE** [Ref](https://roboticsbackend.com/what-are-real-time-constraints-in-robotics/)

* Just finish the job before or after deadline

![Real-time constraints in robotics 3/3](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419220419_coQeQh.png)

## Coding

Low level code:

* almost everything should be in real-time

Decision algorithm:

* important to implement in some Key decision, like when to stop

Synchronization between devices

* start the motor at the same time

## Implementation Consideration

* Using Deterministic algorithm
  * fixed-point arithmetic, state machines, and lookup tables.
* Prioritize task
  * Tasks with lower priority can be preempted or delayed if necessary to allow high-priority tasks to be executed
  * This is typically achieved through the use of priority-based scheduling algorithms.
* Use interrupts