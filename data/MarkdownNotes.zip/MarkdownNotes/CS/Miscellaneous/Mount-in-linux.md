---
title: Mount Disk In Linux
author: Junhan Hu
tags:
  - tips
  - cs
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Miscellaneous
date: 2022-12-16 00:40:00
---

## Goal

Without network, the only way to copy file is through USB drive.

How to mount and copy file through command line?

## How

1. ```bash
   sudo mkdir /media/usb
   # create mount point
   ```

2. ```bash
   sudo lsblk
   # find out which device should mount
   ```

   ![image-20221216004405653](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-12-16-00-44-05.png)

3. ```bash
   sudo mount  /dev/sdb2 /media/usb -o uid=1000,gid=1000,utf8,dmask=027,fmask=137
   # mount the right disk (large one) to the create mount point
   ```

   

