---
title: 个人主页搭建
author: Junhan Hu
tags:
  - web
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Web
date: 2022-10-19 21:20:00
---

## Intro

为什么要搭建个人主页（在已经有了个人博客的前提下

最重要的目的是个人展示，在未来进行创业、自由职业时有较为重要的作用

What I want?

* About page
* Project page
* Gallery page

## Template

https://github.com/hhhrrrttt222111/developer-portfolio

![image-20221019220235992](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-10-19-22-02-36.png)

https://github.com/Dorota1997/react-frontend-dev-portfolio

![image-20221019220921004](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-10-19-22-09-21.png)

https://github.com/rajshekhar26/cleanfolio

![image-20221019221039255](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-10-19-22-10-39.png)

https://github.com/AjitVerma15/Interactive-Portfolio

![image-20221019222242467](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-10-19-22-22-42.png)

https://github.com/hrishikeshpaul/portfolio-template

![image-20221019222333632](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-10-19-22-23-33.png)

https://github.com/hrishikeshpaul/portfolio-template-v2![image-20221019223222485](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-10-19-22-32-22.png)

## Material

https://github.com/hrishikeshpaul/portfolio-template

This one meets my needs.

I would need following info to implement my page

### About

### Education

### Experience

### Skills

### Projects

### Contact