---
title: WebRTC
author: Junhan Hu
tags:
  - test
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Web
date: 2022-03-11 15:53:00
---

## Intro

Web realtime trans 

differ from web sockets

* reduce the latency

## How to communicate

### Signaling

A,B connect to server and exchange informations

### How?

API

Indentity

Type of data

NAT traversal

Security: crypto

Codec

## Challenges

works via UDP

No standard signaling protocal

## Why

Remove the need foe extra apps

Embedded in web technologies

