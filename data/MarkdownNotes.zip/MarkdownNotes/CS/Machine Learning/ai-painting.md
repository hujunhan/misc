---
title: 'AI Painting'
author: Junhan Hu
tags:
  - ml
  - dl
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Machine Learning
date: 2022-10-22 21:01:00
---

## What

Stable Diffusion is a state of the art text-to-image model that generates images from text.

[Online test](https://huggingface.co/spaces/stabilityai/stable-diffusion) by Hugging Face

E.g the text: a samoyed running on the moon

![image-20221022210437827](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-10-22-21-04-37.png)

Confusion:

1. How text to image
2. What kind of ML/DL tech used

## How

[Ref](https://www.youtube.com/watch?v=SVcsDDABEkM) By Vox

5 step:

1. Prepare training data
2. Deep learning
3. Latent space
4. Generation (diffusion)
5. Output

The key step is the **latent space** and **diffusion**

* The deep learning network would learn from the dataset to learn all kinds of latent space for different word. For example, how yellow is the image, how round is the object, etc. 

* Diffusion start with noise and invert the noise step, guess the true data from noisy data [Ref](https://www.youtube.com/watch?v=yTAMrHVG1ew)

  ![image-20221022211653230](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-10-22-21-16-53.png) 

  From Gaussin to inverse the bayesian. the label would work as a guide as the distribution

