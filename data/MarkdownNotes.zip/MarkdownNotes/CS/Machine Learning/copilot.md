---
title: Copilot
author: Junhan Hu
tags:
  - ml
  - rl
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Machine Learning
date: 2023-01-16 15:16:00
---

## Goal

Try to understand the trending AI tool

* ChatGPT
* Github Co-pilot

Decide

* Should use co-pilot or not 

## Copilot

From comment to code

* Use GPT3, trained to natural language

Use the whole github dataset and fine-tune in a supervised version

## Chat-GPT

1. Use the GPT3.5 and fine-tune it on conversation dataset (human labeled)
2. Train on a reward model (human labeled)
3. Optimize the policy

## GPT-3

Super large model

