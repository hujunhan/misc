---
title: What is Transformer
author: Junhan Hu
tags:
  - ml
  - rl
mathjax: true
categories:
  - MarkdownNotes
  - CS
  - Machine Learning
date: 2022-11-09 22:09:00
---

## Intro

A model related to language, model behind GPT, BERT, T5

## What

A general model

* CNN for vision
* RNN for language, sequential
  * hard to train
  * always forget

Initially, trained for translation

* good for training
* huge dataset

## How it work

1. Positional Encoding

   add a index for the word, easier to train

2. Attention

   looking for related word for translation

3. Self-Attention

   How to understand the language? by checking around word to determine the real meaning of a word

## Use

