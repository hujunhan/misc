---
title: Wealth Income Inequality
author: Junhan Hu
tags:
  - politics
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
  - Politics
date: 2022-08-29 19:44:00
---

## Inequality Report

Mainly 4 areas

1. Income inequality, how it changes
2. More detailed evidence
3. Gender inequality
4. Carbon emission inequality

## Shockings

![image-20220829195851376](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-29-19-58-51.png)

Female labour income rate

---

Income:

* Richest 10%: 52% income
* Poorest 50%: 8% income

Wealth:

* Richest 10%: 76% wealth
* Poorest 50%: 2% wealth 

---

![image-20220829201012514](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-29-20-10-12.png)

More and more private wealth

Less and less public wealth

---

De-regulatoin and liberalization program make the wealth inequality even worse

## Insight

Equally distributed income: 16700 euro/person

---

Inequality

* Among country
* In the country

---

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-29-22-18-37.jpg)

Great America

---

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-29-22-17-51.jpg)

Re-distribution works but not much

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-29-22-20-59.jpg)

US re-distribution works best, after tax

> Takeaway: need more re-distribution, how it works and how to improve

## Trend

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-29-23-26-28.jpg)

Highest in 1910 and 2000

---

Only revolution and war can help 

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-29-23-45-54.jpg)

Within-country Inequality is more sever

> Takeaway: Consider more on the inequality within-country rather than between-country

## Poor Government

Wealth arise from

* Capital accumulation, like buildings, equipments, software
* Price effect, value of a house

Wealth include

* Financial assets
* Non-financial assets

Wealth owned by

* Private actors
* Public actors

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-30-21-49-16.jpg)

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-30-21-55-53.jpg)

Who own the country?

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-30-22-09-06.jpg)

## Super Rich

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-30-22-58-56.jpg)

The richest people grow 

