---
title: Good Research
author: Junhan Hu
tags:
  - Philosophy
mathjax: false
categories:
  - MarkdownNotes
  - Philosophy
date: 2022-06-03 13:56:00
---



## Good Research

Collect information and answer questions, make inference more than the data itself

---

Systematic inquiry

* begin research, read paper
* Good research
  * Address some important issue, matter
  * Researchable
  * Not answered question, trying to reproduce knowledge

---

Find something and publish it (make it as knowledge)

## Literature Review

Being part of a broader view.

Engage with other researcher, find their strength and weakness. Add value and contribute to the argument

---

Ensure you have a deep understanding on the current problem.

Then you can make move foreword

---

> Research Philosophy
>
> 1. Postpositivism, verify theory
> 2. Constructivism, generate theory
> 3. Transformative, political and change-oriented
> 4. Pragmatism, real-world practice oriented

## Management and Planning

What skills？Soft-skills

* Management skills
* Communication skills

---

Make best use of time, don't waste time, divide the goal wisely.

---

Make progress everyday

---

时间很重要，做重要的事

## How to Know the Situation

Test? Re-read the material wrote before

Confident and rationale

Validity and reliablity.

