---
title: 母系社会研究
author: Junhan Hu
tags:
  - society
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
date: 2022-08-06 17:27:00
---

## Intro

与小泉讨论世界的问题。小泉提出问题就是男的太多，导致战争不可避免；母权社会没有阶级，不滥生，集体抚养。

此前对母权社会了解不足，在此进行研究。

目的：研究母权社会是什么，分配制度以及现状

## 母权

[Main Ref](https://en.wikipedia.org/wiki/Matriarchy)

英文Matriarchy，Gynecocracy

定义（是什么）：女性掌管社会主要权力，可以延伸到经济、政治、道德等层面

存在与否？

* 大多数人类学家不认为母权社会存在过，[Eller](https://en.wikipedia.org/wiki/The_Myth_of_Matriarchal_Prehistory)
  * 所讨论的母权社会是一种假设情况下的社会
* 一些人类学家认为存在独立的母权家庭和宗族

> 思考：母权社会可能存在过，也可能没存在过，在这种情况下，很难去讨论母权社会的分配制度与现状

## 一些近似的例子

有一些可能是母权社会的例子在当代仍然存在

为什么会被认为是母权社会？有哪些特征？

* 部落A: 女性艺术品、月经周期、农耕季节，[Ref](https://en.wikipedia.org/wiki/Cucuteni%E2%80%93Trypillia_culture)
* 部落B：年老女性掌管几乎岛上所有事，男人负责航海，[Ref](https://en.wikipedia.org/wiki/Anne_Helene_Gjelstad)
* 部落C：摩梭族，女性是家族首领，女性作为遗传线，女性作出经济决定，然而政治权利依然属于男性，[Ref](http://www.mosuoproject.org/matri.htm)
* 部落D：女性有权推翻男性决定，Hopi，[Ref](https://en.wikipedia.org/wiki/Matriarchy#CITEREFSchlegel1984)

## 圣杯与剑

目前为止没有发现明显的母权社会存在过的明显特征以及关于分配制度的描述，小泉推荐《圣杯与剑》，希望在此书中寻找到



