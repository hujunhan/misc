---
title: What is Space
author: Junhan Hu
tags:
  - physics
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
date: 2022-09-11 14:32:00
---

## Question

What's the definition of space

At beginning, where is the space and object come from

## Thoughts

Space relate with time, every single time is just a slice of space-time sequence.

### What is space - by Frank Wilczek

Newton: just pure space without anything

Faraday: the electric and magnetic fields

Maxwell: mathematical 

Einstein: leave Maxwell's equation just as they were

---

Energy feed into space

---

Elastic space-time

* In Newton's law: only go straight
* In relativity: curve

---

Space weights and pushes

* the empty space has a density (dark energy)
* Was a modification in Einstein's equation

---

Space is something, not nothing

Still not quite understanded

