---
title: Development
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
  - Psychology
date: 2022-08-05 18:21:00
---

## Intro

In this module, we will learn about how baby think and discover

What else, language is learned

## Development

Basic question:

* Morality
* Continuity
* Knowledge, how much do we have and how much do we need to learn

---

**Jean Piaget**

The development of knowledge? 

* Think model differ in different stage
* It is changed in the life when human grow

Development Stage 4 stages

1. Sensorimotor 0-2

   first 2 year, gather information, no **reason**

2. Pre-operational 2-7

   Reasoning develops, but not high

   they think the world they see is everyone see

3. Concrete operational 7-12

   More logical thought, inability to reason **abstractly**

4. Formal operational 7-adult

   Scientific reasoning

---

How to study infants?

1. Brain scan
2. Sucking
3. Looking

Infants are smarter than we think, they have common sense about calculation (add, minus)

Born good or bad? 70% do good thing

Baby gradually know others can't know their thoughts

---

Explanation:

* The connection between neuron changes
* different module

Why study development?

* many problem are original in child time

## Language

What is language, here we talk about human language like English, Dutch...

Basic Facts

* 6000 languages
* instinctive
* Pidgin to creole, from informal language to a real language
* creativity

Language Structure

1. Phonology

   How to pause in sentence

2. Morphology

   Dog has week connection between the real thing 'Dog' described

   Morpheme: the smallest meaningful unit

3. Syntax, rules

   Recursion make language infintie

---

Language Acquistion

* We are born with knowledge?

* Development and learning 

  Both the three structure.

  Baby can hear more subtle differences than adults

  > If you start learning English after 3, very hard to get real fluent

Language and thought

* Does language **change** the way you think?
* Is language necessary for **abstract** thought?

## Reflection

> 大脑是一个进化的过程，我们想要研究大脑，可以从婴儿时期开始研究
>
> 许多心理学上的问题其根源都可以在婴儿时期找到根脚
>
> 语言是非常重要的一个部分，人类的语言很复杂
