---
title: Self and Others
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
  - Psychology
date: 2022-08-10 21:27:00
---

## Intro

Social and non-social emotions

How we deal with other people? Social psychology

## Emotion

Radical ideas

1. Brain is the origin of mental
2. Then where the brain comes from? **Natural Selection**

Where do complex things come from?

* Creationism? The god is not perfect since some design in human is bad
* Natural Selection

---

The brain is a product of evolution, this leads to a conclusion that

1. Goal of brain is to fulfill some task
2. Our psychology is ignorant of evolution's view

Many psychology scene need to be explained.

* Facial expression? Fake smile below nose. Real smile move eyes
* Fear? From DNA, hard to fake, as the expression should be a signal, others relied on the signal
* Kinship？Gene tends to be nice to others tends to win. Nice to kin

---

What means love? A great feeling about something, not only living and eating

Animals are also nice to non-kin, if someone cheat, that's hard to know

---

Prisoner's dilemma, it's everywhere,

The **BEST** strategy is to be tit-for-tat

* Nice to Nice
* Mean to Mean

---

Sometime irrational approach is beneficial

* Rational person is easily exploited
* Person with a temper won't be messed with

Psychology is highly related to culture

## Social Psychology

Some are solid but some are failure and hard to replicate

For **self**: spotlight effect

* Most of time, people **focus on themselves**
* Most people give above average
  * Positives are result of self
  * Negatives are result of others
* Human like support (Confirmation bias)
* Cognitive dissonance(认知失调)
  * The more you pay, the more meaning you want to find

**Self and others** Attribution Theory (归因理论)

* We try to explain, but there is a bias
* Focus too much on personality rather than situation

**Like others**?

* Familiarity, play a big role in friend and marriage
* Similarity, 
* Attractiveness,
* First impression
* Pygmalion effect： people behave better when there is a expectation

Groups

* we would categorize people and make stereotype
  * often positive
  * often accurate
* But there are problems with stereotype
  * not always accurate
  * hard to shake
  * bad influence
* 3 level
  * public
  * private
  * implicit

Use our mind/intelligence to fight with stereotype

## Reflection

> 我们的大脑是非常容易被引导、误导的。所以我们要利用智慧去抵抗。先学习各种偏见，然后去尽量避免

