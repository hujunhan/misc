---
title: Foundation of Psychology
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
  - Psychology
date: 2022-08-02 20:31:00
---

## Brain

Materialism:Everything is just no more than assemble of human brain

Mind=Brain

Dualism:

* Descartes: humans are different, mind+material

  * creative? We are too complicated

  * method of doubt: You can doubt the body and everything might just be illusion, but not the mind.

    you could survive without body

* Problem:
  
  * Can't answer important question about ourselves
  * we have better understanding of physics
  

---

Neurons,1000,000,000,000 in human brain, hard to build/copy

Very complicated process and machine. non-linear

Drug can be used to influence neuron

Brain special wire

* highly resistant to damage
* extremely fast

**Cortex** is the main area that something happen

* like a map, mapped area are close, and distribute unevenly

  <img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-03-00-33-32.png" alt="image-20220803003332319" style="zoom:33%;" />

Two part, both side has major function, duplicate

* Right
* Left

Mind is a computer, in recognition, language

But the hard problem is for subject experience

## Freud

Sigmund Freud

His result influence our views profoundly

Most important

* Unconscious
  * Motivation
  * Dynamics

3 system

* Id, aninal
* Ego, logic and reality
* Superego, internalization of society's moral

Stage theory

1. Oral stage, eat or chew
2. Anal, retentive or expulsive
3. Phallic, genetials, 
4. Latency, sexual is sepressed
5. Genitals, pleasure in love and work

Defense Mechanisms: when the conscious **overflow**

* projection
* rationalization
* regression

What is science? Strong claim that can be proven wrong.

* Freud is unfalsiable, can't prove wrong

Though many Freud claims are wrong, but you can find valuable idea

## Skinner

B.F. Skinner

Package the idea and wrap into science

Behaviorism

1. Emphasis on learning, you could be anything
2. Anti-Mentalism
   1. use scientific way: observable, stimulus, response, envrionment
3. No differences across species

---

Habituation:

* response less to more familiar stimuli
* keep up focus on new things

Classical Conditioning

* relation between two stimulus

  ![image-20220804230441225](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-04-23-04-41.png)

* Train dog

  * unconditioned stimulus: food
  * neutral stimulus: voice instruction
  * unconditioned response: statified

Instrumental Conditioning: learning what works and what doesn't

* How to train: give positive reinforcement
* The partial reinforcement effect
  * If constantly give reward, it would stop if not reward
  * Should give the reward randomly

Other view: we can't count everything into reinforcement

## Reflection

> 大脑是心灵的起源
>
> 弗洛伊德的理论是现代心理学的重要部分，但是无法证伪，所以不算科学
>
> 习惯是非常容易被引导的（巴甫洛夫的狗）
>
> 