---
title: Variation
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
  - Psychology
date: 2022-08-12 23:08:00
---

## Intro

Individual difference, how we explain that?

Clinical psychology, mental illnesses and therapies

## Difference

**How** are we different? **Why** are we different

Talk mainly about **personality** and **intelligence**

Personality：

* How to assess? **Reliability** and **Validity**
* **Big 5**, stable, and can predict real world behavior
  * Stability
  * Introversion
  * Openness
  * Antagonism
  * Conscientious

Intelligence：

* IQ score is normalized to normal distribution with mean=100，std=15
* Social value, how people success in society highly related to how society value?
  * if social value red hair, red hair people become successful

---

Why are we different?

1. High heritability (from gene)

   1. Contribute 0.3-0.7

2. Non-shared environment

   1. Contribute 0.7-0.3
   2. This means parents **doesn't matter**
      1. BUT this violate common sense
      2. If SO, why parents treat their children nicely?
         1. We treat others nice because we love them

Being good is not mean that you would transform someone else

## Clinical

Mental illness is a myth?

* being deviate from society

Major mental disorders

1. Schizophrenia: most terrible, 1%of the world's population

   Positive symptoms: 幻觉，被迫害妄想，胡言乱语，行为失常

   Why: lose connection of mind and 

   Brain: Too much dopamine (多巴胺)

   Possible: difficult birth, stress and difficult family environment

2. Mood disorders, major depression disorder

   Symptoms: sadness

   Why: no "reasonable" cause

   How:

   * Man: distract
   * Woman: accept

   Heritable from (genes, brains, minds)

   Brain: different brain basis

3. Anxiety Disorder, affects 5% of people at sometime 

   Symptoms: diffuse, vague feeling, headaches, stomachaches

   Why: classical conditioning

   强迫症OCD（obsessive-compulsive disorder): check door, washing

   * gene

4. Dissociation disorder

   Symptoms: dis-association of memory, forget something

   Why: start prior to age 10, most are women, report torture, sexual abuse and PTSD

   Maybe the therapist itself make this DID, since in 1930, only 2 case, but 20000 case in 1980

5. Personality disorder

   James Bond

----

Therapy

* Psychodynamic therapy Freud
* Behavior therapy Skinner
* Cognitive therapy
* Medical Interventions

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-13-15-24-49.png" alt="image-20220813152448841" style="zoom:33%;" />

Does therapy work?

* Do recover better

## Reflection

> 心理测试的两大重点：稳定性（长时间内保持稳定）和可靠性（能根据结果推测日常）
>
> 心理疾病的治疗没有特别明确的可量化指标，只能说相比于不接受治疗，接受治疗会稍好一些
>
> 
>
> 