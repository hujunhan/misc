---
title: Good Life
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
  - Psychology
date: 2022-08-14 15:21:00
---

## Happiness

Positive psychology

What is **happiness**?

* How happy are you? Common answer is 7,8, none under 5

* Weather effect the mood much

* From **evolutionary** point, happiness is the goal animal evolved to pursue

Facts:

1. Happiness doesn't change much, highly **heritable**.
   1. daily things are irrelevance of certain event
   2. we adapt good or bad things
2. Happiness is influenced by **absolute** and **relative** factors
3. Judgement about past events are **skewed**
   1. we focus on peaks and endings
   2. better to put the pleasure in the end

Two things

* Humility: we haven't solve the problem
* Optimism: the more we view the brain scientific, we appreciate more

## Reflection

> 结尾非常重要，有一个好的结尾能给人留下更好的印象
>
> 目前人类对大脑的研究还有待深入

## Intellectual

Interesting problem