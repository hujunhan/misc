---
title: Cognition
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
  - Psychology
date: 2022-08-08 23:38:00
---

## Intro

Cognitive psychology, how we perceive the world, how attention works, how we store our memory

## Perception and Attention

Perception is a hard problem

How we recognize the object? Still not well studied; Machines are getting better and better

See the perception system into math style, images are just number array

Different level

1. Brightness

   The brain would compensate the scene automatic

2. Objects

   Proximity, we would take the natural form into count.

   Continuation, tendency to continue

   Good form

3. Depth

   Geometry, size, intersect

None of them is conscious,

---

Attention, three stage memory

1. Sensory memory
2. Short term memory
3. Long term memory

How from 1$\to$2? **Attention**

* Some are effortless
* Some need more attention
* Some are can't stop (read, hear)

## Memory

Implicit and Explicit

![image-20220809225426588](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-08-09-22-54-26.png)

Long term memory is like unlimited, people never reach the limit

Short term memory is quite limit

* The basic unit in short term memory is chunks

---

Feed something **INTO** brain

Learning? How to get things into LTM?

* Think deeper, add more sense, add more connection
* By image, mnemonic

---

Get something **OUT** of brain

1. Retrieval curs
2. Compatibility principle 
3. Searching strategies

----

Why sometimes we **FORGET**?

1. Decay
2. Interference
3. Change of cues

What is learning? Create new memory

---

Why sometimes our memory is **WRONG**?

1. Expectation
2. Leading questions
3. Hypnosis
4. Repressed memories
5. Flashbulb memories (vivid, important)

## Reflection

> 我们是如何认识这个世界的？大脑信息的输入
>
> * 视觉系统和注意力
>
> 记忆
>
> * 我们如何记住？活动、短期、长期
> * 我们如何回忆？刺激、类似、搜索
> * 我们如何遗忘？消退、错误、改变
>
> 记忆并不可靠