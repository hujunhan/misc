---
title: Robotics System Design
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
  - System
date: 2023-08-17 21:18:00
---

## Question

Except the software part, what else need to be noticed?

Like expanding the field, robotics introduce additional complexities since the hardware and real-world interaction

## Shared Fundamental

* Requirement gathering
* System Arch
* Coding and algorithm
* Testing
* Deployment

## Added Dimension

* Embedded System and real-time computing
* Mechatronic
* Sensors
* Power Management
* Control
* ML AI

## System Design

The robotics system is always to large. Main thing to keep in mind

* Modularity
* Redundancy and Fault Tolerance
* Abstraction and Layering
* Feedback and Control system
* Configurability
* Iterative Development



