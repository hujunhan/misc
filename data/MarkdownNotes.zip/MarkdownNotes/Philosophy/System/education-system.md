---
title: Robotics System Design
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
  - System
date: 2023-08-17 21:33:00
---

## Goal

design a system that could educate people even if their previous education level is low , easy to understand

## Basic

* Psychology
  * Cognitive development stages (e.g., Piaget’s theory), learning styles, motivation theories, and memory retention.
    * Style: visual/auditory/read&write/kinesthetic learner
    * Motivation: self-determination. Expectancy-value. goal setting
* Curriculum
  * Bloom's Taxonomy, backward design, differentiation
    * Bloom: remember, understand, apply, analyze, evaluate, create
    * Backward design, purpose driven
      * Results
      * Evidence
      * Plan learning
* Pedagogical
  * Inquiry-based learning, project-based learning, flipped classroom, experiential learning.
* Tech
  * Learning Management Systems (LMS), adaptive learning platforms, AR/VR in education, gamification.
* Assessment
  * Formative vs. summative assessment, authentic assessment, rubrics.
* Adult Learning
  * Self-directed learning, experiential learning, relevance in adult learning.

## System Design

1. Understand the user, need assessment
2. Set clear objectives
3. Modularity in content delivery
4. Interactive content
5. Quiz
6. Support system
7. Adaptive learning platform
8. 