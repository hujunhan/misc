---
title: General System Design
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
  - System
date: 2023-08-15 21:56:00
---

## Intro

I start the System series blog in Philosophy part because I think the system thinking is more like the method of method.

## Goal

Understand some general good properties and principle a **long lasting** system would hold

> As long as the system can solve the problem, I think it is good enough, I just add long lasting as a constraints to make the question more insightful

## General Principle

For robust, enduring system

* Modularity: easily repaired, upgraded, modified
* Scalability: handle increased loads or demands
* Resillience: capable of absorbing shocks or unexpected events
* Feedback
* Efficiency
* Clarity of Purpose

## Learning Order

From general guidelines, I would start learning following area in order (for my interest)

1. Software Development: Pure software, fundamental for many modern system
2. Robotics: adds layer of physical system, real-time processing
3. Education: explore the human side of system
4. Politics: most complex, involve tech and human

