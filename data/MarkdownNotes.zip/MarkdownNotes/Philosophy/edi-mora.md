---
title: About Morality
author: Junhan Hu
tags:
  - Philosophy
  - introduction
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
date: 2019-06-16 13:41:00
---

## Overview

We live with some sense of what is good or bad, better or worse.

So what is all the morality about? 

Focus on the **status** of daily morality. , That is:

* are we talking about objective things?
* or our habbit
* something exist in the universe?

There are 3 theories :

1. objective, we are representing some object 
2. relative, describe some kind of culture or personal approach
3. emotion

<!-- more -->

