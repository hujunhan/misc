---
title: What is Time
author: Junhan Hu
tags:
  - physics
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
date: 2022-09-10 15:10:00
---

## Question

The questions that always stay in my mind:

1. How is time defined?
2. How is time measured?
3. What's the origin of time?

## Thoughts

**How is time defined?**

A measurement of motion and movement.

* If a system is unchanging, it is timeless

**Why can't time go backward?**

* Due to second law of thermodynamics, in a isolated system, the entropy would only increase

**How is time measured?**

Time is not same everywhere, time depends on reference or observer.

**What's the origin of time?**

Only for the universe, there is a beginning. (Big Bang)

Rely on the definition, no definition before the time

## Universe?

Quantam field 

* Generate from void

Equation can't do the magic, why these laws?

## One Second

What is 1 second? the time that elapses $9.192631770\times 10^9$ cycles of the radiation produced by transition between two level of cesium-133 atom 

Why such an odd number? 9.19.. to mimic the old standard so that old system don't need to be recalibrated.

Why cesium? unchanging physic law 

## Takeaways

No answers, probably never.

Rely on the definition and perception