---
title: Equality and Education
author: Junhan Hu
tags:
  - Philosophy
  - education
  - equality
mathjax: false
categories:
  - MarkdownNotes
  - Philosophy
date: 2023-05-28 15:14:00
---

## Intro

Goal: try to understand the relationship betwwen education and equality

* How could education contribute to equality
* What is the most important force for equality
* Which equality should I chase first
* How should I do?
* What can GPT and AI do in the process

## Equality, Fairness, Justice

Equality: give everyone the same thing(?) to get the similar result

* same input

Fairness: About the justice in the way people are treated.

* same output

Justice: invlove more than equality and fairness

* address past wrongs or systemic disadvantage

## Contribute

* empowerment
* critical thinking
* tolerance
* economic
* opportunities

## Important Force

* education
* law and policy, maybe already done
* economic system. Distribution of resources
* technology
* social movements
* cultural shifts

## Which Area





