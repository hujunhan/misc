---
title: Value of AI
author: Junhan Hu
tags:
  - ai
  - cs
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
date: 2019-09-10 19:50:00
---
## intro

AI have significant benefits like

* Faster processing speed
* no emotional judge

But AI system cannot be value free (introduced by developer)

## What is value
* ~~subjective preferences~~
* standards for evaluation (judge the extent), in this sense, not only human have value
    * in this sense, there is a plurality of different standards

## System
No system is perfect. All system involve tradeoffs, trade off reflect value

Value in system is ineliminable. In 3 phase

* Problem Identification
    * different ways to address problem 
    * different definition 
* Design
    * data collection, privacy 
    * which data to train, feature or not?
    * algorithmic fairness
* Implementation 