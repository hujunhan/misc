---
title: 旅行的意义
author: Junhan Hu
tags:
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
  - Meaning
date: 2022-09-12 20:25:00
---

## 什么是旅行

暂时摆脱日常的生活，在陌生的地方探索世界

## 为什么要去旅行

满足自己的好奇心，看一看不一样的风景，尝一尝不同的食物，体验不同的文化，结交不同的人

人比风景更有趣

找寻一些在书本中无法获得的东西

体验，Experience，就是人生的意义

摆脱现有的思维定式

## 什么是意义

和语言有关，是重要的，什么是重要的呢

划分一个区别

## Takeaway

比如，旅游，如何将旅游和其他的事件分开

> memory with somebody + 脱离日常的生活方式 + 在不熟悉的环境