---
title: 摄影的意义
author: Junhan Hu
tags:
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
  - Meaning
date: 2022-09-13 21:38:00
---

## 什么是摄影

用感光材料记录下某一刻的光影和故事

## 摄影的意义是什么

记录，回忆，美

不再孤单，一人行走的勇气

创造，creativity

去探索的理由

## 为什么要拍照

意义
