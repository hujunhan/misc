---
title: What is Consciousness
author: Junhan Hu
tags:
  - physics
mathjax: true
categories:
  - MarkdownNotes
  - Philosophy
date: 2022-09-20 20:55:00
---

## Question

Real me? Self?

How idea create?

Model of brain? computational, logical (lead to un-logical mind??)

What I real want to do? Understand how brain works

## Thoughts

David Edelman, creation of Conscious Artifact

* Reentrant Architecture

  Different than feedback system.

  Bi-directionally linked, physical 

* Thalamo-Cortical System

  Dynamic core

* Value system, reinforcement

  For an agent to modify its behavior

* Phenotype

  Shape, morphology of the robot. Touch is important

* Motor control

  Motor command is fed back to nervous system

  Basal Ganglia
  
* Learning and momory. Very complicated model

  * Problem: how to transfer knowledge to other task

* Communication, not language, but showing a degree of self-awareness

* Thought

  Dynamic core theory

* Language: language is distinctively more sophisticated

2006, UCI, "Build A Brain" meeting

## Todo

Theory of Neuronal Group Selection

## Common Sense

Computational model for common sense

Current AI: just pattern recognition, function approximation

Gap: model the world, explain, image, plan, build, share

Self-driving car:

* cost: 100 billion,
* not close to solution
* long-tail problem

Common sense enable flexiable behavior

* understanding the world
* agents have their goal and plan
* abstract of knowledge about
  * Physics, motion, force
  * Psychology, belief, plan 

Smart: learn quickly from example

* Understand others' goal
* Have a plan
* Trying to help

Starting state: a core cognition, game engine

* learning procedure is very smart

----

Reverse Engineering

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-09-25-13-22-42.png" alt="image-20220925132242738" style="zoom:33%;" />

How? Build based on DL platform (TF, PyTorch)

Probabilistic programs

* Symbolic manipulation, enable the auto back prop for super large NN
* Bayesian inference, reasoning in uncertain situation
* Neural network good for pattern recognition and function approximation

We need a fast and good (not perfect) simulator

What to learn?

How to learn?

---

Intuitive physics

* train a network to inverse guess from the vision to 3d world

Intuitive psychology

---

What to learn?

* Program to program new

![image-20220925201835884](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-09-25-20-18-36.png)

## Build a Brain

Deep down

[Spaun](https://uwaterloo.ca/arts-computing-newsletter/spring-2017/feature/spaun)

* see
* remember
* act

Understand the neuron (single, multiple)



## Takeaways

