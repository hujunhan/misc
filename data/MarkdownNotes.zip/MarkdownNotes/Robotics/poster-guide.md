---
title: 'Poster 101'
author: Junhan Hu
tags:
  - robotics
mathjax: true
date: 2021-12-4
categories:
  - MarkdownNotes
  - Robotics
---

## Research Poster Worksheet

A poster is a visual presentation, NOT a paper.

1. List 5 image, and place them on the poster, to see where they might show up
2. Audience analysis: who cares your research, who will use it, what are the real-world application
3. Describe your research in 2-3 bullets
   1. The purpose of this research is to
4. What problem is your research attempting to solve
5. How does your research work to solve the problem
6. What are the results of your research? What are your findings?