---
title: 流水线抓取
author: Junhan Hu
tags:
  - robotics
  - camera
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Computer Vision
autoEqnLabels: true
date: 2021-07-12 13:25:00
---

## 流程

### RGB Image

1. 获取图像
2. 利用传统的方式得到主体脉络
3. 提取RGB关键点
4. 判断抓取位置

### RGB Image + 3D Model

1. 如果有3D模型，则通过RGB关键点匹配模型，得到关键点的3D坐标

2. 利用多组点，求解6D位姿

### 疑惑

* 什么是主体脉络
* 2d特征点的3d坐标

## 安排

基于模型的位姿估计

* 提前在3D模型上选好特征点，确定特征点在模型坐标系下的坐标
* 计算RGB图象中的特征点，



## Survey

位姿估计方法

### 已知三维模型

* PNP，based on marker

* Markerless.

  Search for point correspondences between two frames and distances to be minimized

  ![2021-07-15-10-51-54](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2021-07-15-10-51-54.png)

