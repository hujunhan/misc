---
title: 双目深度估计
author: Junhan Hu
tags:
  - robotics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Computer Vision
date: 2022-04-13 14:17:00
---

## Intro

深度估计的方式有很多种，通过双目来进行深度估计是成本较低、精度较高的一种方式

## Principe

和人眼类似，双目深度估计的原理是同一个点在左右两个相机中的位置偏差决定了深度。直觉上来说，一个点离相机越近（深度越小），那么左右两张图片中的位置差别就越大；反之越远，那么在两张图片中趋向于同一位置

![image-20220413142151851](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-04-13-14-21-52.png)

利用三角关系求出真实深度

## Requirement

需要对左右两侧相机进行校准

* 单目校准，估计内参和畸变
* 双目校准，估计两个相机的相对位置，rectify之后确保同一基线

## ROI

一般情况下，不会对整张图片都进行深度估计，只在感兴趣的区域进行估计，和其他的工具进行合作，完成这个工作

1. Object Detection，在左侧图像找到ROI
2. Feature Extraction，找到特征点
3. Template Matching，在右侧图像找到匹配的ROI，并作Feature Extraction
4. 约束，将不合格的特征点匹配去掉
5. 深度估计，套用公式，根据时差估计深度，求平均、中值

## Active Sensing

主动测距，把双目相机的其中一个替换成projecter

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-07-02-11-35-40.png" alt="image-20220702113540329" style="zoom:33%;" />

本质上就是更加容易地做匹配