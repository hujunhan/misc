---
title: Yolo5Face
author: Junhan Hu
tags:
  - robotics
  - camera
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Computer Vision
date: 2021-12-20 22:24:00
---

## What I want to Know

How they add key point landmark detection

How they design their network due to this change

## Yolo5Face Contribution

* Redesign the YoloV5
* Design models for different model size
* Evaluate on Widerface

## Key Modification

**Add a landmark regression head**, this is what I want to know

In face detection, there are 5 points (simplified from 68 points)

* General loss functions for landmark regression: Wing-loss
  $$
  \operatorname{wing}(x)= \begin{cases}w \cdot \ln (1+|x| / e), & \text { if } x<w \\ |x|-C, & \text { otherwise }\end{cases}
  $$
  
  ![image-20211220224538479](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2021-12-20-22-45-38.png)

* Add landmark loss with object detection loss

  $$
  loss(s)=loss_{obj}+\lambda{L} loss_L
  $$


Stem Block

* YOLOv5 has a focus layer, replacing focus layer with stem block
* Adding landmark into the stem block
