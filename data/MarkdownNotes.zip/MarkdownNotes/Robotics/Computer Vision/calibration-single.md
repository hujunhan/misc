---
title: 单目相机校准
author: Junhan Hu
tags:
  - robotics
  - camera
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Computer Vision
autoEqnLabels: true
date: 2022-04-03 18:44:00
---

## Intro

单目相机标定目标：相机的内参（fx,fy,cx,cy）和畸变，建立从世界坐标到像素坐标的映射

How: 张正友标定法

原理： 

1. 从世界坐标到像素坐标的映射包含了内参和外参，是一个$3\times 3$矩阵（单应矩阵$H$），有8个自由度（一个特征点的xy包含了两个方程，所以一共需要4个特征点）
2. 求出单应矩阵之后再分别求内参、外参

应用：通过棋盘格，棋盘格设为世界坐标系，并且边长也知道，因此世界坐标系的点坐标知道了，因为特征点多于4个，因此可以做优化

![image-20220403195604856](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-04-03-19-56-05.png)

## 推导

![image-20220403200521667](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-04-03-20-05-21.png)

利用单应矩阵的性质

* 旋转向量点积为0
* 旋转向量长度相等

通过两个等式，**用内参代掉外参**，然后只剩下内参，可以把内参求出来。

* 每张图片有2个方程

内参一共有6个未知数，需要最少3张图片

知道内参以后，外参也可以顺利求得

## Ref

https://zhuanlan.zhihu.com/p/136827980
