---
title: 双目相机校准
author: Junhan Hu
tags:
  - robotics
  - camera
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Computer Vision
autoEqnLabels: true
date: 2022-04-04 17:34:00
---

## Intro

Prerequisite: 将两个单目相机单独标定，得到了两个相机的内参和畸变参数

Goal: 就像人眼一样，需要知道两个相机的位置关系才能判断深度。两个相机并不是完全水平地放置，需要确定两者之间的R、T关系，修正视角使得两个图像中的位置在y方向一致

How：

1. Calibration for stereo camera set
2. Rectification, find R, T to make them aligned in the y-axis

## 原理

### stereoCalibrate

利用之前标定的两个相机的单独的内参，在标定时fix_intrinsic，只估计R，T，E（Essential），F（Fundamental）between two cameras

minimize re-projection error

### StereoRectify

Why：光轴不平行

Goal：光轴交点在无穷远aka光轴平行

利用两个相机的内参和相对位置，计算两个相机单独的旋转矩阵和映射矩阵使得两个相机中的y方向对齐（极线校正）

Bouguet算法 (OpenCV)

* 共面：使重投影误差最小
  * 为了减小畸变，两个相机各旋转一半，使得两个相机共面
  * 但是还不平行，即xy平面还不共面
* 行对准
  * 让主点($c_x,c_y$)作为左图像的原点，用矩阵转换到无穷远

