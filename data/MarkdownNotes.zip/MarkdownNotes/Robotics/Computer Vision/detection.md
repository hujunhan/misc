---
title: 目标检测
author: Junhan Hu
tags:
  - robotics
  - vision
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Computer Vision
autoEqnLabels: true
date: 2022-04-24 17:10:00
---

## 背景

两个子任务

* 分类
* 定位

## 发展脉络

1. 传统：HOG，DPM。速度慢、准确率不高
2. Anchor based，计算Anchor比较耗时，且固定anchor降低了普适性
   1. two stage：RCNN，选框、resize、CNN、SVM $\to$ SPPNET提高了速度$\to$ faster RCNN 提取一个ROI来做处理，再选择候选框 $\to$ FPN，在不同尺度上效果更好
   2. one stage：YOLO，速度快精度低；SSD加入不同的检测分支
3. Anchor free：
   1. CornerNet，将网络对边界框的检测转化为左上角、右上角的检测 $\to$ CenterNet, 检测目标中心点
   2. FCOS，不训练Anchor、不提Proposal

## 评价方法

IOU

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-04-24-17-25-50.png" alt="image-20220424172550611" style="zoom:25%;" />

Precision-Recall曲线

![image-20220424172649320](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-04-24-17-26-49.png)

面积越大，性能越好

mAP：越大越好，Mean Average Precision，考察了所有类的精度

## 难点

* 尺寸小
* 背景复杂
* 颜色对比度低

## 五大技术

* Multi-scale
* Bounding Box regression
* Context Prime
* NMS

## 模型加速

* 轻量化网络
  * 卷积分解、bottle-neck、神经架构搜索
* 模型压缩
  * 剪枝
  * Float to Int to Bool
  * 知识蒸馏
* 数值加速

## 提高精度

* 特征提取网络，对于性能非常重要
  * Backbone
* 特征融合
* 目标定位：微调、新的损失函数CIOU
* 语义分割
* 旋转和尺度变化

