---
title: 视觉目标跟踪
author: Junhan Hu
tags:
  - robotics
  - vision
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Computer Vision
autoEqnLabels: true
date: 2022-03-27 13:57:00
---

## Intro

给定目标在某一帧内的状态，估计目标在后续帧中的状态，三个方面

* 找到：在某个位置，颜色过滤
* 感兴趣物体：定义一些特征，表达、提取特征
* 后续帧：找到最像的物体，最重要的子问题

![image.png](https://ucc.alicdn.com/pic/developer-ecology/3c420a95c5f94b22bc188a75ae485bf7.png)

* 运动模型输入的是两帧，输出候选框
* 特征模型输出候选框+特征
* 观测模型：选择最像的

## 运动模型

如何表达位置？Bounding box

如何生成候选框？sliding window

## 特征模型

* 像素值
* 统计 hist
* 变换 梯度

有哪些特征提取方式？颜色特征、梯度直方图

* 手工特征
* **深度特征**

## 观测模型

如何做决策？最像的，匹配问题

如何做匹配？相似度度量，找最接近的候选框

* 生成式方法

  * 空间距离，像素灰度值的欧氏距离
  * 概率分布，颜色直方图的Bhattacharyya distance
  * 综合，

* **判别式方法**：性能更好，将目标试做前景，和背景分离，转化为二分类问题

  * 经典机器学习
  * 互相关
  * 深度学习

  

## 性能评估

IOU：交并比，越大说明效果越好



Thanks for the question. So your problem is: what means expand the application.

Here is the basic idea: once we co-operate with tea farms for tea harvesting, we will have the opportunity to work with farms on other fields. For example, to ensure the tea quality, we could build new product like tea examination machine to exclude low-quality tea leaf. What's more, pests would harm the tea leaf greatly, and our robots can be equipped with farm chemicals to protect the tea leaf.

By providing various automation product, tea farms could build a more modern procedure to make better quality tea with lower cost.





