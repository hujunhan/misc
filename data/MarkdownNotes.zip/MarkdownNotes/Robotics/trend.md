---
title: Robotics Trend
author: Junhan Hu
tags:
  - robotics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
date: 2022-11-09 17:02:00
---

## Robot Own Code

For robot, the detection and sequencing commands can be time consuming

A program generate code from description

* PALM
* Generate full expression of general-purpose python code

![image-20221108144018994](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419220642_Y56XTU.png)

BAD research

## Learning Safe in real world

Satisfying safe constrains

* Where is the constrain come from? Manual Generated
* How to perform? A safe recovery policy learner
  * tretrTrain the model with rewarding stability

![image-20221108145410152](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419220642_5mO0Z8.png)

## Robot See, Robot Do

Given a video of human task, then let robot learn the task and perform

Learn what? An embodiment invariant reward function

* Method? Temporal cycle-consistency objective

## NeRF (Rendering)

Data driven solution to realistic rendering

Neural volume rendering, generate image by tracing a ray and taking integral

Prelude: using a neural network to define an **implicit surface** representation

Physics based modeling

