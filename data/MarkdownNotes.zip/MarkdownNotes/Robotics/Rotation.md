---
title: 旋转矩阵
author: Junhan Hu
tags:
  - rotation
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
date: 2021-12-12 21:11:00
---

## 旋转矩阵

旋转方式

* 绕自身旋转（右乘变换矩阵）
* 绕固定轴旋转（左乘变换矩阵）

> 比如说RPY，绕XYZ旋转，如果是绕自身，那就是
> $$
> R_x()R_y()R_z()
> $$
> 如果是绕固定轴，那就是
> $$
> R_z()R_y()R_x()
> $$

