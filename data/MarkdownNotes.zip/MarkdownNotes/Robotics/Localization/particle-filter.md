---
title: LiDAR Particle Filter
author: Junhan Hu
tags:
  - hardware
  - lidar
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Localization
date: 2023-01-17 01:00:00
---

## How

Given a observation, we can have a distribution

How to transform from multiple observation to a estimation?

[Particle filter](https://www.youtube.com/watch?v=NrzmH_yerBU&list=PLn8PRpmsu08rLRGrnF-S6TyGrmcA2X7kg&index=2)

* Random pose
* Measure the similarity
* Resample
* Update

## What if NO map

We need SLAM

Two kind

* Filtering: EKF, particle
  * Only estimate based on the latest observation
* Smoothing: pose graph optimization
  * Optimize the whole trajectory

---

Pose Graph Optimization

* Consider each move, the confidence is set by how much we trust the odometry

![image-20230117012032788](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230117012032.png)

* Key: align the feature that detected in different pose

