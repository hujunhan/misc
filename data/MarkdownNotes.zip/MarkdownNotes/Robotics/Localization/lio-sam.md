---
title: LIO-SAM
author: Junhan Hu
tags:
  - slam
  - lidar
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Localization
date: 2023-03-15 11:29:00
---

## What

Lidar SLAM coupled with IMU and GPS (optional)

## Components

![LIO-SAM 基本流程](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419215859_zlrbiw.png)

* ImuPreintergration
* ImageProjeection
* Feature Extraction
* MapOptimization

Two odometry

* Incremental, use only local matching
* Global, for loop detection and optimization

## IMU

* Input: raw IMU, lidar odometry output
* Output: local IMU odometry, global IMU odometry

![IMUPreintegration 类](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419203801_PxC1wc.png)

* imu: used to directly calcualte the pose
* imuOpt: used to optimization

## ImageProjection

* Input: raw IMU, IMU odometry output, and raw point cloud
* Output: corrected point cloud with related index

## Feature Extraction

Almost the same as LOAM

* corner point
* plane point

## MapOptimization

Input: Point Cloud, GPS

Output: lidar odometry (global and incremental)

* Main thread
* loop detection loop

