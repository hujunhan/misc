---
title: Generalized ICP
author: Junhan Hu
tags:
  - robotics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Localization
date: 2023-05-31 22:46:21
---

## Intro

Combine ICP and point-to-plane ICP into a single probabilistic framework

* More robust to incorrect correspondence
* Easier to tune the maximum match distance

## How it works

Align two point sets in 3D space

* by minimizing the distance
* Extends ICP by allowing more general types of correspondaences

## Standard ICP

![image-20230531230520928](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230531230521_hcUb4D.png)

## Point-to-Plane

Update the T calculation process (Line 11)
$$
T \leftarrow \underset{T}{\operatorname{argmin}}\left\{\sum_i w_i\left\|\eta_i \cdot\left(T \cdot b_i-m_i\right)\right\|^2\right\}
$$
Taking the surface normal information

## GICP

Also improved the Line 11

Attaching a probabilistic model

* Correspondence: computed with Euclidean distance
  * Use of KD-tree and speed up

## NDT?

NDT represents the entire point cloud as a collection of Gaussian distributions.

1. divide the 3D space containing the point cloud into a grid of cells 
   1. Each cell that contains at least one point is then represented by a Gaussian distribution
2.  iteratively revises the transformation (translation and rotation) to minimize the difference between the two point clouds.
