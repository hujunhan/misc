---
title: Lidar Kidnap Robot Problem
author: Junhan Hu
tags:
  - slam
  - lidar
  - localization
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Localization
date: 2023-05-27 22:28:00
---

## Intro

Problem:

* have the learned 3D lidar point cloud map
* given a single frame (lidar scan) from lidar
* calculate current robot position and pose (without knowing initial pose)

## Review

[Ref](https://arxiv.org/abs/2302.07433)

Map

* Keyframe-based submaps
* Global feature map
* Global metric map

Single shot localization

* Place Recognition: match the keyu frame
* Place Recognition and Local Pose Estimation
* Pose Estimation coupled Place Recognition
* One stage global estimation

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230528013339_anUzXY.png" alt="image-20230528013339621" style="zoom:33%;" />

![image-20230528013453090](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230528013453_bcLnsY.png)

## Scan Context

## SegMatch

