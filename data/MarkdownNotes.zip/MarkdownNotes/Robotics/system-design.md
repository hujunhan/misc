---
title: System Design Thinking
author: Junhan Hu
tags:
  - system
  - design
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
date: 2023-08-12 18:21:00
---

## Intro

Why? From an engineer view, I am always designing some system, from small to large

The problem is, although it seems I solved the problem, that's mainly from intuition. Sometimes it turns out my design is bad and hard to maintain.

My goal is to learn a systematic way for system design

### Why?

Ultimately, I am looking for a solution method to problem, how to solve problem.

Maybe that's the **algorithm** 

## ~~Materials~~

~~Books~~

* ~~**Thinking in Systems: A Primer**~~
* ~~**The Systems Bible: The Beginner's Guide to Systems Large and Small**~~
* ~~**The Systems View of Life: A Unifying Vision**~~

## ~~Thinking in System~~

~~This book seems not broad and well constructed~~

### ~~Structure and Behavior~~

### ~~System and Us~~

### ~~Creating Change~~

## ~~Algorithm to Live By~~

~~How to develop a solution to problem?~~

## Takeaways

Based on these days research, I think the system design is a too broard subject.

Asking the right question is more important

1. What is the problem、
   1. Why the problem exist
   2. Who involved
2. How to solve the problem
   1. What are the constraints
   2. How to measure success
   3. Assumption we made
3. What properties should the solution have
