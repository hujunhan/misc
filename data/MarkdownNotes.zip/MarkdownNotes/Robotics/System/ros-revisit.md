---
title: ROS Re-visit
author: Junhan Hu
tags:
  - ros
  - software
mathjax: true
date: 2023-07-24 22:13:00
categories:
  - MarkdownNotes
  - Robotics
  - System
---

## Intro

ROS is too heavy for new project with little dependence on open-source project.

Plan: Understand the design and philosophy of ROS1 and ROS2, design my own robotics stack

## ROS1

### Philosophy and Design Principles

Goal: to support code reuse in robotics

* as thin as possible? Really?
* ROS-agnostic
* Scaling
* Test, Language

How: Node for executables to be run individually

### Architecture

[Ref](http://wiki.ros.org/ROS/Introduction)

Two concepts

Filesystem:

1. Package
2. Metapackage
3. Package Minifests
4. Repositories
5. Message Type
6. Service Type: request and response

Computation Graph:

* Node
* Master: name registration, help node find each other
* Parameter Server: allow data store in central location
* Message: Nest data
* Topics: one way
* Services: good for request reply interaction
* Bags: storing data

### Middleware

* Master is implemented via XMLRPC, HTTP based protocal
* Node
  * Slave API: XMLRPC API, receiving callbacks
  * Topic transport protocal: TCPROS, UDPROS
  * Command-line API
* Topic: TCP, UDP
* Message serialization:

## ROS2

[Ref](https://design.ros2.org/)

Why?

* Multiple Robots
* Less computation
* Real time
* Non ideal network
* Production
* Clear pattern
* New API
* Use open-source middleware

Most important change: use DDS as middleware

## New

new middleware

new build (ament)

c++11

### Philosophy and Design Principles

De-centralized nature

### Architecture

Very similar with ROS1, but add discovery

![ros-architecture](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230725223812_NDEQ4C.jpg)

### Middleware

Apply open-source software

Has a abstract middleware interface

DDS: end2end middleware

* Publish, subscribe transport

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230725222521_mizr90.png" alt="api_levels" style="zoom:38%;" />

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230725223717_BphaUG.png" alt="img" style="zoom:33%;" />