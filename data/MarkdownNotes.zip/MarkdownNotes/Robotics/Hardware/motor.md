---
title: Motor In Robots
author: Junhan Hu
tags:
  - hardware
  - motor
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Hardware
date: 2022-11-07 22:06:00
---

## Why

Method: test the single motor first and then deploy it to real robot

Any problem can be solved using a layered abstraction

## Motor Types

AC Motor, taken from AC, application in industrial

* Higher power, higher torque

**Brushed and Brushless DC**

* Brushed
* Brushless: smooth, no noise, efficient, high speed

Geared-: Speed reduction

**Stepper/Servo**: highest precision

## Control the Motor

1. Motor, can't de anything
2. Supply Voltage, the motor can move
3. Motor Driver, take low voltage and output high voltage
4. Motor Controller, take practical input and output real signal
5. Open-loop control, feedback control, encoder, at a precise speed
6. Communication layer, serial
7. Robot controller
   1. Driver software,

![image-20221107222539340](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-11-07-22-25-39.png)

Keep the system more modularity, easier to swap the components

---

## For Robot

How to choose?

* Torque, know the load of your robot
* Speed, on mobile robot, trade off between torque and speed
* Accuracy,
* Voltage, check the nominal volt, the mainstream

## How to Master Robotics

Stage 1

* Programming
* Assembly
* Electronics

Stage 2

* OO-programming
* Math and Physics
* Linux
* Embedded System

Stage 3

* Algorithm
* Library
* ROS
* Design：need a mechanical expert

Stage 4

* Technology that fascinating
* Work on various tool
* Work with as many single board as  possible
* Maintain the project gut hub

## Speed, Torque, Current

[Ref](https://www.youtube.com/watch?v=STdONYFI2C4&t=266s)

First, there is current, the current in the magefield would generate force

If there is movement, it would generate a oppose voltage (current)

* Faster, the current would be less
* Stall, the largest current

![image-20221119214701264](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-11-19-21-47-01.png)

Try to keep in the left half



