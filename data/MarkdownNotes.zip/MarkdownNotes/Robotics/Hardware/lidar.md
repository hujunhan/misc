---
title: LiDAR In Robots
author: Junhan Hu
tags:
  - hardware
  - lidar
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Hardware
date: 2022-12-03 01:06:00
---

## Intro

Lidar is important for mobile robot to achieve the obstacle avoidance and navigation system

## How it Works

Light Detection And Ranging

Determined by the travel time to calculate the distance

---

Lidar works great indoor and outdoor

Ultrasonic is great for indoor use only, and the sensor would be very noisy for some object



 