---
title: Encoder
author: Junhan Hu
tags:
  - hardware
  - encoder
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Hardware
date: 2022-12-06 21:45:00
---

## Intro

Usage

1. Active, can be used as motor controller, like a physical button to tell the system how much speed/volume you want
2. Passive, can be used as a motor sensor, reading the rotation of a motor, can be further calculated as angular speed

![image-20221206215355653](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-12-06-21-53-55.png)

## Usage

Typically, the encoder on a motor would have 4 channel,

* VCC: in general, 5V
* GND: ground
* ChA and ChB, two channel of the encoder that output PWM
  * two channel can be used at same time to determine the direction of motor
  * In reality, only ONE channel is enough since the direction is controlled by the controller (us)

## Resolution

Resolution need to be known to calculate the speed

### PPR

Pulses Per Revolution

Describe the number of high pulse an encoder will have over a single revolution

![image-20221207215312381](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-12-07-21-53-12.png)

### CPR

Counts Per Revolution

![image-20221207215255380](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-12-07-21-52-55.png)

## Datasheet

![image-20221207233224754](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-12-07-23-32-25.png)

Gearbox output shaft shows 751.8, but when I rotate the wheel for a revolution, the encoder increased by around 180, what's wrong?

* There are two channel A/B

* Each square wave would have two pulse (although only one is rising)

* So 751.8/4=187.95, that's right :white_check_mark:

  [Ref](https://www.reddit.com/r/FTC/comments/aity1l/how_many_encoder_pulses_in_a_gobilda_motor/)
