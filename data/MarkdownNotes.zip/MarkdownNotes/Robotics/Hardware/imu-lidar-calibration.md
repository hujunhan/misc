---
title: Calibration Between Lidar and IMU
author: Junhan Hu
tags:
  - hardware
  - imu
  - lidar
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Hardware
date: 2023-05-27 16:04:00
---

## Intro

Goal: calibrate between leishen lidar C16 and 6 axis IMU

Ref: [unmannedlab/imu_lidar_calibration: Target-free Extrinsic Calibration of a 3D Lidar and an IMU (github.com)](https://github.com/unmannedlab/imu_lidar_calibration)

## Theory

[Ref](https://www.youtube.com/watch?v=VIc8XxNrymQ)

Goal: estimate the extrinsic
$$
T_L^I=\left[\begin{array}{cc}
R_L^I & { }^I \mathrm{P}_{\mathrm{L}} \\
0 & 1
\end{array}\right]
$$
Step:

* Rotation Estimation

  ![image-20230527162339584](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230527162339_DjJ4cJ.png)

  Motion of Lidar = Motion of IMU

  <img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230527162708_h52OIr.png" alt="image-20230527162708340" style="zoom:50%;" />

* Tranlation Estimation

  Refine the rotation and translation

  ![image-20230527163220016](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230527163220_Cp8rj9.png)

  the key state is from Lidar data

  Minimize the data in a EKF process

System design

## Data Analysis

The data sample

![image-20230527172131502](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230527172131_SoemvE.png)

Ours

![image-20230527172251129](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230527172251_cSXtgc.png)

![image-20230527174240241](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230527174240_VWkk67.png)

roll, pitch, azimuth

### difference between azimuth and yaw

while the yaw is turn from current orientaion

the azimuth is the absolute heading

[Ref](https://novatel.com/solutions/attitude)

## 