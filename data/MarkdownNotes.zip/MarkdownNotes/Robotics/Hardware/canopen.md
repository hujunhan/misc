---
title: CANopen Protocal
author: Junhan Hu
tags:
  - hardware
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Hardware
date: 2023-04-19 22:49:00
---

## What

High-level communication protocol, based on CAN

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419225002_3nfOZs.jpeg)

## Application Layer

Central themes of CANopen is the object dictionary

* 16bit index
* 8bit sub-index

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419230342_GukETu.jpeg)