---
title: Differential Drive
author: Junhan Hu
tags:
  - hardware
  - motor
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Hardware
date: 2022-11-10 00:03:00
---

## Why

[Ref](https://www.youtube.com/watch?v=nC6fsNXdcMQ)

Make two wheels rotate at different speed

Standard differential

![image-20221110000619593](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-11-10-00-06-19.png)