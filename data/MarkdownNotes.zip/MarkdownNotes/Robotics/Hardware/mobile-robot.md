---
title: Mobile Robot Design
author: Junhan Hu
tags:
  - hardware
  - robot
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Hardware
date: 2022-11-10 00:28:00
---

## Intro

Mobile robot

Requirement:

* High torque
* Compact size
* Durability
* Low nose
* High efficiency

## Motion system

Brushless DC motor with gearbox

Output

* Torque: 4-8 Nm
* Speed: 50-150 rpm

