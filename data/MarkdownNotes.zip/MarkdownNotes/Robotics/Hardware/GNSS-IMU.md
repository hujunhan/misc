---
title: GNSS-IMU Calibration
author: Junhan Hu
tags:
  - hardware
  - sensor
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Hardware
date: 2023-03-16 22:04:00
---

## 测试流程

1. Windows上用上位机查看数据，确保能获取IMU数据
2. ROS包安装，录制数据
3. 校准

## ROS

Lidar, IMU ROS package

```bash
sudo apt install ros-XXX-serial
```

Fix the port name for IMU

```bash
echo KERNEL=E"ttyUSB*", ATTRSfldVendor}=="10c4", ATTRStLdProduct)=="ea60",ATTRS(ser1al)=="0003", MODE:="0777", GROUP:="dialout",SYMLINK+="fd1Link_ahrs"' >/etc/udev/rules.d/fdtLink_ahrs.rules

service udey reload

sleep 2

service udev restart
```



