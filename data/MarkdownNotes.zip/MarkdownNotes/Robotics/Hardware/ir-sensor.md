---
title: IR Remote
author: Junhan Hu
tags:
  - hardware
  - ir
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Hardware
date: 2022-12-19 21:39:00
---

## Intro

IR use light to transmit data

![image-20221219213927203](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-12-19-21-39-27.png)

Light used is infrared

* inexpensive
* subject to interference 
  * Sunlight would interference the IR

Data are modulated in 38K Hz (usually)

![image-20221219214112137](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-12-19-21-41-12.png)

Each button sends a unique code

## Test

### Sender

How to see if the controller works？

* Human eye can't see the light
* Camera can see it (phone)

### Receiver

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-12-19-22-16-09.png" alt="image-20221219221609056" style="zoom:33%;" />

## Code

```cpp
#include <boarddefs.h>
#include <IRremoteInt.h>
#include <ir_Lego_PF_BitStreamEncoder.h>
#include <IRremote.h>

int RECV_PIN = 11; // the pin where you connect the output pin of IR sensor     
IRrecv irrecv(RECV_PIN);     
decode_results results;     
void setup()     
{     
Serial.begin(9600);     
irrecv.enableIRIn();     
}     
void loop()     
{     
if (irrecv.decode(&results))// Returns 0 if no data ready, 1 if data ready.     
{     
 //int value = results.value; ;// Results of decoding are stored in result.value     
 Serial.println(" ");     
 Serial.print("Code: ");     
 Serial.println(results.value,HEX); //prints the value a a button press     
 Serial.println(" ");     
 irrecv.resume(); // Restart the ISR state machine and Receive the next value     
}    
}
```

