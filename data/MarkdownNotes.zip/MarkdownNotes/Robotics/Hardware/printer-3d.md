---
title: 3D打印机选型
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Hardware
date: 2022-05-20 10:59:00
---

## 基础

目的：快速制造原型

工艺：FDM（fused deposition modeling）

大小：越大越好，通常来说6-9inch(15cm-23cm)

材质：塑料丝热熔堆积

* ABS（ acrylonitrile butadiene styrene），更坚固，但是需要的温度更高，会有味道
* PLA （polylactic acid），更脆弱一点

分辨率：目前基本都有200 microns （0.2mm），好一点的100microns

底板：打印的时候沾的牢，打印完了方便拿下来

* 常见：加热（防止底边翘起来）的玻璃板+胶带

闭合空间：需不需要全封闭的空间

* 闭合的更安全、更安静、更无味

## 本次打印目标

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-05-21-10-18-45.png" alt="image-20220521101845583" style="zoom:20%;" />

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-05-21-10-30-43.png" alt="image-20220521103043098" style="zoom:25%;" />

多角度相机测试平台

大小：200x200x100mm

材料：ABS、PLA

## 备选

| 名称                                                         | 价格 | 打印大小    | 分辨率 | 图片                                                         | 特点                             |
| ------------------------------------------------------------ | ---- | ----------- | ------ | ------------------------------------------------------------ | -------------------------------- |
| [Ender3 v2](https://www.creality.com/products/ender-3-v2-3d-printer-csco) | 259  | 220x220x250 | 0.1mm  | <img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-05-20-17-28-11.png" alt="image-20220520172811076" style="zoom:5%;" /> | 便宜，用户多，可扩展性强         |
| [Monoprice Voxel 3D Printer](https://www.amazon.com/Monoprice-133820-Voxel-Printer-Removable/dp/B07GV5GLLC/ref=psdc_6066127011_t2_B098N6JZGD) | 389  | 150x150x150 | 0.05mm | <img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-05-21-11-09-12.png" alt="image-20220521110911886" style="zoom:10%;" /> | 全封闭打印，体积较小             |
| [Ender3 S1](https://www.creality.com/products/creality-ender-3-s1-3d-printer) | 399  | 220x220x270 | 0.1mm  | <img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-05-21-10-58-00.png" alt="image-20220521105800019" style="zoom:10%;" /> | 用户多，自动调平底板，容易组装， |
| [Flashforge 3D Printer Adventurer 4](https://www.amazon.com/dp/B098N6JZGD?tag=georiot-us-default-20&th=1&psc=1&ascsubtag=tomsguide-us-3354148051582835000-20&geniuslink=true) | 799  | 220x200x250 | 0.1mm  | <img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-05-21-11-04-46.png" alt="image-20220521110446042" style="zoom:10%;" /> | 全封闭打印                       |

