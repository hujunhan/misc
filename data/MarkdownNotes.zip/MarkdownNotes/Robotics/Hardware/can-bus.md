---
title: CAN Bus
author: Junhan Hu
tags:
  - hardware
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Hardware
date: 2021-10-31 13:50:00
---

## What 

Like the nerve system in human body

* ECU like the body parts
* Sensor can broadcast the data and share in the can bus

Hardware level

* CAN High
* CAN Low

## Why (Main Benefical)

1. Simple and Low cost
2. Fully Centerlized
3. Extremely Robust (抗干扰)
4. Effcient, with priority ID

## History

BOSCH CAN 1986

CAN 2.0 1991 

International standard 1998

## Message / Frame

8 fields

1. SOF
2. CAN ID
3. RTR
4. Control, extension for ID
5. Data, actual information
6. CRC, redundancy check
7. ACK
8. EOF

## Record and Decode

ID and Data, use a logger



## Ref

https://www.youtube.com/watch?v=oYps7vT708E



