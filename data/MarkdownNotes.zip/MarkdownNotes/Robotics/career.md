---
title: Career in Robotics
author: Junhan Hu
mathjax: true
date: 2022-11-12 15:36:00
categories:
  - MarkdownNotes
  - Robotics
---

## Amazon Robotics

All kinds of role

General skills

* Science heavy
* Computer Vision
* Machine Learning / Deep learning
* Navigation

Highlight the research experience

Be prepared

Not only what you do, but **WHY** you do

Focus on the impact and goodness

## Boston Dynamics

1. System thinking, you need to understand different things
2. Focus on the problem what you are trying to solve
3. ROS, something like that
4. How to use unit test, docker, git, 

---

Watching video and understand what people are talking about

The best way to learn something is doing a project

