---
title: MPC Control for Mobile Robot
author: Junhan Hu
tags:
  - robotics
  - control
mathjax: true
date: 2023-03-21 20:52:00
categories:
  - MarkdownNotes
  - Robotics
  - MobileRobots
---

## Intro

Feedback control

* Use the model of the system to predict its behavior
* Compute an optimal control input that minimize a given cost function
* Subject to constrainsts

Basic Idea: 

* formulate a dynamic optimization problem
  * tracking trajectory
  * regulating process variable
  * minimize energy consumption

Advantage:

* Handle system with nonlinear dynamics and constraints
* explicitly use the model of system
* Handle multivariable system
* Handle time-varying parameters

## For Car-like Control

Trajectory

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230321210501.png" alt="image-20230321210500789" style="zoom:33%;" />

yaw

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230321210639.png" alt="image-20230321210639873" style="zoom:33%;" />

1. init, find the closet point

2. In each step

   1. get reference point (next few points)

   2. Use the MPC control

      1. predict the motion

      2. formulate the optimization problem

         1. constraints
         2. cost function

      3. solve
   3. Update car state

## Wheel Steer

In the MPC, we used a simplified car model (bicycle model), there are only two wheels (front and back) in the car. Here is the problem

* Given front and back steer, how to calcualte the real steer the car should go?

![image-20230410202402763](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230410202402.png)

Almost the same, but in opposite direction

![image-20230410205220309](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230410205220.png)
