---
title: Steering System for Mobile Robot
author: Junhan Hu
tags:
  - robotics
  - control
mathjax: true
date: 2023-03-15 15:22:00
categories:
  - MarkdownNotes
  - Robotics
  - MobileRobots
---

## What

Steering system are mechanisms that control the direction of movement

Goal: Control direction, maintaining stability and safety

## Common Type

* Rack and pinion: translate rotation into linear motion

  ![What Actually Is Rack And Pinion Steering?](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419220310_C2a8Dk.jpg)

* Recirculating ball steering: worm gear and sector gear, convert rotational motion into linear motion

  ![Recirculating-ball Steering - How Car Steering Works | HowStuffWorks](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419203854_Ml9v7f.jpg)

* Ackermann steering:  used in tractors and heavy-duty vehicles, all turn smoothly

  ![Ackermann steering geometry - Wikipedia](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419203854_MVoRbU.png)

* Differential steering: use two separate motors to drive each size

  ![Differential steering - Wikipedia](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419203855_pnxRPj.png)

* Skid steering, control the speed and direction, no turn

  ![PDFs Comparison of Skid Steering Vs. Explicit Steering for a  Wheeled Mobile RobotSemantic Scholar](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419220310_FNwa7e.png)

* Crab steering: all wheels turned in the same direction, it can move sideways

  ![Why is crab steering a thing? : r/farmingsimulator](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419203857_AhJHfS.jpg)

## All in One: Four-wheel Steering

All four wheels are steered to improve the maneuverability

