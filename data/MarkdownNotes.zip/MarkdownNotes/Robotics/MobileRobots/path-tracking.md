---
title: Path Tracking for Mobile Robot
author: Junhan Hu
tags:
  - robotics
  - control
mathjax: true
date: 2023-03-21 10:22:00
categories:
  - MarkdownNotes
  - Robotics
  - MobileRobots
---

## Intro

Path tracking for car-like robot

Or can be called as vehicle lateral control

Some most common method

* PID control
* Stanley controller, based on cross-track error and heading error
* Pure pursuit, based on current position and a point
* Model predictive control(MPC), use a model of the vehicle dynamics to predict the future behavior, then optimize the control input
* Linear Quadratic Regulator (LQR), use a linearized model to calculate the optimal control input

## Compare

| Method       | Pro                                | Con                                                         |
| ------------ | ---------------------------------- | ----------------------------------------------------------- |
| PID          | simple<br />good for linear system | stability issue                                             |
| Stanley      | simple<br />capable                | sensitive to parameter tuning<br />not good with sharp turn |
| Pure Pursuit | simple<br />good for low speed     | suffer from oscillation                                     |
| MPC          | capable, optimize                  | Computationally expensive                                   |
| LQR          | optimize                           | linearized model                                            |

## Pure Pursuit

Geometric path tracking controller

Look ahead point: A fixed distance on the reference path ahead of the vehicle

Reference point of vehicle: the center of rear axle

Target point: 

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419220100_Cnb8GC.png" alt="img" style="zoom:33%;" />

## Stanley Controller

CTE: cross-track error

Reference point of vehicle: the center of front axle

Cost: heading error + cross-track error

Control logic

1. Eliminating the heading error
2. Eliminating the cross-track error
3. Clip the steering to bond

## MPC

Define the cost function

* deviation from the reference path
* control command magnitude

Predict the future evolution of the system:

* update the system state
  * x, y, $\theta$, $\delta$

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230419203814_etwf0u.png)