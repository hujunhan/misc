---
title: Part Learning in Mechanics
author: Junhan Hu
tags:
  - mechanics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Mechanical
date: 2023-01-13 22:50:00
---

## M Socket

Counterbore, 沉孔

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230113225140.png)

Clearance Hole，穿孔

![image-20230113225321213](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230113225321.png)

## 3D construction

Chamfers，倒角

![Fillet vs Chamfer: Basic Operations & Cad Design Features 2022 - Aria |  Custom Plastic injection molding, CNC Machining Aluminum & Sheet Metal  Services](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230114185845.png)