---
title: 零件设计疑惑
author: Junhan Hu
tags:
  - mechanics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Mechanical
date: 2022-04-14 22:08:00
---

## Intro

最近开始学习机械画图，但画图不是目的，目的是做出能够工作的机械零部件

练习项目：相机外壳

已经有的：PCB和相机

目标：相机的外壳，分别对PCB和相机，也就是说两个壳体

## Problem

由于不是机械出身，对于一些设计时候需要经验的地方就无从下手

相机外壳设计遇到的问题

- 设计冗余量怎么确定：
  - 专业术语叫公差、配合
- 壳体厚度怎么确定：
  - 看设计，和大小有关。这里设计的相机比较小，厚度1.5mm或者2mm就够了
- 排线能否在相机段插拔，
  - 设计时要考虑加工的难易程度，尽量设计简单易加工的。比如说，我本来的想法是给排线设计一个孔，但是加工孔的难度较大，那么应该设计一个槽，加工就容易很多
- 什么时候用倒角圆角，0.5
  - 从安全、美观角度来说应该多使用。比如说直角容易划破排线、对于人来说也很危险，因此要使用倒角。倒角的半径设计：不能太大（大于厚度不行），不能太小（小了没用）
- 稳定的连接，一般需要螺丝多长
  - 看壳体厚度

## Fit and Tolerance

设计时我们希望不同的部件是怎么样配合在一起的？紧密的？松垮的？

公差-告诉加工人员多大的误差是可接受范围。精度要求越高，成本指数上升

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-04-14-22-50-44.png" alt="image-20220414225044634" style="zoom:10%;" />

根据需求选择合适的配合

<img src="https://249261-772960-raikfcquaxqncofqfm.stackpathdns.com/wp-content/uploads/2021/03/flow-chart-of-the-types-of-fits-.jpg" alt="flow chart of the types of fits" style="zoom:25%;" />

---

想到的问题

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-04-14-23-51-24.png" alt="image-20220414235123855" style="zoom:33%;" />

过盈配合，稍微大一点也是可以装配的

