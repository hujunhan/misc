---
title: 3D Reconstruction with Meshroom
author: Junhan Hu
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Vision
date: 2021-12-14 14:38:00
---

## Meshroom

>Photogrammetry is the science of making measurements from photographs. It infers the geometry of a scene from a set of unordered photographies or videos. Photography is the projection of a 3D scene onto a 2D plane, losing depth information. The goal of photogrammetry is to reverse this process.
>
>The dense modeling of the scene is the result yielded by chaining two computer vision-based pipelines:
>“Structure-from-Motion” (SfM) and “Multi View Stereo” (MVS).

## Pipeline

1. Feature extraction
   1. Goal: extract feature points
   2. Method: SIFT
2. Image matching
   1. Goal: find images looking to the same area, then we can reduce computation
   2. Method: Vocabulary tree approach
3. Feature matching
   1. Goal: match feature points between candidate image pairs
   2. Method: calculate distance and use RANSAC
4. Structure from Motion (SFM)
   1. Goal: compute the pose of each images
   2. Methods: 
      1. Fuse all matched feature point pairs
      2. Choose the best initial image pair
      3. Compute the fundamental matrix
      4. Using PnP to calculate the pose
      5. Filter the results using Bundle Adjustment
5. Depth Maps Estimation
   1. Goal: get the depth value of each pixel
   2. Method: Semi-Global Matching
6. Meshing
   1. Goal: create geometric surface representation of the scene
   2. Method: 
      1. Fuse all depth maps into global octree
      2. Perform 3D Delaunay tetrahedralization (四面体化), then voting
      3. Graph cut Max-Flow, optimally cut the volume
7. Texturing 
   1. Goal: texture the generated mesh
   2. Method:
      1. Compute UV maps
      2. For each triangle, use the color of each candidate to estimate

## Data Acquisition

Goal: Clear images from different angles

Camera setting

* Fixed **low** ISO (low noise)
* Fixed **high** shutter speed (less then 1/100s, no blur)
* Fixed **long** focal length (everything is in focus)
* Fixed white balance  (stable image color for feature matching)
* Enough lighting (so that we can keep low iso and high shutter speed)

Move:

* Camera fixed, object move
  * will need a spin base
  * keep the background pure color

* Camera move, object fixed
  * Shot around the object (360 degree)
  * In each spot, shot from 3 different heights

Illustration:

![Whiteboard_20211214T151703](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2021-12-14-15-17-16.png)

## Results

![2021-12-14-16-39-18](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2021-12-14-16-39-18.gif)

The final results of Meshroom is pretty unstable

* In many cases, even high quality images dataset can not generate satisfied results
* However, when the algorithm works, it can generate detailed mesh and texture.

## Discussion

Why performs bad?

I think the main reason is the object itself. For the leaf object, it has a few features that make the algorithm doesn't work

* The leaf is so thin. It's hard to generate a plane using point cloud
* The leaf is semi-transparent, it will look differently from different angle
* The leaf skin is so smooth that would generate reflection

How to solve the problem? (Possible solution)

* Using laser to generate point cloud (to capture textureless feature)
* Create great lighting system, try to avoid reflection and semi-transparent situation
