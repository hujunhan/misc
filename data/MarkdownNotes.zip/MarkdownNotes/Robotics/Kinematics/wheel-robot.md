---
title: Kinematics for Wheeled Robot
author: Junhan Hu
tags:
  - robotics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Kinematics
date: 2023-03-16 20:46:21
---

## Basic

Goal:

* FK
* IK

Math:

* Wheel
  * w: angular speed
  * v: linear speed
* Frame
  * world
  * vehicle
  * steer
  * contact
* Car:
  * Yaw: defined by the car pose and world frame
  * Heading: defined by the path
  * Curvature: the 2nd directvie of path

## Steering

More freedom joint $\to$ over determined configuration

ICR: instance center of rotation

**ALL motion can be considered as a rotation around some point**

![image-20230317004047578](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230317004047.png)

## FK

![image-20230317004124761](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230317004124.png)

