---
title: Trac-IK Paper Review
author: Junhan Hu
tags:
  - robotics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Kinematics
date: 2023-03-04 20:58:21
---

## Goal

In the paper, author compared some common open-source project address the kinematics problem. I want to know

* Which optimization method is used behind these popular project
* How these project compared to each other

## Introduciton

The main purpose if trac_ik is to improve the popular KDL

Issue with KDL

* convergence failure
* stuck in local minima
  * loop for maximum **time** rather than **iteration**
  * Detect by $q_{next}-q_{prev}\approx 0$ 
    * Change to a random seed

* Failure with joint limit
  * solved with SQP sequential quadratic programming

* no utilization of tolerance

## Candidate IK Algorithm

* KDL-RR

  * Random Restart
  * maximum time

* SQP: SLSQP with BFGS
  $$
  \arg \min _{q \in \mathbf{R}^n}\left(q_{\text {seed }}-q\right)^T\left(q_{\text {seed }}-q\right),
  $$

* SQP-DQ: dual quaternion

  * combine the translation and orientation

  * $$
    \phi_{D Q}=4\left((\log \hat{e}) \cdot(\log \hat{e})^T\right)
    $$

* SQP-SS and SQP-L2, $p$ as simple 6-element vector

  * SS: $\phi_{S S}=p_{e r r} \cdot p_{e r r}^T$
  * L2: $\phi_{L 2}=\sqrt{p_{e r r} \cdot p_{e r r}^T} .$

* Trac-ik

  * Run two algorithm at once
    * SQP-SS
    * KDL-RR
  * Use the fastest one

  

