---
title: General Path Planning (Advanced)
author: Junhan Hu
tags:
  - robot
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Planning
date: 2023-04-04 13:11:00
---

## Goal

Choose the most suitable path planning algorithm for mobile robot

### Graph-Search

Discrete approximation

* Optimally efficient

Con:

* quality depends on discretization
* Suffer in high-dimensional spaces

### Sampling-Based

No discretization

Scale well in higher dimensions

Con:

* random lead to long computation times

## Timeline

* Dijkstra: 1956
* A*: 1968
* RRT: 1998
* RRT*: 2010
  * Store the distance info
  * Tree would be rewired
* CHOMP: 2013

## Some New Algorithm

* FMT
* Informed RRT*
  * Narrow search space
  * Subproblem defined by a ellipse
* BIT: find a balance between graph and sample 

![image-20230404133447946](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230404133448.png)

## BIT Algorithm

1. Init the tree with start point
2. Batch creation, create new sample
3. Edge selection, processing the $Q_E$, find the best edge
   1. $Q_V$, the vertex expansion queue
4. Edge Processing
   1. check if can improve current soluition
5. Vertex Expansion
   1. remove a vertex from the queue and 
   2. Adds outgoing edge from the vertex to the edge queue
6. Graph Pruning
   1. remove states that cannot provide a solution better than the given cost

### Ref

[Python实现-BIT*-Batch Informed Tree 运动规划算法_海晨威的博客-CSDN博客](https://blog.csdn.net/songyunli1111/article/details/102808704)

```python
while self.BestVertexQueueValue() <= self.BestEdgeQueueValue():
	result = self.BestInVertexQueue()
	self.ExpandVertex(result)
```

Only expand when current point's value is better than the point in the current tree

```python
if (
  self.g_T[vm] + self.calc_dist(vm, xm) + self.h_estimated(xm)
  < self.g_T[self.x_goal]
  ):
  actual_cost = self.cost(vm, xm)
  if (
      self.g_estimated(vm) + actual_cost + self.h_estimated(xm)
      < self.g_T[self.x_goal]
  ):
      if self.g_T[vm] + actual_cost < self.g_T[xm]:
```

Check the vvalue of a edge, should add it to tree or not

## Problem

### Empty QV

Too little sample point, increase the sample size solve the problem
