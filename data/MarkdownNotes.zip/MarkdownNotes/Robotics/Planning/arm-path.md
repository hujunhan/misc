---
title: Path Planning for Robot Arm
author: Junhan Hu
tags:
  - robot
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Planning
date: 2023-02-26 15:41:00
---

## Math Formulation

目标：生成一条符合**要求**的轨迹（**点**的集合）

*  目标是根据需求来选择的，一般的会有的需求
  * 时间
  * joint constraints
  * 避障
* 点：在三维空间中

## Library

OMPL (Open Motion Planning Library)

* sampling based and optimization based
* How: PRM (Probabilistic Roadmaps ), RRT, BIT( Batch Informed Trees)
* Input: include the robot's configuration, the environment
* Output: the motion plan, a sequence of robot configuration or trajectories

PIMPL (Pilz Industrial Motion Planner)

* especially designed for industrial robot

STOMP (Stochastic Trajectory Optimization for Motion Planning)

* optimization based, suited for many degree of freedoms
* How: iteratively optimizing a random trajectories

SBPL (Search-Based Planning Library )

* search based
* How: reprensent the robot and environment as a grid, then use search algorithm like A*, Dijkstra, to explore

CHOMP (Covariant Hamiltonian Optimization for Motion Planning )

* optimization based
* How:  based on the Hamiltonian formulation of mechanics and optimizes the Hamiltonian of the system subject to constraints.

## Math Basis

RPM, RRT, BIT, Search, Optmization

### Cell Decomposition

Sample the space into grid, so the problem degrade to a classic search problem

* Bad for high-dimensional situation

### Control based

* Fast, can be done in online with minimal error
* Difficult to compute with  complex dynamics 

### Potential Fields

Simple and intuitive

* Real time speed
* Fail in local minima

### Sample Based

* If the solution exist, the method would find it

Some idea: workspace, state space, free state space, ppath

Two type

* PRM, Using the knowdege of graph

  ![image-20230226181351316](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230226181351.png)

* Tree based

  ![image-20230226181414617](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230226181414.png)

Important tool

* Collision checking
* Nearest neighbor