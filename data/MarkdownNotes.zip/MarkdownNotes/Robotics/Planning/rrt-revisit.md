---
title: RRT Revisit
author: Junhan Hu
tags:
  - robot
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Planning
date: 2023-08-10 01:37:00
---

## Intro

Recently, I re-implemented RRT algorithm in Python, and learned a lot during the optimization process

## Numpy

Vectorized calculation like Numpy would save a lot of time

## O(N)?

Sometimes, we need to change the algorithm for speed

For example, for looking the nearest point, plain algorithm O(N) even using Numpy is slow

Change the data structure to KDTree would boost the speed

## Profile

Profile is an important tool to analyze the performance, so we could focus on the most time consuming part and optimize it



