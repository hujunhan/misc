---
title: 机器人建图技术（位置已知）
author: Junhan Hu
tags:
  - maps
mathjax: true
date: 2020-7-23
categories:
  - MarkdownNotes
  - Robotics
  - Mapping
---

## 背景知识

为什么要建图：

- 学习地图是基本任务
- 有了地图可以方便其他任务
- 其他任务依赖正确的地图

基本问题：环境是怎么样的

已知的：环境数据和状态数据 $d={u_1,z1,u_2,z2,...u_t,z_t}$

要计算的$m^*=argmax_mP(m|d)$

## 地图种类

* Grid Maps

  世界离散化，结构是固定的，每个cell可以是被占据或者free的，这个模型是没有参数的，不需要识别特征

  * 每个cell的状态用概率来描述
  * 每个cell之间都是相互独立的

  更新同样是用贝叶斯滤波

利用上述工具，可以使用Occupancy Grid Mapping技术，最早是为了解决传感器噪声问题，根据传感器的数据来判断是障碍物的距离

或者也可以使用反射概率波形，根据统计次数来生成最大似然模型