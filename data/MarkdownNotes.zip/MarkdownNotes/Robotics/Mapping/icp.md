---
title: ICP Algorithm
author: Junhan Hu
tags:
  - maps
mathjax: true
date: 2023-01-25 23:06:00
categories:
  - MarkdownNotes
  - Robotics
  - Mapping
---

## Intro

Hardware: Laser Lidar

Input: a series of 2D or 3D point, $X_0, X_1...X_n$

Output: the R,T betwwen $X_i$ and $X_{i+1}$

## Algorithm

General Procedure

1. Point selection: for lidar, the data is in order
2. Matching: nearest neighbor
3. Weighting
4. Rejecting
5. Calculate error
6. Minimize the error

## Plan

1. get real data
   1. From ros, record the data using ROS bag
   2. Convert the rosbag to numpy
2. Test algorithm in existing code
3. Migrate the algorithm to Taichi version

