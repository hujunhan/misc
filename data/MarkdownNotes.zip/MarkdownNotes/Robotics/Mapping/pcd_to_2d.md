---
title: 3D Point Cloud to 2D Map
author: Junhan Hu
tags:
  - maps
mathjax: true
date: 2023-05-27 19:04:00
categories:
  - MarkdownNotes
  - Robotics
  - Mapping
---

## Goal

After running the lidar SLAM, the final map we got is a 3d point cloud.

Goal: compress it to 2d plane 