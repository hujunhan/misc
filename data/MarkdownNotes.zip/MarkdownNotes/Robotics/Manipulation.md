---
title: Manipulation Notes
author: Junhan Hu
tags:
  - manipulation
  - arm
mathjax: true
date: 2022-07-01 12:25:00
categories:
  - MarkdownNotes
  - Robotics
---

## Introduction

Hard problem: need strong ability in so many technical areas

* Perception
* Planning
* Control

### More Than Pick-and-Place

The task a human can do is so remarkable.

Making salad? Grasping? Much more!

### Open-world Manipulation

Challenge: very diverse world, and we have high expectation

Maybe it also is a chance that diversity would make the problem easier, since we would never ask for a optimal solution

### Simulation

Perception and physics

### Model-Based Design and Analysis

More accurate and informative messages

How to model? Diagrams

## Get a robot

### Arm

#### Position-control

Most are position controlled

Torque control is not widely used since the $\tau_{motor}=k_t i$ doesn't hold in real life

How: use position sensor to do a PID control, we are controlling torque but in reality we are ouputing voltage by PWM

> Though the control objects are always different, the gains are surprisingly not that different

#### Torque-control

Not common

* Direct control to electrical motor with small gear reduction (<10:1)
* Hydraulic actuators
* Keep large gear-ratio motors, add sensors to measure the torque

The cost is going down

#### Simulation

Drake

* MultibodyPlant, represent the physical system, in control field
* SceneGraph, handle the geometry of the scene

For the torque, we need to specify even the controller is off

To simulate the arm well, we need to implement  a low-level controller

### Hand

Different camps

* Dexterous hands, just like human's hands, sensor rich. We are not there yet
* Simple grippers, can also do amazing useful job. Why we need a dexterous hand?
* Soft hands, good at something but not general.

### Sensor

Perception, tactile sensing is important. Now, we only need to focus on joint sensor.

* reliable: position, velocity, torque
* unreliable: acceleration

## Pick and Place

Naturally, we can start from **geometry** and **kinematics**

### Notion

![image-20220701000523016](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-07-02-11-32-06.png)

very powerful

### Pick Transform

Object $O$, Gripper $G$，Sensor tell us $^WX^O$, Desired $^WX^{O_d}$

goal: make $X^O=X^{O_d}$

> Example: camera frame to world frame
> $$
> p^{P_i}=X^{CC}p^{P_i}
> $$

### FK

In real life, we give command for the joint position, so we need to convert from **joint angles** to **cartesian frames**

Define 3 element in every joint

* transform from children joint frame to parent joint frame $^{J_P}X^{J_C}(q)$
* transform from children joint frame to children body frame $^{C}X^{J_C}$
* transform from parent joint frame to parent body frame $^{P}X^{J_C}$

All in all, we can compute the transform
$$
^PX^C(q)=^{P}X^{J_CJ_P}X^{J_C}(q)^{J_C}X^{C}
$$
In short, we get a map
$$
X^G=f^G_{kin}(q)
$$

### Jacobians

If the goal is to move the gripper, then we should how **change in joint** relate to **change in pose**

Straightforward to compute the partial derivative
$$
dX^B=J^B(q)dq
$$

To represent a 6D velocity more clearly, we use the following
$$
{ }^{A} V_{C}^{B}=\left[\begin{array}{c}
{ }^{A} \omega_{C}^{B} \\
A_{\mathrm{V}_{C}^{B}}^{B}
\end{array}\right]
$$

* $w$ is the angular velocity
* $v$ is the translational velocity

### Inverse Kinematics

If we have a desired a gripper velocity $V^{G_d}$, may be we could do $v=\left[J^{G}(q)\right]^{-1} V^{G_{d}}$?

#### Pseudo-inverse

First consider is the matrix invertible? E.g. the dimension is $6\times7$, it's more than required

Moore-Penrose pseudo inverse
$$
v=\left[J^{G}(q)\right]^{+} V^{G_{d}}
$$
This would give the solution with minimum-norm

### Trajectory

Define the keyframe pose we wish the gripper to travel

What kind of trajectory? splines is a good way

Interpolation

* Position: simply linear interpolation
* Rotation: Spherical linear interpolation or slerp

### Constrains

Pseudo-inverse solution might lead to large velocity (beyond robot limits) which we don't want

Regard the inverse as a optimization problem
$$
\min _{v}\left|J^{G}(q) v-V^{G_{d}}\right|_{2}^{2}
$$
and we have constrains in positions, speed and acceleration
$$
\begin{array}{ll}
\min_{v_{n}} & \left|J^{G}(q) v_{n}-V^{G_{d}}\right|_{2}^{2} \\
\text { subject to } & v_{\min } \leq v_{n} \leq v_{\max } \\
& q_{\min } \leq q+h v_{n} \leq q_{\max } \\
& \dot{v}_{\min } \leq \frac{v_{n}-v}{h} \leq \dot{v}_{\max }
\end{array}
$$

#### Joint Centering

In robotics, we could add a secondary control
$$
\min _{v_{n}}\left|J^{G}(q) v_{n}-V^{G_{d}}\right|_{2}^{2}+\epsilon\left|P(q)\left(v_{n}-K\left(q_{0}-q\right)\right)\right|_{2}^{2}
\\
subject \ to \  constraints.
$$

## Pose Estimation

Assumption: we know the object and have depth camera

Two trends:

* deep learning
* geometric reasoning

### Camera

In practice, **camera** or **range** sensor are more important

#### Depth sensor

RGBD (ToF and structured light)

There are noise in real life, and dependent to lighting conditions, surface normals and other properties.

### Representation

* depth image
* color image
* camera pose

Combine, we can get a point cloud

### Registration

Point cloud registration

* given two point clouds
* find the transform

In two strong assumption:

1. knowing the camera pose
2. known correspondences. Each point in the scene correspond with one model point

In this situation, it becomes a optimization problem
$$
\begin{array}{ll}
\min _{p, R} & \sum_{i=1}^{N_{s}} \| p+R^{O} p^{m_{c_{i}}}-X^{C C^{s_{i}}} p^{2} \\
\text { subject to } & R^{T}=R^{-1}, \quad \operatorname{det}(R)=+1
\end{array}
$$
We can get the rotation first, then get the translation. So we center two point

Using SVD, we can get the solution

### ICP

1. initial guess of the object **pose**
2. calculate the **correspondence** via closet points
3. Use the correspondence update pose

We have very good numerical solution like FLANN

### Partial View

![image-20220714221135748](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-07-14-22-11-39.png)

In real world, the data is not perfect, how to deal with it?

#### Detecting outliers

* detect outliers need good estimation
* good estimation need detect outliers

How?

1. ICP with RANSAC
   1. many seed to select a good start (good estimation)
2. relative distance (graph theory)

#### Segmentation

Use NN more

#### Multiple object and Partial view

Use a correspondence matrix to find the minimum
$$
\min _{X \in \operatorname{SE}(3)} \sum_{i=1}^{N_{s}} \sum_{j=1}^{N_{m}} C_{i j}\left\|X^{O} p^{m_{j}}-p^{s_{i}}\right\|^{2}
$$
The main idea behind CPD: relax the strict and let the matrix between 0 and 1

This make CPD more robust than ICP, but still use SVD

#### Non-linear Optimization

Try to estimate the pose and outliers at the same time, make the problem **nonconvex**, but

1. the computation time would be saved
2. can add more objective function

### Looking ahead

In the discussion, we lost the color, only use the depth.

In the future, the color should be used more

## Bin Picking

Consider the simplest situation: pick objects from one bin to another bin

* How to simulate the drop and grasping?

We could refine it to more complicated situation.

### Generate Scenes

1. Falling
   1. uniform rotate, place in X,Y
2. Frictional Contact
   1. $M(q) \dot{v}+C(q, v) v=\tau_{g}(q)+\sum_{i} J_{i}^{T}(q) F^{c_{i}}$
   2. static $v=\dot v=0\to$ $\tau_{g}(q)=-\sum_{i} J_{i}^{T}(q) F^{c_{i}}$
3. Optimization, consider the constrain

However, the simulation is not stable in current study, we need more computation source.

### Grasp Selection

The problem is hard: how to choose the right point of grasp

* Still a problem in nowadays
* New approach: by learning method

#### Point cloud

1. crop：delete unwanted points
2. estimate: estimate the normal
3. merge
4. down-sample: using voxel grid

#### Normal and Curvature

Calculate the normal
$$
\min _{p, n} \sum_{i=1}^{N}\left|\left(p^{i}-p\right)^{T} n\right|^{2}, \quad \text { subject to } \quad|n|=1
$$
and we can transform it into
$$
\min _{n} n^{T} W n, \quad \text { subject to } \quad|n|=1, \quad \text { where } W=\left[\sum_{i}\left(p^{i}-p^{*}\right)\left(p^{i}-p^{*}\right)^{T}\right] \text {. }
$$
By finding the eigenvalue of W, we can find the optimal solution

#### Grasp point

two step

1. find a cost function
   1. **antipodal grasps**. the most force to fight gravity
   2. $\text { cost }=-\sum_{i}\left(n_{G_{x}}^{i}\right)^{2}$
2. find the low cost candidate
   1. How to find  $X^G$
      1. local curvature
      2. find antipodal point pair

## Object Detection

Geometric method can give good estimate of local minima, but perform bad in complex scene

Deep learning based method are more powerful

### Big Data

![image-20220720002240961](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-07-20-00-22-41.png)

Massive annotated datasets

Instance segmentation is what we need in manipulation

----

What if we met new classes?

* In the dataset, we have data for like plates, forks
* What about the bottles?
  * From the backbone
  * Finetune

### Simulation

Real data is valuable, but we can also use simulation to synthetic data

### Object Detection

Image recognition:

* input the full image
* output is the probability of the image contain something

Semantic Segmentation:

* input the full image
* output is another image

Instance Segmentation: Mask R-CNN

## Force Control

A hard task to grasp something

### Simple Model

To fight against complexity, find a setup as simple as possible.

Consider the following setup

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-07-23-13-11-33.png)

We have two model to consider

* Dynamic model for simulation
* Robot model for controller

---

Direct force control

* Direct means we control the **contact forces**

How to do a flip-up?

Text version: Apply a moment around the bottom left corner to generate a rotation. also add a force that the corner would not slip

Math version:
$$
\begin{aligned}
\min _{f_{W}^{C}} &\left|w f_{C_{x}}^{C}-\operatorname{PID}\left(\theta_{d}, \theta\right)\right|^{2} \\
\text { subject to } &\left|f_{W_{x}}^{C}\right| \leq \hat{\mu}_{A}\left(\hat{m} g-f_{W_{z}}^{C}\right) \\
& f_{C_{z}}^{C} \geq 0, \quad\left|f_{C_{x}}^{C}\right| \leq \hat{\mu}_{C} f_{C_{z}}^{C} \\
\text { with } &{ }^{W} R^{C}(\theta)=\left[\begin{array}{cc}
-\sin \theta & -\cos \theta \\
\cos \theta & -\sin \theta
\end{array}\right] .
\end{aligned}
$$

---

Indirect force control

Program our robot to act like a mechanical system reacts to the contact forces

* Benefit: we only need to know the robot rather than environments
* Guarantee the robot won't go unstable

## Motion Planning

Why motion planning?

* Collision between arm and environment
* In different environment, we need more automated robot
* In static environment, we could optimize the manipulation process significantly

Need MORE brave robot

### IK

### Trajectory Optimization

### Sampling-Based Planning
