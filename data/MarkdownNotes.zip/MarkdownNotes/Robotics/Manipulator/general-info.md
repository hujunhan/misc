---
title: Basics of Manipulator
author: Junhan Hu
tags:
  - learn
  - robotics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Manipulator
date: 2023-07-19 22:45:00
---

## Goal

Understand the general framework of manipulator.

From my current understanding, it would include

* Design (general shape etc)

* Control

* Mechanics

How human manipulate? (manipulation without grasping)

* Sliding and environmental contact
* Grasping

For robot

* Grasping 
* Non-Grasping

## From MIT Course

[Ch. 8 - Manipulator Control (mit.edu)](https://manipulation.csail.mit.edu/force.html)

1. Assume the object is a point mass
   $$
   \left[\begin{array}{cc}
   m & 0 \\
   0 & m
   \end{array}\right] \dot{v}=m\left[\begin{array}{l}
   \ddot{x} \\
   \ddot{z}
   \end{array}\right]=\tau_g+\left[\begin{array}{l}
   u_x \\
   u_z
   \end{array}\right]+f^{F_c}
   $$

   1. Trajectory Tracking

   2. Force Control

      1. Know the state of robot
      2. Measure the contact force
      3. *stiffness control*
      4. Hybrid position/force control

      