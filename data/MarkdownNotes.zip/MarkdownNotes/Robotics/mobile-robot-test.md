---
title: 移动机器人测试
author: Junhan Hu
tags:
  - manipulation
  - arm
mathjax: true
date: 2023-05-16 00:18:00
categories:
  - MarkdownNotes
  - Robotics
---

## 具体任务分配

* 底层

  * 轮毂电机（立文）和转向电机（立文+陈浩）的控制，写成ros node A
    * 输入：控制信号
    * 内容：通过CAN发送信号
    * 测试内容：0到2m/s速度控制精度，位置控制精度
  * 电气系统搭建：有序、可扩展的电源分配，安全可靠的上下电方式（陈豪）
    * 测试内容：多次上下电，是否都正常工作
* 中间层（立文）

  * 键盘控制，写成ros node B
    * 输入：方向键
    * 内容：输出控制信号给ros node A
  * 测试内容：使用方向键控制小车在测试环境中走一圈
* 上层（钧涵）
  * 路径规划，写成ros node C
    * 输入：地图，起点，终点
    * 内容：输出路径给ros node D
    * 测试内容：由采集好的数据测试
  * 运动控制，写成ros node D
    * 输入：路径，当前状态
    * 内容：输出控制信号给ros node A
    * 测试内容：由采集好的数据测试
  * 自动化启动，开机后自动启动相应驱动和ros node

## 测试流程

1. 机械组装
2. 电源布线
3. 测试轮毂电机
   1. 前进后退功能
   2. 测精度，跑10m误差多少
4. 测试转向电机
   1. 左转右转功能
   2. 测精度，旋转90°误差多少
5. 远程键盘控制
   1. 使用键盘远程操纵小车在指定空间行走一圈
   2. 加上雷达做一个建图
6. 测试运动控制
   1. 指定起点和终点，运动控制自动导航
   2. 测精度，在终点误差多少
7. 测试路径规划
8. 动态的障碍物检测

## Update 0625

新的工控机，接下来的测试流程

1. 确定轮毂电机和转向电机正常工作
2. 确定雷达正常工作
3. 室内MPC without SLAM
4. 室外MPC with SLAM

## Test 0626

1. 启动雷达 roslaunch lslidar_driver lslidar_c16.launch

2. 启动定位 roslaunch hdl_localization hdl_localization.launch

3. 可视化定位

   roscd hdl_localization/rviz

   rviz -d hdl_localization.rviz

4. 全局定位 rosservice call /relocalize

5. 跑MPC: python3 ~/MPC/carlike_control/test/FWS_ros.py

   1. 跑之前根据第3步的输出修改一下小车的初始位置

      ![image-20230626202431526](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230626202431_C4SjZN.png)

   2. 运行轨迹点在第58行