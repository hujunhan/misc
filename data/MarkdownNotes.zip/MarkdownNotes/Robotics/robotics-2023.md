---
title: Robotics in 2023
author: Junhan Hu
tags:
  - robotics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
date: 2023-02-08 20:57:00
---

## Goal

Review the future development for robot

Especially focus on market and industry, not research

## Framework

[Ref](https://finance.sina.com.cn/stock/stockzmt/2023-02-03/doc-imyemynm3685079.shtml)

工业机器人、电控系统、传感器、AI芯片、软件、电机、轻量化

国产替代

![8bf2-8a5f20fca4f04fbe019c0e97127bf15a](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230208213635.png)

Product

* 搬运：AGV，技术含量不高，需求旺盛
* 焊接：点焊、弧焊
* 装配：轻量型，自动化水平低

总结：提高效率，降低成本

硬件

* 减速器
* 伺服电机
* 控制器

---

Electrical Control System

![ccb2-ce70e12967bed408e756ed2c78439cbe](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230208225140.png)

---

Sensor

* 内部，用来感知自身状态
* 外部，用来感受周围环境

![6287-8ad72e96150cd04bfe62974cf8293c71](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230208225552.png)

## 国内项目

6轴：轨迹规划，避障

* 运动精度
* 算法，以及形式

采茶机器人

* 真实环境demo

巡检机器人

* 室外
* 激光雷达
* 外部装甲



视觉导航，仿真，机械臂