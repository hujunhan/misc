---
title: HDL Localization
author: Junhan Hu
tags:
  - SLAM
  - project
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - SLAM
date: 2023-06-26 21:42:00
---

## Intro

Building a SLAM system based mainly on Lidar

3 main different system

* Building point cloud map
* Global localization
* Relative localization

## Building Map

Graph optimization + loop closure detection

## Global Localization

Bound and refine bound

## Relative Localization

NDT (normal distribution transform)

Or GICP (generalized ICP)

