---
title: ALOAM Learning
author: Junhan Hu
tags:
  - SLAM
  - project
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - SLAM
date: 2023-03-07 21:15:00
---

## Goal

Understanding the overall structure of the LOAM project and try to compile it **without** ROS

## Theory

Paper: [Lidar Odometry and Mapping in Real-time](http://www.roboticsproceedings.org/rss10/p07.pdf)

[Explanation](https://lukeyalvin.site/archives/43.html)

Problem: error in motion estimation cause mis-registration

Solution: propose 2 odometry

* High frequency, low accuracy
* Low frequency, high accuracy

![image-20230307215625066](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230307215625.png)

Some key point

* feature extraction: based on curvature, only a(A) is considered as a good feature point

  ![image-20230307220110995](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230307220111.png)

  * Only a few feature point in a location (avoid density in-balance)
  * Can't on the parallel surface and blocked area

* Need to deal with the distortion (since the robot is moving)
* Find the matching
  * Goal: minimize the distance (point to line and point to surface)
    * $d_{\xi}=\frac{|(\tilde{X}^L_{(k+1,i)}-\overline{X}^L_{(k,j)})×(\tilde{X}^L_{(k+1,i)}-\overline{X}^L_{(k,l)})|}
      {|\overline{X}^L_{(k,j)}-\overline{X}^L_{(k,l)}|}. \tag{2}$
    * $d_\mathcal{H}=\frac
      {\begin{vmatrix}
      (\tilde{X}^L_{(k+1,i)}-\overline{X}^L_{(k,j)})·((\overline{X}^L_{(k,j)}-\overline{X}^L_{(k,l)})×(\overline{X}^L_{(k,j)}-\overline{X}^L_{(k,m)}))
      \end{vmatrix}
      }
      {\begin{vmatrix}
      (\overline{X}^L_{(k,j)}-\overline{X}^L_{(k,l)})×(\overline{X}^L_{(k,j)}-\overline{X}^L_{(k,m)})
      \end{vmatrix} }.$
* Movement: linear interpolation
* Building the Map: using the existing map to correct the movement estimation
  * Since computation complex, so low frequency (1/10 of the odometry)
  * Correct the whole map

## Dependencies

* PCL

  * VTK

    ```bash
    brew edit vtk
    #https://stackoverflow.com/questions/3939651/how-do-i-modify-a-homebrew-formula
    ## Add two line
          -DVTK_MODULE_ENABLE_VTK_GuiSupportQt:STRING=YES
          -DVTK_MODULE_ENABLE_VTK_ViewsQt:STRING=YES
    brew reinstall --build-from-source --formula /opt/homebrew/Library/Taps/homebrew/homebrew-core/Formula/vtk.rb
    export CMAKE_PREFIX_PATH=/opt/homebrew/Cellar/qt@5/5.15.8_2/
    ```

    

* gtsam

* Ceres-solver

## Structure

