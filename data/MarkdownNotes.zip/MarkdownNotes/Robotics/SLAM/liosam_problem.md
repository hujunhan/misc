---
title: Problem Calibrating Lidar and IMU
author: Junhan Hu
tags:
  - SLAM
  - project
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - SLAM
date: 2023-03-06 00:51:00
---

## 背景

硬件：

* 雷神雷达C16
  * 16线
  * 每线2000点
* 北斗星通MS-6111 六轴IMU
  * xyz加速度
  * 角速度

软件

* 校准：[lidar_imu_calib](https://github.com/chennuo0125-HIT/lidar_imu_calib)
  * 开启雷达和IMU的ros节点
  * rosbag记录，同时移动雷达和IMU
  * 计算IMU和雷达之间的位姿转换矩阵（只计算旋转）
* SLAM：[liorf](https://github.com/YJZLuckyBoy/liorf)
  * LIO-SAM的变种，可以接收六轴传感器

## 问题

SLAM能够正常启动和运行，但是里程计会漂移，有很大的误差

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230329185739.png" alt="image-20230329185739433" style="zoom: 50%;" />

观察到的现象

* 在平地时，IMU数据的x,y均有值。0.1m/s^2左右
* 里程计显示速度越来越快

## 猜测原因

* 雷达和imu校准不准确，算出来的矩阵有问题
* 由于雷达和imu频率不同导致的同步问题
* imu没有调平

## 解决办法

1. IMU内参标定
2. IMU和雷达外参标定
3. 调平
4. 时间戳同步
5. 排查静止时输入到前段的数据，如点云，测距精度，噪声，频率，时间戳