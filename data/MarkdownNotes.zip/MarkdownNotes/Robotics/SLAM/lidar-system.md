---
title: Lidar SLAM System Design
author: Junhan Hu
tags:
  - SLAM
  - project
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - SLAM
date: 2023-05-31 21:03:00
---

## Intro

Overlooked the localization problem earlier.

So now the system is more clear

* Offline map construction
  * Use LOAM series to build graph map and construction
* Online global localization
  * Use HDL (GICP) to to the localization in real time

## System

![img](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230531211522_pwfIDK.png)

## Test Via Point Data

Building Map:

* y=5200, x=0
* x=1920, y=5200
* y=(745)73\*80+100-65\*80, x=1920
* y=-300, x=700
* x=150, y=-56



Map

* x=0,y=5200-80
* x=1920,y=5200
* x=1920, y=745-80
* x=1920-460, y=745-80-100

80: 3

73: 2+3

一共65

58块80

7块73

14-7*7=35