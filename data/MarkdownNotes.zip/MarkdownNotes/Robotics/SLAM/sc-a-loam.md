---
title: SC-A-LOAM
author: Junhan Hu
tags:
  - SLAM
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - SLAM
date: 2023-05-29 16:58:00
---

## Intro

I need a fully worked SALM system, what I want to get from the system?

* Generate a 3d lidar map from the system
* Used for further localization
  * Given a lidar scan
  * give the global position

## Project

[Source](https://github.com/gisbi-kim/SC-A-LOAM)

structure

* A-LOAM for odometry
* ScanContext fro global localization
* GTSAM for pose-graph optimization

## Question About the SLAM

做一个小车，以雷达传感器为主，主要实现建图和定位功能，该如何下手？

我设想的方式：

1. 建图部分

   1. 使用雷达建图，建立稠密点云

   1. 仿真重新采样（在地图的所有位置）

   1. scan context计算特征

2. 定位部分

   1. 获得lidar scan，计算scan context特征
   2. 匹配scan context
   3. 计算位置

有一些问题，这样的方式是否可行

1. 建图类型，那种类型适合
   1. key frame
   2. 点云
2. global localization方法
3. 比较完善的框架和代码

