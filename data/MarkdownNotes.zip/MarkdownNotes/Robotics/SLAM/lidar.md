---
title: Lidar SLAM System Review
author: Junhan Hu
tags:
  - SLAM
  - project
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - SLAM
date: 2023-03-06 00:51:00
---

## Intro

Review Lidar based SLAM algorithm and libraries

Some of the popular lib:

* LOAM
* **LEGO LOAM**
* LIO SAM

## LOAM

Year: 2014

Lidar Odometry and Mapping

* Scan Matching
* Odometry
* Fast and efficient

Con:

* Require careful parameter tuning

## LEGO LOAM

Year: 2018

Lightweight and Ground-Optimized Lidar Odometry and Mapping

* Use line and point feature extraction to increase the robustness
* More robust to sensor noise and calibration error

## LIO SAM

Year: 2018

Lidar Inertial Odometry and Mapping via Smoothing and Mapping

* Tightly couple with inertial sensor
* Fuse sensor to estimate
* Computation Intensive

## LOCUS

[Repo](https://github.com/NeBula-Autonomy/LOCUS)

![locus-demo](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230306214826.gif)

## Ref

[Evaluation and comparison of 3D lidar based SLAM algorithms](https://www.aia-polytech.be/wp-content/uploads/2021/01/EvaluationAndComparisonOf3DLidarBasedSLAMAlgorithms.pdf)

## Question

1. 从一个开源项目到实际部署到机器人的过程中，有哪些要注意的地方
2. 大概需要怎样的性能

室内场景更加复杂

仓储机器人

激光雷达，传感器融合，

IMU: Bosch, ADA

