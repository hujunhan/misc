---
title: Driver
author: Junhan Hu
tags:
  - course
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Udemy
date: 2022-06-14 14:14:00
---

## Mechanical Advantage

Lever，杠杆，变大变小

* 力
* 运动

Trade-off，力换距离，或者距离换力

为了在所有时间上都能产生力，我们生成了齿轮，gear

## Gear

混合齿轮 Compound Gear，also applied to wheel

Linear: use **stepper motor** for a precise control

## Arm

电机，在极坐标平面的分辨率是固定的，但是在xy方向上，分辨率是不固定的，

## Backlash

滞后，机器人的诅咒。尤其在齿轮系统中，存在滞后，对精度有很大的影响

Will amplified in the whole system

Anti-backlash, use tension

## Precise Control

Wedge, thread

Ball screw

## DC-brushed Motor

Most common in small robotics

永磁体，为了控制方向，我们需要3向磁铁。
* 如果只有两个接口，一般没法控制方向
* 如果有多个接口，就可以控制方向

## Back EMF

当电机卡住的时候，电阻变小，电流变大了，所以得计算stalled时候的最大电流，来选择其他的配件，不然可能会烧坏

## Toggle Mechanisim

Good for grippers, very large mechanical advantage

## Electrical Generation

Reverse of the motor, use the power of human, wind and water

## Regenerative braking

回收电，在停下来之前，把电收集起来

实际上，因为太少、电压不高，因此普通的不行。得用AC-DC转换器把电压升高

## Servo and Feedback

closed-loop **positional**(most important in robot) servo

Example: use positional control to do a changable capacitors, make many high=accurate sensor

Encoder，optical binary encoder；accelerometer to detect move and orientation

## Stepper motors

brushless motor: multiple phase wire to change the field,

* more current, much more powerful, no back EMF

<img src="https://toshiba.semicon-storage.com/content/dam/toshiba-ss-v2/master/en/semiconductor/knowledge/e-learning/brushless-motor/chapter1/1-2.png" alt="History of Brushless Motors | Toshiba Electronic Devices & Storage  Corporation | Europe(EMEA)" style="zoom:33%;" />

You need to make sure the system moves, or the position would be lost

## BLDC

No sensor, open loop, use back EMF to do a closed-loop control

* Hall sensor, good for the feedback

H-bridge: control the motor move forward or backward

* Just open loop

<img src="https://www.build-electronic-circuits.com/wp-content/uploads/2018/11/H-bridge-switches-1-drawn-217x300.png" alt="img" style="zoom:33%;" />

Hall sensor, make the motor closed loop

---

Transform in to AC servo motor (expensive)

* AC motor, more accurate, more position

## PWMAC

Use PWM to simulate the AC

## Harmonic Drive

Using the mechanical advantage of **wedge** to drive

<img src="https://upload.wikimedia.org/wikipedia/commons/2/21/HarmonicDriveAni.gif" alt="Strain wave gearing - Wikipedia" style="zoom:25%;" />

**NO** **backlash**



##  AC Motor

How to initiate the motor? use a capacitor to keep a 90 offset

AC frequency is the same as rotate frequency

Sync: Only the magnite is used

Async: Use wire, so introduce current

## Stored power: Air and Water

Anything that stores energy is dangerous

## Spring，Resolver

Spring: More natural, more realistic, since it has bouncing

Resolver: rotation position feedback, different angle show different wave shape

