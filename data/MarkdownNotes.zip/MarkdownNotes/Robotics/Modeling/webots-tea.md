---
title: Webots Simulation for Tea Robot 
author: Junhan Hu
tags:
  - robotics
  - simulation
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Modeling
date: 2023-02-12 14:20:00
---

## Intro

Using the Webots to do the simulation of general mobile arm robot

Current, the simulation have following task to do (in high level)

* Build a simulation world (Place something)
  * Obstacles
  * Object
* Robot base movement simulation (SLAM)
* Robot arm manipulation simulation (Kinematics and Inverse)

## Roadmap

### Build the World

![image-20230212225320373](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230212225320.png)

* The big box simulate the tea tree
* The small box simulate the tea leaf
* The YouBot simulate our robot

### Migrate from Matlab to Python

Control robot move by control the wheel directly

step is important to update and sync the robot and world



#### Base

Movement. Turn. Go through location

#### Arm

ik

## Setup

Using Python as the controller

* ~~Change the preference~~
* ~~Recompile the wrapper~~

No need to recompile the Python binding since in newer version, the python is already in header file format

Just include the `/Applications/Webots.app/Contents/lib/controller/python`

in the Python path

And set the robot controller to extern

![image-20230213225557838](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230213225558.png)

## Design

Learn from the youbot design

4 Part

* Arm
* Base
  * move forward/backward/left/right
* Gripper
  * init
  * Set gap
  * grip/release

