---
title: Design Process for Robot Arm
author: Junhan Hu
tags:
  - robotics
  - modeling
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Modeling
date: 2023-02-21 20:31:00
---

## Goal

Try to figure out a clear path or best practice for robot arm modeling and programming 

Input: the requirements and some consideration, limitation

Output:

* The robot arm model (the math model for kinematics)
* The control algorithm
  * Kinematics
  * Invser-Kinematics
* Simulation:(webots)

## Requirements 

* Payload:
  * Influence: Structure and motor actuator
  * How: the weight, how far from the center of gravity, [Ref](https://www.youtube.com/watch?v=larhoalnVSQ)
  * ![image-20230221204934948](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230221204935.png)
* Workspace, [Ref](https://www.youtube.com/watch?v=_canCYWZPsc)
  * reachable
  * dexterous
  * ![image-20230221210331362](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230221210331.png)
* Accuracy: determined by sensor
* Speed: model and actuators
* Control: software and hardware needed for control and **communication**
* Cost: materials, components, labor
* Safety: vision / lidar
* Maintenance: repair, parts, mechanical, electrical system

## Modeling

### Format? URDF

* **URDF: Unified Robot Description Format**
  * Simpler, only the basics like geometry, kinematics, dynamics
* SDF: Simulation Description Format
  * More featured, materials, lighting, camera model, environments

### URDF Crash Course

[Matlab Ref](https://www.mathworks.com/help/sm/ug/urdf-model-import.html)

XML based

Nested structure, <robot>, <link>, <joint>

* Elements, <robot>, <link>, <joint>
* Attributes, `name` , `rgba`

* Parent and Child could be indicated by the parent and child elements
  * Model **Topology**
  * No closed-loop Chain: A <link> could only be **one** child of <joint>

![image-20230221223829402](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230221223829.png)

Green are optional

### URDF Parser

XML based file, find the root and iterate over node

<Link>  defines the structure of the robot

<joint> defines the transformation of the robot

1. Read all the link and joint by their **name**
2. Iterate over joint
   1. calculate the translation, orientation
   2. joint origin descsribe how **two links related**, in default situation

==So **only the joint** matter the kinematics, the link just matters for physics and simulation==

* In many case, the collision and visual should be the same, however it  should not in the following situation

  * simpler collision for faster processsing
  * Safe zone, make more room in collision

  | Visual                                                       | Collision                                                    |
  | ------------------------------------------------------------ | ------------------------------------------------------------ |
  | ![image-20230412223503445](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230412223503.png) | ![image-20230412223512348](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230412223512.png) |

  

### Kinematics

1.  Get the translation and rotation from the URDF
2. Apply the forward kinematics
   1. Calculate the forward kinematics from code
   2. ~~Simulate the forward kinematics in Webots~~ Hard to get position of the end arm, use python visual instead

1. Solve the Inverse kinematics

## Motion Planning

### Inverse Kinematics

Problem: many constrains

For 6 or 7 DOF: IKFast, open source, use a approximation, fast and numerically robust solution

* Fact: the 6D pose constraint on a 6D manipulator has closed form solution

For less constrained for inequality constrained, became an **optimization** problem

* Differential IK
* Full IK



### Trajectory Optimization

Not solving the problem independently, the basic idea is to solve in a optimization form,

### Sampling Based 


## Implementation

workspace calculation, maybe by sampling?

* 2D to 3D

## Takeaway

Make the cost function simple

Write minimal constraints