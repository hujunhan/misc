---
title: Python Modeling Using CadQuery
author: Junhan Hu
tags:
  - robotics
  - modeling
  - python
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Modeling
date: 2023-01-12 23:35:00
---

## Why

Goal: 3D modeling something in my mind, and 3D print the object

Tried: I tried 

* Solidworks (standard software for 3D modeling, but too expensive and not portable)
* Pure Python, generate point manually, then use Meshlab to reconstruct the face/mesh again, this method is  free but the result is harsh and hard to modify.

This time, I would try to use a Python library called CadQuery, it based on OpenCascade, an open-source 3D modeling engine.

## Design Principle

Intuitive Construction

* the language should just like human language

Capture Design Intent

* Should follow some unclaimed assumption
* Understand the constrain between different part

CAD file as cource code

## Concept

* Topology
  * Boundary Representation, objects are defined by their enclosing surfaces
  * vertex to edge to wire to face to shell to solid to compound

* Workplane, represent a plane that features are located
  * Usually start with "XY" plane
  * Work in 2D, but generate the 3D thing

* 2D Construction: circle, lines, arcs, mirror
* 3D Construction: boxes, wedges
* Selector, select the vertices, edges, faces, solids and wire using selectors (like the hand and mouse in GUI CAD software)
* Assumption: working on a SINGLE solid object
* 

## Try

### Install

Need x86_64 env in M1 Mac, MiniForge can do the job

[Ref](https://github.com/CadQuery/cadquery/issues/997)

```bash
CONDA_SUBDIR=osx-64 conda create -n rosetta python   # create a new environment called rosetta with intel packages.
conda activate rosetta
python -c "import platform;print(platform.machine())"
conda config --env --set subdir osx-64  # make sure that conda commands in this environment use intel packages
```

## Result

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230114232840.png" alt="image-20230114232840060" style="zoom:15%;" />

## Takeaway

1. The extra for hole don't need to be so generous
