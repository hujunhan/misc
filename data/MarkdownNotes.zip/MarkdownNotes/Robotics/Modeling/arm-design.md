---
title: Arm Control Design
author: Junhan Hu
tags:
  - robotics
  - simulation
  - arm
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Modeling
date: 2023-02-15 23:03:00
---

## Goal

Modeling the arm robot from different setting like DH parameter

* Can move over a line (in space domain)
* Can move smooth (in angle domain)

## Plan

* Generate robot arm modeling
* Inverse function

