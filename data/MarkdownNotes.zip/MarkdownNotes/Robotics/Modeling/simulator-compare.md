---
title: Simulator For Robotics 
author: Junhan Hu
tags:
  - robotics
  - simulation
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Modeling
date: 2023-02-09 21:35:00
---

## Goal

For the robotics algorithm and development, a simulation platform is needed

In this post, I would review existing robot simulation platform, and decide one for further developmetn

Consideration:

* Open Source
* Speed
* Lightweight

What makes a good simulator from [zhihu](https://zhuanlan.zhihu.com/p/545418917)

* Accurate physics
* Various sensor
* Standard

For my current simulation, I want to try a mobile robot with arm, find a simulation platform that provide the existing robot is a great idea.

Since the purpose is to verify the algorithm, still a huge gap between Sim and Real, so the simulator could focus on the **vision** and **kinematics** rather than dynamics.

Kuka YouBot is the kind of robot I would like use,

## Compare

**Webots**

* Existing model and sensor to use

* QT+ODE+OpenGL


Gazebo: too much dependency, huge system, open source

Nvidia: Rely on Nvidia GPU

Currently, I think the Webots would be the choice to go

## Test

A .wbt file contain all the info

* World info
* viewpoint
* Background and lighting
* Object

To save the world, pause, reset, modify, save

Use different language to write the controller

![image-20230211235756159](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230211235756.png)

Works great, and not much hassel

## Conclusion

For current simulation purpose, the Webots is choosed becaused the out-of-box experience 

* Pre commercial product, make it a stable simulation
* Offical model like Kuka YouBot make a good out-of-box experience
* Python and multiple language support
* Camera sensor support

