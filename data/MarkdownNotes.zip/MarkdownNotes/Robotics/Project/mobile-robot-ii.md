---
title: Build A Mobile Robot from Scratch —— Part II
author: Junhan Hu
tags:
  - robotics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Project
date: 2022-12-30 11:10:00
---

## Intro

It has been several weeks since the project begins. To make the project more clear, we can summarize the progress here and plan the next step

## Current

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/2022-12-21-22-36-18.png" alt="image-20221221223618322" style="zoom: 15%;" />

Material:

* Chasis
* Power distribution: 12V, 5V, GND, voltage transformer, power 
* Move: Motor
* Control: Arduino, Jetson Nano
* Sensor
  * Encoder
  * IMU
  * IR: for communication and control


Function

* Remote Manual Control: move forward/backward, rotate clockwise/counter-clockwise. SPEED CONTROL
* TODO: move robot to a specific position. POSITION CONTROL
  * use IMU, accumulate the ACCL
* TODO: use lidar to build map and refer it for localization. CLOSED LOOP POSITION CONTROL
  * use Lidar

For the current phase, the goal is to move from point A to point B

* due to the design, easy to rotate and move

## Next Phase

For a robot, movement is the most basic task, following by the question: what can it do?

I would like to see a robot can move and finish some task that are useful, for example, clean the floor

* Force feedback
* Motor arm



---

厨房机器人

半年的时间做一个demo

投入20w-30w美元

* 招人
  * 电气开发，福龙水平
  * 算法开发

合作：

* 工业扫地
* 酒店送餐机器人
* 不大的企业

----

场景

* Fry robot
* 
