---
title: Lidar SLAM -- Simulation
author: Junhan Hu
tags:
  - robotics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Project
date: 2023-02-06 21:28:00
---

## Goal

Try to recover the path using lidar data

Data: [Newer College Dataset](https://ori-drs.github.io/newer-college-dataset/stereo-cam/) from Oxford

* Why not self-acquired data? Hard to get the ground truth, low resolution data

The data: quad with dynamics

* 4 loops of quad with increasingly aggressive motion of device with swinging and fast walking (398 seconds)

Hardware

- **Intel Realsense D435i** - a stereoscopic-inertial camera
- **Ouster OS-1 (Gen 1) 64** - a 64 multi-beam 3D LiDAR also with an IMU

## Explore

Read the ground truth

<img src="https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230206213810.png" alt="image-20230206213810188" style="zoom:33%;" />

X: from -10 to 20

Y: from -40 to 10

---

Read data, from Ouster OS1

```python
struct_fmt = f'<{1024*64*3}H'
```

64 in veritical

1024 in honrizontal

3 for [x,y,z]

---

Test ICP in 2D

Read PointCloud Data in Python

* Offset defined in fields is important
* Calculate how many byte needed for the info
* ROS's PointCloud2 data,
  * Read the fields, understand how much inforamtion for a point, e.g 48byte and related datatype, e.g float32
  * Init a struct to read the data 

![image-20230208183313530](https://raw.githubusercontent.com/hujunhan/cloudimage/master/img/20230208183313.png)