---
title: Battery Localization 
author: Junhan Hu
tags:
  - robotics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Project
date: 2022-12-04 23:03:00
---

## Intro

矿山电池定位系统

目标：使用多相机多角度视觉系统，定位电池的3d位置

描述：

1. 多个相机拍摄电池的不同位置
2. 将信息组合，列公式或者
3. 推算出相机相对于电池的位置

算法：

* 输入：多张图片
* 输出：相对位姿

