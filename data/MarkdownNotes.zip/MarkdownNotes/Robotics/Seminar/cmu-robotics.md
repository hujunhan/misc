---
title: CMU Robotics Seminar Writeup
author: Junhan Hu
tags:
  - learn
  - robotics
mathjax: true
categories:
  - MarkdownNotes
  - Robotics
  - Seminar
date: 2023-07-17 22:53:00
---

## Conclusion

1. **Interdisciplinary Approach**: Many of these seminars showcase the interdisciplinary nature of robotics, highlighting the combination of engineering, computer science, and even biology and physics. Examples include "Snakes & Spiders, Robots & Geometry" by Ross L. Hatton, "Robots and Biosystems" by Kevin Lynch, and "DNA and gammaPNA in programmable nanomaterials..." by Rebecca Taylor.
2. **Artificial Intelligence and Machine Learning**: A significant number of these seminars deal with artificial intelligence (AI) and machine learning (ML) in the context of robotics. Talks like "Learning to Generalize beyond Training" by Deepak Pathak, "Deep Learning for Robotics" by Pieter Abbeel, and "Machine Learning and Model Predictive Control for Adaptive Robotic Systems" by Byron Boots reflect the current focus of the field.
3. **Human-Robot Interaction (HRI)**: Many seminars discuss aspects of how robots interact with humans, either physically or in terms of communication. For example, "Towards Robust Human-Robot Interaction" by Stefanos Nikolaidis, "Enabling Grounded Language Communication for Human-Robot Teaming" by Thomas Howard, and "Human-Robot Interactive Collaboration & Communication" by Heni Ben Amor, highlight the significance of HRI in modern robotics.
4. **Space and Field Robotics**: Some talks focus on the use of robotics in space or fieldwork applications. "Mars Robots and Robotics at NASA JPL" by Vandi Verma and "Robotic Grippers for Planetary Applications" by Aaron Parness exemplify space robotics, while "Autonomous and Intelligent Robots in Unstructured Field Environments" by Girish Chowdhary and "The World’s Tiniest Space Program" by Zachary Manchester underscore field robotics.
5. **Design and Control**: Several seminars delve into the design and control of robotic systems, which can range from the microscale to the macroscale, or even complex, autonomous vehicles. Examples include "Design and control of insect-scale bees and dog-scale quadrupeds" by Avik De, "Design, Modeling and Control of a Robot Bat" by Seth Hutchinson, and "Modeling, Design, and Analysis for Intelligent Vehicles..." by Chung-Wei Lin.
6. **Perception and Environment Interaction**: Seminars such as "Next-Generation Robot Perception..." by Luca Carlone, "Understanding the Physical World from Images" by David Fouhey, and "Perception-Action Synergy in Uncertain Environments" by Jing Xiao highlight the importance of perception and the ability of robots to understand and interact with their environments.
7. **Sustainability and Social Impact**: A few seminars also touch upon topics related to sustainability and social impact, like "Robots Should Reduce, Reuse, and Recycle" by Chelsea Finn and "What (else) can you do with a robotics degree?" by Nidhi Kalra.

## List

 Vandi Verma : Mars Robots and Robotics at NASA JPL

Brenna Argall : Mobility and Manipulation Independence with Interface-Aware Robotics Intelligence

 Phillip Isola : Structures and Environments for Generalist Agents

 Luca Carlone : Next-Generation Robot Perception...

 Lerrel Pinto : A Constructivist’s Guide to Robot Learning

 David Fouhey : Understanding the Physical World from Images

 Jorgen Pedersen: RE2 Robotics: from RI spinout to Acquisition

 Russ Tedrake : Motion Planning Around Obstacles with Graphs of Convex Sets

 Dorsa Sadigh : Learning Representations for Interactive Robotics

 Byron Boots : Machine Learning and Model Predictive Control for Adaptive Robotic Systems

 Chelsea Finn : Robots Should Reduce, Reuse, and Recycle

 Nidhi Kalra : What (else) can you do with a robotics degree?

 Ankur Mehta : Towards $1 robots

 Soon-Jo Chung : Safe and Stable Learning for Agile Robots without Reinforcement Learning

 Ross L. Hatton : Snakes & Spiders, Robots & Geometry

Teruko Yata Memorial Lecture : Jeannette Bohg : Leveraging Language and Video Demonstrations...

 Jing Xiao : Perception-Action Synergy in Uncertain Environments

 Zackory Erickson : Haptic Perspective-taking from Vision and Force

 Leila Bridgeman : Distributed Dissipativity: Applying Foundational Stability Theory...

 Matthew Johnson-Roberson : Lessons from the Field

 Stefanos Nikolaidis : Towards Robust Human-Robot Interaction

 Sebastian Scherer & Matthew Travers : Team Explorer’s Approach and Lessons Learned

 Matthew T. Mason : Robotics and Warehouse Automation at Berkshire Grey

 Siddharth Srivastava : The Unusual Effectiveness of Abstractions for Assistive AI

 Shubham Tulsiani : Towards Reconstructing Any Object in 3D

 Matthew Walter : Robots that Learn through Language

 Thomas Howard : Enabling Grounded Language Communication for Human-Robot Teaming

The Search for Ancient Life on Mars Began with a Safe Landing

 Cynthia Sung : Dynamical Robots via Origami-Inspired Design

 Avik De : Design and control of insect-scale bees and dog-scale quadrupeds

 Jun-Yan Zhu : GANs for Everyone

 Rohan Paul : Towards an Intelligence Architecture for Human-Robot Teaming

 Herman Herman : Robots “R” Us: 25 years of NREC

 Heni Ben Amor : Human-Robot Interactive Collaboration & Communication

 Gustav Eje Henter : Move over, MSE! – New probabilistic models of motion

 Melisa Orta Martinez: Design and Analysis of Open-Source Educational Haptic Devices

RI Seminar : Alberto Rodriguez : Role of Manipulation Primitives in Building Dexterous...

 Mac Schwager : Enabling Robots to Cooperate & Compete: Distributed Optimization...

 Deepak Pathak : Learning to Generalize beyond Training

 Chelsea Finn : Data Scalability for Robot Learning

 Brittany A. Duncan : Drones in Public: distancing and communication with all users

 Kevin Lynch : Robotics and Biosystems

 Raquel Urtasun : A future with affordable Self-driving vehicles

 Zachary Manchester : The World’s Tiniest Space Program

 Robert D. Gregg IV : kinematic/energetic design/robots for agile human locomotion

 Scott Niekum : Scaling Probabilistically Safe Learning to Robotics

 Rebecca Taylor : DNA and gammaPNA in programmable nanomaterials...

 Anca Dragan : Optimizing for coordination with people

 Sarjoun Skaff : Yes, That’s a Robot in Your Grocery Store. Now what?

 Hadas Kress-Gazit : Formal Synthesis for Robots

 Sam Burden : Toward telelocomotion: human sensorimotor control of contact-rich robot...

 Jeff Clune : Improving Robot and Deep Reinforcement Learning via Quality Diversity...

 Girish Chowdhary : Autonomous and Intelligent Robots in Unstructured Field Environments

RI40 Seminar: Harry Asada : From Direct-Drive to SuperLimb Bionics

 Chung-Wei Lin : Modeling, Design, and Analysis for Intelligent Vehicles...

RI Seminar : Pieter Abbeel : Deep Learning for Robotics

RI Seminar : Seth Hutchinson : Design, Modeling and Control of a Robot Bat

 Tucker Hermans : Improving Multi-fingered Robot Manipulation...

 Aaron Parness : Robotic Grippers for Planetary Applications

 Sarah Bergbreiter : Microsystems-inspired robotics